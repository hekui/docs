import path from 'path'
import fs from 'fs'
import express from 'express';
import cookieParser from "cookie-parser";
import bodyParser from "body-parser";
import session from 'express-session';
import connectRedis from 'connect-redis';
import serverRoute from './routes/index';
import LRU from "lru-cache";
import microcache from 'route-cache'

import {
	createBundleRenderer
} from 'vue-server-renderer' //创建渲染器
import serialize from 'serialize-javascript'
import MFS from 'memory-fs'
import {
	port,
	redisConfig
} from './../config/sys.config';
import {
	city as cityInfo
} from './city';

import apple from './apple'

let renderer;
const useMicroCache = process.env.MICRO_CACHE !== 'false'
const createRenderer = fs => {
	const bundlePath = path.resolve(process.cwd(), './dist/server/server-bundle.js');
	return createBundleRenderer(fs.readFileSync(bundlePath, 'utf-8'), {
		cache: LRU({
			max: 1000,
			maxAge: 1000 * 60 * 15
		}),
		runInNewContext: false
	})
}

let assets = {
	"main": {
		"js": "/static/bundle.js"
	}
}

const app = new express()
// app.use(function(req, res, next){
// 	let memoryUsage = process.memoryUsage()
// 	let n = 1024 * 1024
// 	console.log('------------------------------------------------------------------------')
// 	console.log('[进程常驻内存]memoryUsage.rss:\t\t', memoryUsage.rss / n + 'MB')
// 	next()
// })
const RedisStore = connectRedis(session);
app.set('x-powered-by', false);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: false
}));
app.use(cookieParser());
app.use('/', express.static(path.resolve(process.cwd(), 'public')));
app.use(session({
	name: "SSID",
	secret: "mfm-pc",
	resave: false,
	saveUninitialized: true,
	store: new RedisStore(redisConfig),
}));

if (process.env.NODE_ENV === 'development') {
	const webpack = require('webpack')
	const webpackConfig = require('../config/webpack.client.dev')
	const compiler = webpack(webpackConfig); //生成
	const devMiddleware = require('webpack-dev-middleware')
	const hotMiddleware = require('webpack-hot-middleware')
	app.use(devMiddleware(compiler, {
		publicPath: webpackConfig.output.publicPath,
		stats: {
			colors: false,
			modules: false,
			children: false,
			chunks: false,
			chunkModules: false
		}
	}))
	app.use(hotMiddleware(compiler))

	// server renderer
	const serverBundleConfig = require('../config/webpack.bundle')
	const serverBundleCompiler = webpack(serverBundleConfig)
	const mfs = new MFS()
	serverBundleCompiler.outputFileSystem = mfs
	serverBundleCompiler.watch({}, (err, stats) => {
		if (err) throw err
		stats = stats.toJson()
		stats.errors.forEach(err => console.error(err))
		stats.warnings.forEach(err => console.warn(err))
		renderer = createRenderer(mfs)
	})
} else {
	assets = require('../dist/server/webpack-assets');
	// use nginx to serve static files in real
	app.use('/static', express.static(path.resolve(process.cwd(), 'dist/static')));
	renderer = createRenderer(fs)
}

app.use(apple);

//获取城市
app.use(async(req, res, next) => {
	// console.log('req.url：', req.url)
	// console.log('req.city1：', req.city)
	if (!(req.city = await cityInfo(req, res))) {
		return;
	}
	// console.log('req.city2：', req.city)
	next();
});

app.use("/:city", serverRoute);
app.use(microcache.cacheSeconds(1, req => useMicroCache && req.originalUrl))
app.get("*", (req, res) => {
	const context = {
		path: req.path,
		req: req,
		curCity: req.city.curCity,
		city: req.city.curCity.code,
		isWeChat: (/micromessenger/.test(req.headers["user-agent"].toLowerCase())) ? true : false
	};
	const renderStream = renderer.renderToStream(context);
	let cityName = context.curCity.name;
	let title = `${context.title} - ${cityName}新开楼盘，${cityName}房价，${cityName}新楼盘价格，${cityName}楼盘信息 - 买房吗`;
	let keywords = `${cityName}新楼盘,${cityName}地铁楼盘,${cityName}在售楼盘,${cityName}买房,${cityName}楼盘`;
	let description = `买房吗拥有${cityName}完善的${cityName}新开楼盘数据库,收录${cityName}范围500多个${cityName}楼盘信息。买房吗为您节省95%的选房时间.买房吗大数据智能选房,1分钟匹配${cityName}新楼盘房源，为您实现${cityName}安家的梦想。`;

	res.setHeader("Content-Type", "text/html");
	res.write(`<!DOCTYPE html><html><head>
<meta charset="utf-8"/>
<title>${title}</title>
<meta name="keywords" content="${keywords}" />
<meta name="description" content="${description}"/>
<meta name="format-detection" content="telephone=no, email=no"/>
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
<meta content="yes" name="apple-touch-fullscreen">
<meta name="applicable-device" content="mobile">
${assets.main.css ? `<link rel="stylesheet" href="${assets.main.css}"/>` : ''}
<script>(function(){function a(d,c,e){if(d.addEventListener){d.addEventListener(c,e,false)}else{d.attachEvent('on'+c,e)}}
function b(){var c=document.documentElement.clientWidth||document.body.clientWidth;document.documentElement.style.fontSize=c/3.75+'px'}
b();a(window,'resize',b)}());</script>
</head><body>`);
	renderStream.on('data', chunk => {
		res.write(chunk);
	});
	renderStream.on('end', () => {
		res.write(`<script id="resource">window.__INITIAL_STATE__=${serialize(context.initialState, {isJSON: true})}</script>`)
		res.write(`<script src="${assets.main.js}"></script>`);

// 		res.write(`
// <script>
// var _hmt = _hmt || [];
// (function() {
//   var hm = document.createElement("script");
//   hm.src = "https://hm.baidu.com/hm.js?1e17b203b7001ce3fe57aa14acd71b9b";
//   var s = document.getElementsByTagName("script")[0]; 
//   s.parentNode.insertBefore(hm, s);
// })();
// </script>
// `);

//统计代码
res.write(`
<div class="undis">
<script src="https://s11.cnzz.com/z_stat.php?id=1259942820&web_id=1259942820" language="JavaScript"></script>
</div>
`);

		// 不显示商桥的条件：微信、关于我们、下载、协议页面
		if (!context.isWeChat && !(/\/about|\/download|\/agreement/.test(req.path))) {
			res.write(`
<script>
var _hmt = _hmt || []; (function() { var hm = document.createElement("script"); hm.src = "https://hm.baidu.com/hm.js?41620a8a2e1cd446a6eb1244b521b20a"; var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(hm, s); })(); </script> 
<script type="text/javascript" charset="utf-8" async src="https://lxbjs.baidu.com/lxb.js?sid=10488042"></script>
`);
		}
		res.end('</body></html>');
	})
})
process.on('unhandledRejection', (reason, p) => {
  console.error("未捕捉的Promise错误：", p, "\n reason: ", reason);
});
process.on('uncaughtExpection', function(err){
	console.error('uncaughtExpection:', err)
})
app.listen(port, () => {
	console.log(`==> Listening at http://localhost:${port}`)
})