/**
 * Created by NX on 2016/6/28.
 */
import apiFetch from './api-fetch';
import fetch from 'node-fetch';
import querystring from 'querystring';
import {
	utilHost,
	javaHost,
	activeHost,
	requestTimeout,
	pcHost,
	bmapiHost,
} from './../../../config/sys.config';

/**
 * 网络超时
 * @param fn
 * @returns {Function}
 */
function timeOut(fn) {
	function t(fn, req, url, data) {
		return new Promise(async(resolve) => {
			let result, state = 0,
				st = setTimeout(() => {
					if (state == 1) return;
					state = 2;
					resolve({
						code: 10000,
						msg: "网络超时"
					});
				}, requestTimeout);
			result = await fn.apply(undefined, [req, url, data]);
			if (state == 2) return;
			state = 1;
			clearTimeout(st);
			resolve(result);
		}).then((result) => {
			return result;
		});
	}

	return async function (req, url, data) {
		let result = await t(fn, req, url, data);
		return result;
	}
}
/**
 * 查询接口
 * @param req
 * @param url
 * @param data
 * @returns {{userFetch: *, result: *}}
 * @constructor
 */
async function InterFace(req, url, data) {
	let start = new Date().getTime()
	// console.log("InterFace");
	// console.log("=========start==========");
	// console.log(`url:${url}`);
	// console.log(`data:${JSON.stringify(data || {})}`);
	// console.log(`session:   ${JSON.stringify(req.session)}`);

	let userFetch = apiFetch(req.sessionID, req.session.apiFetch),
		result = await userFetch.fetch(url, req.city ? Object.assign({
			CITY_ID: req.city.curCity.id
		}, data) : (data || {}));
	req.session.apiFetch = userFetch;

	let end = new Date().getTime()
	console.log("----------response----------");
	console.log(`[${end - start}ms]url - ${url}`);
	console.log(`**request data: ${JSON.stringify(data || {})}`);
	console.log(`**request session: ${JSON.stringify(req.session)}`);
	console.log(`**result: ${JSON.stringify(Object.assign({
		code: result.code,
		msg: result.msg
	}, {data: result.data ? userFetch.decryptData(result.data) : ""}))}`);

	return {
		userFetch,
		result
	};
}

/**
 * 查询接口 明文返回数据
 * @param host
 * @returns {Function}
 * @constructor
 */
function InterFaceDecrypt(host) {
	return async function (req, url, data) {
		let {
			userFetch,
			result
		} = await InterFace(req, `${host}${url}`, data);
		result = JSON.stringify(userFetch.decryptConvey(result)).replace(/http:\/\/(test.)?img(\d+)\.maifangma\.com/g, 'https://$1img$2.maifangma.com');
		return JSON.parse(result);
	}
}

/**
 * 登陆接口
 */
let loginInterface = timeOut(async function (req, url = "/login", data) {
	delete req.session.apiFetch;
	delete req.session.ticketId;
	delete req.session.userInfo;
	let {
		userFetch,
		result
	} = await InterFace(req, `${utilHost}${url}`, data);
	var decryptRes = userFetch.decryptConvey(result);
	if (result.code == 0) {
		console.log('decryptRes.data.ticketId', decryptRes.data.ticketId)
		userFetch.initTicketId(req.session.ticketId = decryptRes.data.ticketId);
		req.session.userInfo = decryptRes.data || {};
	}
	return decryptRes;
});
/**
 * 工具类接口
 */
let utilInterface = timeOut(InterFaceDecrypt(utilHost));
/**
 * 平台明文返回数据
 */
let decryptInterface = timeOut(InterFaceDecrypt(javaHost));

/**
 * pc端明文返回数据
 * @type {Function}
 */
let webDecryptInterface = timeOut(InterFaceDecrypt(pcHost));

/**
 * 信息收集请求
 */
function resFetch(_url, _data) {
	_data.prj = '170609005';
	_data.qudao = _data.qudao || 'mfm';
	let postData = {
		sign: "",
		data: JSON.stringify(_data),
	}
	// console.log(postData);
	return fetch(bmapiHost + _url, {
			method: 'POST',
			body: querystring.stringify(postData),
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded'
			}
		})
		.then(_res => {
			return _res.json();
		})
}

export {
	loginInterface,
	utilInterface,
	decryptInterface,
	webDecryptInterface,
	resFetch,
};