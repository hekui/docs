/**
 * Created by NX on 2016/6/22.
 */
import fetch from 'node-fetch';
import config from './../../../config/sys.config';
class sdkFetch {
    constructor(token, option) {
        this.deviceNo = token;
        if (option) {
            this.ticketId = option.ticketId;
            this.param = option.param;
        }
    }

    initTicketId(ticketId) {
        this.ticketId = ticketId;
        return this;
    }

    /**
     * 初始化
     */
    init(CITY_ID) {
        this.ticketId = this.ticketId || "";
        this.param = `encryMode=${config.encryMode}&userver=2&utype=2&version=${config.version}&cityId=${CITY_ID||config.cityId}&deviceNo=${this.deviceNo}&deviceType=${config.deviceType}&ticketId=${this.ticketId}`;
    }

    /**
     * 初始化参数
     * @param data
     * @returns {*}
     */
    getParam(data) {
        let sParam;
        if (data != void(0) && data != null) {
            data = `&data=${encodeURIComponent(new Buffer(JSON.stringify(data)).toString("base64"))}`;
        } else data = "";
        sParam = `${this.param}${data}`;
        return sParam;
    }

    /**
     * 明文传输
     * @param result
     */
    decryptConvey(result) {
        let data = result.data;
        if (result.code == 0 && data) Object.assign(result, data ? { data: this.decryptData(result.data) } : {});
        return result;
    }

    /**
     * 解密data数据
     * @param data
     */
    decryptData(data) {
        return JSON.parse(new Buffer(data, "base64").toString());
    }

    /**
     * 发送请求
     * @param url
     * @param data
     * @returns {Promise.<T>}
     */
    async fetch(url, data) {
        this.init(data.CITY_ID);
        let body = this.getParam(data);
        console.log('fetch body', body)
        return fetch(url, {
            method: "POST",
            body: body,
            timeout: 5000,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).then((res) => {
            if (res.status !== 200) return { status: res.status, message: res.statusText };
            else return res.json();
        }).catch(e => {
            console.log(e);
            return e;
        });
    }
}

export default function(token, fetchApi) {
    if (fetchApi) fetchApi = new sdkFetch(token, fetchApi);
    else {
        fetchApi = new sdkFetch(token);
        fetchApi.init();
    }
    return fetchApi;
}