
import express from 'express';
import fetch from 'node-fetch';
const router = express.Router();
import { decryptInterface, webDecryptInterface } from './../core/services-util';
//搜索结果
router.post('/getSearchResult', function (req, res, next) {
    decryptInterface(req, '/houses/listcriteria' ,req.body).then(result => {
        res.json(result);
    });
});
//搜索
router.post('/listkeyword', function (req, res, next) {
    decryptInterface(req, '/houses/listkeyword' ,req.body).then(result => {
        res.json(result);
    });
});


export default router;