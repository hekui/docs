import express from 'express';
import { decryptInterface } from './../core/services-util';
const router = express.Router();

router.post('/getAll', function(req, res, next) {
    Promise.all([
        decryptInterface(req, '/houses/get', {houseId: req.body.housesId}),
        decryptInterface(req, '/housenews/list', req.body),
        decryptInterface(req, '/houses/listestimates/v2_1', {houseId: req.body.housesId}),
        decryptInterface(req, '/trends/list', {housesId: req.body.housesId}),
        decryptInterface(req, '/houses/listnearby', {houseId: req.body.housesId})
    ]).then(result => {
        res.json(result);
    })
})

router.post('/getDetail', function(req, res, next) {
    decryptInterface(req, '/houses/get', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getHouseNews', function(req, res, next) {
    decryptInterface(req, '/housenews/list', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getTypeList', function(req, res, next) {
    decryptInterface(req, '/houses/listdoor', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getComments', function(req, res, next) {
    decryptInterface(req, '/houses/listestimates/v2_1', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getPriceTrends', function(req, res, next) {
    decryptInterface(req, '/trends/list', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getSurround', function(req, res, next) {
    decryptInterface(req, '/houses/listnearby', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getHouseImgs', function(req, res, next) {
    decryptInterface(req, '/houses/listattachs', req.body).then(result => {
        res.json(result);
    });
});

router.post('/getReply', function(req, res, next) {
    decryptInterface(req, '/steward/listcomments', req.body).then(result => {
        res.json(result);
    });
});

router.post('/download', function(req, res, next) {
    decryptInterface(req, '/wechat/version/get', req.body).then(result => {
        res.json(result);
    });
});

export default router;