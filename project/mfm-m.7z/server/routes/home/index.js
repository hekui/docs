import express from 'express';
import fetch from 'node-fetch';
const router = express.Router();
import { decryptInterface, webDecryptInterface } from './../core/services-util';

router.post('/test', function (req, res, next) {
    decryptInterface(req, '/houses/listkeyword', req.body).then(result => {
        res.json(result);
    });
});

export default router;