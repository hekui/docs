
import express from 'express';
import fetch from 'node-fetch';
const router = express.Router();
import { decryptInterface, webDecryptInterface } from './../core/services-util';
//获取户型详情
router.post('/getdoorinfo', function (req, res, next) {
    decryptInterface(req, '/houses/getdoorinfo' ,req.body).then(result => {
        res.json(result);
    });
});
//获取户型列表
router.post('/listdoor', function (req, res, next) {
    decryptInterface(req, '/houses/listdoor' ,req.body).then(result => {
        res.json(result);
    });
});
//获取户型类型
router.post('/gethousestype', function (req, res, next) {
    decryptInterface(req, '/houses/gethousestype' ,req.body).then(result => {
        res.json(result);
    });
});

export default router;