import express from 'express';
import fetch from 'node-fetch';
import querystring from 'querystring';
import {
    getCityList
} from '../../city';
const router = express.Router();


router.post('/getcity', async function (req, res, next) {
    let coords = req.body;
    //坐标转换
    let coordsResult = await fetch('https://api.map.baidu.com/geoconv/v1/?' + querystring.stringify({
        output: 'json',
        coordtype: 'wgs84ll',
        ak: 'zishHhU993mnCRDS3zncmazHuZkIRfti',
        coords: `${coords.longitude},${coords.latitude}`
    }), {
        method: 'GET'
    }).then(_req => {
        return _req.json();
    }).then(_json => {
        return _json;
    }).catch(err => {
        res.json({
            code: 100,
            message: err
        });
        console.log("坐标转换错误：", err);
    });

    //获取地址
    if (coordsResult && coordsResult.status == 0) {
        let coords = coordsResult.result[0];
        let cityResult = await fetch('https://api.map.baidu.com/geocoder/v2/?' + querystring.stringify({
            output: 'json',
            ak: 'zishHhU993mnCRDS3zncmazHuZkIRfti',
            location: `${coords.y},${coords.x}`
        }), {
            method: 'GET'
        }).then(_req => {
            return _req.json();
        }).then(async _json => {
            let cityList = await getCityList(req);
            let _cityCode = 'cd';
            if (_json && _json.status == 0) {
                for (let key in cityList) {
                    if (_json.result.addressComponent.city == cityList[key].name) {
                        _cityCode = cityList[key].code;
                    }
                }
            }
            res.json({
                code: 0,
                data: cityList[_cityCode]
            });
        }).catch(err => {
            res.json({
                code: 100,
                message: err
            });
            console.log("获取地址错误：", err);
        });
    } else {
        res.json({
            code: 100,
            message: '获取地址错误'
        });
    }
});

export default router;