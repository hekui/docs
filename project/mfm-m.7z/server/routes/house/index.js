import express from 'express';
const router = express.Router();
// const apiFetch = require('')
import apiFetch from './../core/api-fetch'

import { decryptInterface, webDecryptInterface } from './../core/services-util';

router.post('/getcriteria', function (req, res, next) {
    decryptInterface(req, '/houses/getcriteria/v3_3', req.body).then(result => {
        res.json(result);
    });
});
router.post('/listcriteria', function (req, res, next) {
    decryptInterface(req, '/houses/listcriteria' ,req.body).then(result => {
        res.json(result);
    });
});

// 订阅状态接口，无tickId直接返回。
router.post('/substatus', function(req, res, next){
    // console.log('req.session.ticketId', req.session.ticketId)
    // console.log('req.cookies', req.cookies)
    if(req.session.ticketId){
        webDecryptInterface(req, '/house/substatus', req.body).then(result => {
            res.json(result);
        })
    }else{
      res.send({
        code: 0,
        data: {
          subStatus: false
        }
      })
    }
})
// 未登录订阅接口，会进行登录，需要在session中写入tickId及用户信息。
router.post('/loginsubscribe', function(req, res, next){
    webDecryptInterface(req, '/house/loginsubscribe', req.body).then(result => {
        if(result.code == 0){
            req.session.ticketId = result.data.ticketId
            req.session.userInfo = result.data

            if(req.session.apiFetch){
                req.session.apiFetch.ticketId = result.data.ticketId
            }

            let userFetch = apiFetch(req.sessionID, req.session.apiFetch);
            userFetch.initTicketId(result.data.ticketId);
        }
        console.log('after router /loginsubscribe')
        console.log('req.session', req.session)
        res.json(result);
    })
})
export default router;