import express from 'express';
import home from './home';
import householdDetail from './household-detail';
import house from './house';
import homePage from './home-page';
import account from './account';
import houseDetail from './house-detail';
import searchResult from './search-result';
import api from './api';
import { utilInterface, decryptInterface, webDecryptInterface } from './core/services-util';

const router = express.Router();

router.use('/home', home);
router.use('/householdDetail', householdDetail);
router.use('/house', house);
router.use('/houseDetail', houseDetail);
router.use('/searchResult', searchResult);
router.use('/api', api);
router.use('/homePage', homePage);
router.use('/account', account);


// utilHost 账户
// router.post('/account', function(req, res, next){
//   // console.log('req.url', req.url)
//   let startTime = new Date().getTime()
//   utilInterface(req, req.url, req.body).then(result => {
//     console.log(`route - ${req.url} - ${new Date().getTime() - startTime}ms`)
//     res.json(result);
//   })
// })

//  javaHost 端接口地址
router.post('*', function(req, res, next){
  // console.log('[*]req.url', req.url)
  let startTime = new Date().getTime()
  decryptInterface(req, req.url, req.body).then(result => {
    console.log(`route - ${req.url} - ${new Date().getTime() - startTime}ms`)
    res.json(result);
  })
})

module.exports = router;