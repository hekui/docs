import express from 'express';
const router = express.Router();
import { utilInterface, loginInterface, decryptInterface, webDecryptInterface } from './../core/services-util';

// 发送验证码
router.post('/sendcode', function (req, res, next) {
    utilInterface(req, '/sendcode', req.body).then(result => {
      res.json(result);
    });
});
// 发送语音验证码
router.post('/sendvoice', function (req, res, next) {
    utilInterface(req, '/sendvoice', req.body).then(result => {
      res.json(result);
    });
});
  
router.post('/login', function (req, res, next) {
    loginInterface(req, '/login', req.body).then(result => {
        res.json(result);
    });
});
  
router.post('/codelogin', function (req, res, next) {
    loginInterface(req, '/codelogin', req.body).then(result => {
        // console.log('codelogin res:', result)
        // req.session.userInfo = result;
        res.json(result);
    });
});
  
// router.post('/register', function (req, res, next) {
//     loginInterface(req, '/register', req.body).then(result => {
//         res.json(result);
//     });
// });
  
router.post('/logout', function (req, res, next) {
    console.log('in logout router')
    utilInterface(req, '/logout').then((result) => {
        req.session.userInfo = {};
        req.session.ticketId = ''
        req.session.apiFetch = ''
        res.json(result);
    }).catch(err => {
        req.session.userInfo = {};
        res.json(result);
    });
});

export default router;