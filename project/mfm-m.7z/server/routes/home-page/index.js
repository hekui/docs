import express from 'express';
const router = express.Router();
import {
    decryptInterface,
    webDecryptInterface,
    resFetch,
} from './../core/services-util';

router.post('/listcity', function (req, res, next) {
    decryptInterface(req, '/home/listcity', req.body).then(result => {
        res.json(result);
    });
});
router.post('/listhot', function (req, res, next) {
    decryptInterface(req, '/houses/listhot', req.body).then(result => {
        res.json(result);
    });
});
router.post('/hotRegion', function (req, res, next) {
    decryptInterface(req, '/home/index', req.body).then(result => {
        res.json(result);
    });
});

router.post('/sysdict', function (req, res, next) {
    decryptInterface(req, '/sysdict/list', req.body).then(result => {
        res.json(result);
    });
});
router.post('/insertcustomer', function (req, res, next) {
    let _body = req.body;
    let _chnType = req.cookies.chnType || '';
    decryptInterface(req, '/wechat/insertcustomer', _body).then(result => {
        res.json(result);
        if (result.code == 0) {
            resFetch('/prj/userclues/add', {
                city: _body.city,
                name: _body.userName,
                tel: _body.phone,
                qudao: _chnType,
                date: "",
                housesId: _body.housesId,
                housesName: _body.name,
            }).then(_data => {
                console.log(_data);
            })
        }
    });
});

router.post('/activitys', function (req, res, next) {
    decryptInterface(req, '/activitys/list', req.body).then(result => {
        res.json(result);
    });
});






export default router;