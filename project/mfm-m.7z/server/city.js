/**
 * Created by hao on 2016/12/5.
 */
import fetch from 'node-fetch';
import querystring from 'querystring';
import {
    decryptInterface
} from './routes/core/services-util';
import {
    redisConfig
} from '../config/sys.config';
import redis from "redis";

const redisClient = redis.createClient(redisConfig);
redisClient.on("error", function (err) {
    console.log("Redis Error: ", err);
});

async function getCityList(req) {
    return new Promise((resolve, reject) => {
        redisClient.get("mfmCityList", function (err, report) {
            if (!report) {
                decryptInterface(req, '/home/listcity')
                    .then(_json => {
                        if (_json.code == 0) {
                            let _cityList = {}
                            _json.data.list.map(city => {
                                _cityList[city.code] = city;
                            })
                            redisClient.set("mfmCityList", JSON.stringify(_cityList));
                            redisClient.expire("mfmCityList", redisConfig.ttl);
                            resolve(_cityList);
                        } else {
                            reject('getCityList Error');
                        }
                    }, res => {
                        reject('getCityList Network Error');
                    })
            } else {
                resolve(JSON.parse(report));
            }
        })
    })
}

async function city(req, res) {
    let subHost = req.path.split('/')[1];
    // if (req.cookies.CITY) {
    //     subHost = req.cookies.CITY
    // }
    if (!subHost) {
        let cityResult = await fetch('https://api.map.baidu.com/location/ip', {
            method: 'POST',
            body: querystring.stringify({
                ak: 'zishHhU993mnCRDS3zncmazHuZkIRfti',
                ip: req.body.ip || req.ip
            })
        }).then(_req => {
            return _req.json();
        }).then(_json => {
            return _json;
        }).catch(err => {
            console.log("获取IP错误：", err);
        });
        if (cityResult && cityResult.status == 0) {
            let _cityCode = 'cd';
            let cityList = await getCityList(req);
            for (let key in cityList) {
                if (cityResult.content.address_detail.city == cityList[key].name) {
                    _cityCode = cityList[key].code;
                }
            }
            res.redirect('/' + _cityCode);
            return false;
        }
    } else {
        let cityList = await getCityList(req);
        let pagePaths = ['/about', '/agreement', '/download'];
        if (cityList[subHost]) {
            let cityInfo = {
                curCity: cityList[subHost],
                cityList
            }
            return cityInfo;
        } else if (pagePaths.indexOf(req.path) > -1) {
            return {
                curCity: cityList['cd'],
                cityList
            }
        } else {
            res.redirect('/cd');
        }
    }
}

module.exports = {
    cityInfo: city,
    getCityList
};