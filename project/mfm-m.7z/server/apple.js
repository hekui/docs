import express from 'express';
const router = express.Router();

router.get('/apple-app-site-association', function (req, res, next) {
  let _text = {
    "applinks": {
      "apps": [],
      "details": [{
        "appID": "E6WC5ACGU5.com.chuangjia.MaiFang",
        "paths": ["*", "/"]
      }]
    }
  };
  res.header('content-type', 'application/pkcs7-mime')
  res.end(JSON.stringify(_text));
});

export default router;