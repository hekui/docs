import {createApp} from './app';

export default context => {
	return new Promise((resolve, reject) => {
		const { app, router, store } = createApp({})
		const { session } = context
		// 设置session
    store.commit('ACCOUNT_SET', {
      target: 'userInfo',
      data: session.userInfo || {}
		})
		
		router.push(context.req.originalUrl);
		
		router.onReady(() => {
			const matchedComponents = router.getMatchedComponents()
      // no matched routes
      if (!matchedComponents.length) {
        return reject({ code: 404 })
			}
			
			store.commit("SET_CITY", context.req.city);
			store.commit("SET_ISSHOWNAV",/micromessenger/.test(context.req.headers['user-agent'].toLowerCase()) ? true : false);
			// Prefetch
			context.title = router.currentRoute.meta.title || "买房吗";
			context.params = router.currentRoute.params;
			context.query = router.currentRoute.query;

			Promise.all(matchedComponents.map(({ preFetch }) => preFetch && preFetch({
        store,
        route: router.currentRoute,
        context
      }))).then(() => {
				context.state = store.state
				// context.initialState = store.state
        resolve(app)
      }).catch(reject)
		}, reject)
	})
}







// export default (context) => {

// 	// get the initialState of vue-router
// 	router.push(context.req.originalUrl);
// 	store.commit("SET_CITY", context.req.city);
// 	store.commit("SET_ISSHOWNAV",/micromessenger/.test(context.req.headers['user-agent'].toLowerCase()) ? true : false);
// 	// Prefetch
// 	context.title = router.currentRoute.meta.title || "买房吗";
// 	context.params = router.currentRoute.params;
// 	context.query = router.currentRoute.query;
// 	return Promise.all(router.getMatchedComponents().map(component => {
// 		if (component.preFetch) {
// 			return component.preFetch({
// 				store,
// 				context
// 			});
// 		}
// 	})).then(() => {
// 		context.initialState = store.state
// 		return app
// 	});
// }