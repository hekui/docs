## @2x 图片计算rem后除以2 

.bg-user@2x {
    width: 124px; height: 124px;
    background: url('css_sprites.png') -637px -362px;
}
.bg-01@2x {
    width: 30px; height: 30px;
    background: url('css_sprites.png') -906px -678px;
}
.bg-1_copy_2@2x {
    width: 18px; height: 34px;
    background: url('css_sprites.png') -146px -822px;
}
.bg-1_copy_3@2x {
    width: 16px; height: 30px;
    background: url('css_sprites.png') -184px -822px;
}
.bg-1_copy_4@2x {
    width: 16px; height: 30px;
    background: url('css_sprites.png') -256px -822px;
}
.bg-1_copy@2x {
    width: 18px; height: 34px;
    background: url('css_sprites.png') -108px -822px;
}
.bg-1@2x {
    width: 18px; height: 34px;
    background: url('css_sprites.png') -70px -822px;
}
.bg-02@2x {
    width: 36px; height: 36px;
    background: url('css_sprites.png') -802px -545px;
}
.bg-4@2x {
    width: 404px; height: 330px;
    background: url('css_sprites.png') -434px -10px;
}
.bg-Combined_Shape {
    width: 163px; height: 163px;
    background: url('css_sprites.png') -454px -362px;
}
.bg-Group_2_Copy@2x {
    width: 96px; height: 96px;
    background: url('css_sprites.png') -386px -678px;
}
.bg-Group_2@2x {
    width: 96px; height: 96px;
    background: url('css_sprites.png') -570px -545px;
}
.bg-Group_3_Copy_2@2x {
    width: 96px; height: 96px;
    background: url('css_sprites.png') -154px -678px;
}
.bg-Group_3@2x {
    width: 96px; height: 96px;
    background: url('css_sprites.png') -270px -678px;
}
.bg-Group_9@2x {
    width: 146px; height: 42px;
    background: url('css_sprites.png') -502px -678px;
}
.bg-Group_Copy@2x {
    width: 96px; height: 96px;
    background: url('css_sprites.png') -454px -545px;
}
.bg-Group@2x {
    width: 96px; height: 96px;
    background: url('css_sprites.png') -686px -545px;
}
.bg-Oval@2x {
    width: 32px; height: 32px;
    background: url('css_sprites.png') -802px -601px;
}
.bg-Rectangle_5@2x {
    width: 16px; height: 30px;
    background: url('css_sprites.png') -220px -822px;
}
.bg-Shape@2x {
    width: 24px; height: 30px;
    background: url('css_sprites.png') -502px -740px;
}
.bg-Triangle@2x {
    width: 20px; height: 12px;
    background: url('css_sprites.png') -858px -640px;
}
.bg-user@2x {
    width: 124px; height: 124px;
    background: url('css_sprites.png') -10px -678px;
}
.bg-地址@2x {
    width: 24px; height: 30px;
    background: url('css_sprites.png') -546px -740px;
}
.bg-房子_激活_copy@2x {
    width: 40px; height: 40px;
    background: url('css_sprites.png') -728px -678px;
}
.bg-房子_激活@2x {
    width: 40px; height: 40px;
    background: url('css_sprites.png') -668px -678px;
}
.bg-户型@2x {
    width: 28px; height: 28px;
    background: url('css_sprites.png') -956px -678px;
}
.bg-火热@2x {
    width: 20px; height: 28px;
    background: url('css_sprites.png') -590px -740px;
}
.bg-没有搜索到房管家@2x {
    width: 424px; height: 296px;
    background: url('css_sprites.png') -10px -362px;
}
.bg-搜索@2x {
    width: 26px; height: 26px;
    background: url('css_sprites.png') -1004px -678px;
}
.bg-我的__2__copy_2@2x {
    width: 40px; height: 46px;
    background: url('css_sprites.png') -10px -822px;
}
.bg-我的__2__copy@2x {
    width: 40px; height: 46px;
    background: url('css_sprites.png') -781px -362px;
}
.bg-我的__2_@2x {
    width: 40px; height: 46px;
    background: url('css_sprites.png') -781px -428px;
}
.bg-暂无评论@2x {
    width: 366px; height: 278px;
    background: url('css_sprites.png') -858px -342px;
}
.bg-暂无网络@2x {
    width: 390px; height: 312px;
    background: url('css_sprites.png') -858px -10px;
}
.bg-3@2x {
    width: 404px; height: 332px;
    background: url('css_sprites.png') -10px -10px;
}
.bg-关于我们2x {
    width: 38px; height: 32px;
    background: url('css_sprites.png') -848px -678px;
}
.bg-我的订阅2x {
    width: 40px; height: 34px;
    background: url('css_sprites.png') -788px -678px;
}