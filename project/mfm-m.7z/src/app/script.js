import Vue from 'vue'
import { Message, Dialog, Input, Form, FormItem, Checkbox, Radio, RadioGroup } from 'element-ui'

Vue.use(Dialog)
Vue.use(Input)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Checkbox)
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.prototype.$message = Message

// import 'element-ui/lib/theme-chalk/index.css'

import {
	Navbar,
} from '../components';
import utils from './../utils/utils'

export default {
	computed: {
		isShowNav() {
			return !this.$store.state.isShowNav;
		},
		routerTransition() {
			return this.$store.state.routerTransition;
		}
	},
	mounted(){
    //分享
		utils.initShare();
		document.body.addEventListener('touchstart', function () { 
			//...空函数即可
		});  
  },
	components: {
		Navbar,
	}
}