import Vue from 'vue';
import {fetch} from 'utils';
import {Icon,Scroller} from './../components';
import { priceFilter, date, phoneSecurity } from './app_filter';
import helper from '../utils/helper';
Vue.use(install);
Vue.component("Icon", Icon);
Vue.component("Scroller", Scroller);
Vue.filter('priceFilter', priceFilter);
Vue.filter('date', date);
Vue.filter('phoneSecurity', phoneSecurity);
let util;
function install(Vue) {
	let property = Object.getOwnPropertyNames(Vue.prototype);
	if (property.indexOf("$util") != -1) return;
	Object.defineProperty(Vue.prototype, "$util", {
		get: function get() {
			return this.$root._util;
		}
	});
	Object.defineProperty(Vue.prototype, "$title", {
		get: function get() {
			return this.$route.meta.title;
		},
		set: function set(title) {
			this.$route.meta.title = title;
		}
	});
	Vue.mixin({
		beforeCreate: function beforeCreate() {
			if (this.$options.util) {
				this._util = this.$options.util;
				this._util.init(this);
			}
		}
	});
	if (typeof window !== "undefined") {
		window.addEventListener('popstate', function () {
			util.beforeBack();
		});
	}
}
function Util() {
	this.app = null;
}
Util.prototype.init = function (app) {
	this.app = app;
	this.routeStoreHistory = [];

};
Util.prototype.getCityCode = function () {
	return this.app.$store.state.cityCode || 'cd';
};
Util.prototype.push = function (path,cityObj) {
	this.beforePush(cityObj);
    let realPath = helper.isNoCityPage(path) ? path : `/${this.getCityCode() + path}`;
	this.app.$router.push(realPath);
};
Util.prototype.beforePush = function(cityObj){
	this.app.$store.commit('SET_ROUTE_STATUS', false);
	this.routeStoreHistory.push(JSON.parse(JSON.stringify(this.app.$store.state)));
	cityObj && this.app.$store.commit("CHANGE_CITY", cityObj);
	this.clearScrollPosition();
};
//status是true时 用后退的历史记录
Util.prototype.beforeBack = function(){
	if(this.routeStoreHistory.length > 0)this.app.$store.commit('SET_ROUTE_STATUS', true);
};
Util.prototype.backReplaceState = function(){
	let historyState = this.routeStoreHistory.length > 0 && this.routeStoreHistory.pop();
	if(historyState){
		historyState.route = JSON.parse(JSON.stringify(this.app.$store.state.route));
		this.app.$store.replaceState(historyState);
	}
};
Util.prototype.back = function () {
	this.app.$router.back();
};
Util.prototype.isWechat = function () {
	return (/micromessenger/.test(navigator.userAgent.toLowerCase())) ? true : false;
};
Util.prototype.fetch = function (url, body = {}) {
	let city = this.getCityCode();
	return fetch(url, body,{city:city});
};
Util.prototype.setScrollPosition = function(position){
	this.app.$store.commit("SET_SCROLL_POSITION",position);
};
Util.prototype.clearScrollPosition = function(){
	this.app.$store.commit("SET_SCROLL_POSITION",{x:0,y:0});
};
Util.prototype.scrollDom = function(dom){
	let position = this.app.$store.state.scrollPosition;
	dom && (dom.scrollTop = position.y);
	dom && (dom.scrollLeft = position.x);
};
util = new Util();
export default util;