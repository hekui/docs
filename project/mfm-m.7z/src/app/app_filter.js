import dayjs from 'dayjs'
function priceFilter(value) {
    if (!value) {
        return 0;
    }
    return (value / 10000).toFixed(2);
}

function date(value, temp = 'YYYY-MM-DD HH:mm:ss'){
    if(!value) return ''
    return dayjs(value.toString().length === 10 ? value * 1000 : value).format(temp)
}

function phoneSecurity(phone){
    if(!phone) return ''
    return phone.substr(0,3) + '****' + phone.substr(7);
}

export {
    priceFilter,
    date,
    phoneSecurity,
}