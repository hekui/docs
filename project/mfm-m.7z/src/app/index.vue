<template>
    <div id="app" class="main-page">
        <div style="display: none;">
            <img src="./img/logo-b.png" />
        </div>
        <!-- <Navbar v-if="isShowNav"></Navbar> -->
        <!--<div class="main-wrap">-->
            <!--<transition :name="routerTransition">-->
            <router-view class="container"></router-view>
            <!--</transition>-->
        <!--</div>-->
    </div>
</template>
<script src="./script.js">
</script>
<style lang="less" src="./style.less">
</style>