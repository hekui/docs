import Vue from 'vue'
import {sync} from 'vuex-router-sync'
import App from './app/index.vue';
import util from './app/app_utils';
import createRouter from './router';
import createStore from './store'

// export default (config)=> {
// 	const router = factoryRouter(config.routeConfig);
// 	sync(store, router);
// 	return {
// 		app: new Vue({
// 			router,
// 			store,
// 			util,
// 			...App
// 		}),
// 		util,
// 		router,
// 		store
// 	}
// }

export function createApp (config){
	const store = createStore()
	const router = createRouter(config.routeConfig)
	
	sync(store, router);
	const app = new Vue({
    router,
		store,
		util,
    render: h => h(App)
  })
	return { app, router, store, util }
}