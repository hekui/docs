/**
 * Created by chuangjia05 on 2016/12/30.
 */
import { fetch } from 'utils';

export default {
    state: {
      ctx: {}, //全局信息
      presellHouse: {}, // 预售楼盘信息
      presellList: {}, // 预售列表
      presellDetail: {}, // 预售详情
      lotteryList: {curPage: 0, nextPage: 1, list: [], pageSize: 20}, //摇号结果列表
      lotteryDetail: {curPage: 0, nextPage: 1, list: [], pageSize: 20}, // 摇号结果详情
      houseDetail: {}, // 楼盘信息
    },
    mutations: {
      SET_PRESELL(state, data) {
        state[data['target']] = data.data
      },
      SET_CONTEXT(state, ctx){
        state.ctx.city = ctx.city;
      },
      SET_LOTTERY_LIST_INIT(state){
        state.lotteryList.curPage = 0
        state.lotteryList.nextPage = 1
      },
      PUSH_LOTTERY_LIST(state, data){
        console.log('data', data)
        let oldList = state.lotteryList.list, newList = data.list;
        delete data.list;
        
        state.lotteryList = {
          ...data,
          list: data.curPage <= 1 ? newList : oldList.concat(newList)
        };
      },
      
      SET_LOTTERY_DETAIL_INIT(state){
        state.lotteryDetail.curPage = 0
        state.lotteryDetail.nextPage = 1
      },
      PUSH_LOTTERY_DETAIL(state, data){
        console.log('data', data)
        let oldList = state.lotteryDetail.list, newList = data.list;
        delete data.list;
        
        state.lotteryDetail = {
          ...data,
          list: data.curPage <= 1 ? newList : oldList.concat(newList)
        };
      },
    },
    actions: {
      // 预售列表
      GET_PRESELL_LIST({commit}, {ctx, params}) {
        if(ctx){
          commit('SET_CONTEXT', ctx);
        }
        return fetch('/presell/listhousespresellbyhousesid', params, ctx || state.ctx).then(result => {
          if (result.code == 0) {
            commit('SET_PRESELL', {
              target: 'presellList',
              data: result.data
            });
            return Promise.resolve(result.data);
          } else {
            // return Promise.reject(result);
          }
        }, res => {
          // return Promise.reject({});
        });
      },
      // 预售详情
      GET_PRESELL_DETAIL({commit}, {ctx, params}) {
        if(ctx){
          commit('SET_CONTEXT', ctx);
        }
        return fetch('/presell/gethousespresell', params, ctx || state.ctx).then(result => {
          if (result.code == 0) {
            commit('SET_PRESELL', {
              target: 'presellDetail',
              data: result.data
            });
            return Promise.resolve(result);
          } else {
            return Promise.reject(result);
          }
        }, res => {
          return Promise.reject({});
        });
      },
      // 摇号结果列表
      GET_LOTTERY_LIST({commit, state}, {context, params, callback}) {
        let curPage = state.lotteryList.nextPage || state.lotteryList.curPage + 1,
            pageSize = state.lotteryList.pageSize || 20;
        if(context){
          commit('SET_CONTEXT', context);
        }
        return fetch('/presell/listhousespresell', {
          curPage, pageSize,
        }, context || state.ctx).then(result => {
          if (result.code == 0) {
            commit('PUSH_LOTTERY_LIST', result.data)
            callback && callback(state.lotteryList.hasNext == true ? undefined : 1);
            return Promise.resolve(result.data);
          } else {
            // return Promise.reject(result);
          }
        }, res => {
          // return Promise.reject({});
        });
      },
      // 摇号结果详情
      GET_LOTTERY_DETAIL({commit, state}, {context, params, callback}) {
        let curPage = state.lotteryDetail.nextPage || state.lotteryDetail.curPage + 1,
            pageSize = state.lotteryDetail.pageSize || 20;
        if(context){
          commit('SET_CONTEXT', context);
        }
        return fetch('/presell/listHouseLotteryResult', {
          curPage, pageSize,
          presellId: params.presellId,
          keyword: params.keyword
        }, context || state.ctx).then(result => {
          if (result.code == 0) {
            commit('PUSH_LOTTERY_DETAIL', result.data)
            callback && callback(state.lotteryDetail.hasNext == true ? undefined : 1);
            return Promise.resolve(result.data);
          } else {
            // return Promise.reject(result);
          }
        }, res => {
          // return Promise.reject({});
        });
      },
      // 通过presellId查询楼盘信息
      GET_HOUSE_DETAIL_BY_PRESELLID({commit, state}, {context, presellId}) {
        return fetch('/presell/queryhousename', { presellId }, context || state.ctx).then(result => {
          if (result.code == 0) {
            commit('SET_PRESELL', {
              target: 'houseDetail',
              data: result.data
            });
            return Promise.resolve(result.data);
          } else {
            // return Promise.reject(result);
          }
        }, res => {
          // return Promise.reject({});
        });
      },
      
      
    }
}