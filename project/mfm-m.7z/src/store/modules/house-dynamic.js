import { fetch } from 'utils';
export default{
    actions:{
        HOUSE_DYNAMIC_LIST({commit},context){
           return fetch('/houseDetail/getHouseNews', {
                curPage: 1,
                pageSize: 100,
                housesId: context.params.id || "",
                type: 1
            }, context).then(res=>{
               commit("SET_NEWS_HDETAIL", res);
           })
        },
        FETCH_USER_INFO({commit},obj){
            return fetch('/homePage/insertcustomer',obj,obj).then(res=>{
                   return res;
            })
        }
    }
}

