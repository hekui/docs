import { fetch } from "utils";

const ACCOUNT_SET = 'ACCOUNT_SET'
const ACCOUNT_CODE_LOGIN = 'ACCOUNT_CODE_LOGIN' // 登录
const ACCOUNT_LOGOUT = 'ACCOUNT_LOGOUT'
const ACCOUNT_FORGET = 'ACCOUNT_FORGET'         // 找回
const ACCOUNT_REGISTER = 'ACCOUNT_REGISTER'     // 注册
const ACCOUNT_CHECKACCOUNT = 'ACCOUNT_CHECKACCOUNT' // 帐号是否存在
const ACCOUNT_SENDCODE = 'ACCOUNT_SENDCODE'     // 通过帐号获取验证码

export default {
  state: {
    ctx: {}, //全局信息
    userInfo: {},
  },
  mutations: {
    [ACCOUNT_SET](state, data){
      state[data['target']] = data.data
    },
    SET_CONTEXT(state, ctx){
      state.ctx.city = ctx.city;
    },
  },
  actions: {
    [ACCOUNT_CODE_LOGIN]({commit, state}, {context, params}){
      return fetch('/account/codelogin', params, context || state.ctx).then(res => {
        if(res.code === 0){
          commit('ACCOUNT_SET', {
            target: 'userInfo',
            data: res.data
          })
          return Promise.resolve(res)
        }else{
          return Promise.reject(res)
        }
      }, res => {
        return Promise.reject(res)
      })
    },
    [ACCOUNT_LOGOUT]({commit}){
      return fetch('/account/logout',{}, {
        city: 'cd'
      }).then(res => {
        commit('ACCOUNT_SET', {
          target: 'userInfo',
          data: {}
        })
        return res
      })
    },
    [ACCOUNT_SENDCODE]({commit, state}, {context, params}){
      return fetch('/account/sendcode', params, context || state.ctx).then(res => {
        if(res.code === 0){
          return res
        }else{
          return Promise.reject(res)
        }
      }, res => {
        return Promise.reject(res)
      })
    },
    ACCOUNT_SENDVOICE({commit, state}, {context, params}){
      return fetch('/account/sendvoice', params, context || state.ctx).then(res => {
        if(res.code === 0){
          return res
        }else{
          return Promise.reject(res)
        }
      }, res => {
        return Promise.reject(res)
      })
    },
    
  }
}