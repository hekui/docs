import { fetch } from 'utils';
import tools from './tools'

export default {
    state: {
        info: {},
        news: [],
        types: [],
        commentInfo: { list: [] },
        prices: [],
        surrounds: [],
        houseImgs: [],
        isSubscribeNews: false,
    },

    mutations: {
        HOUSEDETAIL_SET(state, data){
            state[data['target']] = data.data 
        },

        SET_DETAIL_HDETAIL(state, {data, code, msg}) {
            if (code == 0) {                
                state.info = data || {};
                state.types = state.info.doorModels || [];
            } else {
                console.log(msg);
            }
        },

        SET_NEWS_HDETAIL(state, {data, code, msg}) {
            if (code == 0) {
                let list = (data && data.list) || [];
                let date = null;
                list.forEach(item => {
                    date = new Date(item.sendDate * 1000);
                    item.sendDate = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
                });                
                state.news = list;
            } else {
                console.log(msg);
            }
        },

        SET_COMMENTS_HDETAIL(state, {data, code, msg}) {        
            if (code == 0) {
                state.commentInfo.total = (data && data.totalRecords) || 0;
                state.commentInfo.list = (data && data.list) || [];
            } else {
                console.log(msg);
            }
        },

        SET_PRICES_HDETAIL(state, {data, code, msg}) {
            if (code == 0) {      
                let list = (data && data.list) || [];    
                state.prices = list.filter(v => {
                    return !!v.price;
                });
            } else {
                console.log(msg);
            }
        },

        SET_SURROUNDS_HDETAIL(state, {data, code, msg}) {
            if (code == 0) {            
                state.surrounds = (data && data.list) || [];
            } else {
                console.log(msg);
            }
        },

        SET_HOUSEIMGS_HDETAIL(state, {data, code, msg}) {
            if (code == 0) {          
                let list = (data && data.list) || [];
                state.houseImgs = list.filter(v => {
                    return v.list && v.list.length;
                });
            } else {
                console.log(msg);
            }
        }
    },

    actions: {
        GET_DETAIL_HDETAIL({commit}, {context, houseId}) {
            if (houseId == null) {
                return;
            }
            // return Promise.all([
            //     fetch('/houseDetail/getDetail', {houseId: houseId}, context),
            //     fetch('/houseDetail/getHouseNews', {
            //         curPage: 1,
            //         pageSize: 1,
            //         housesId: houseId,
            //         type: 1
            //     }, context),
            //     fetch('/houseDetail/getComments', {houseId: houseId}, context),
            //     fetch('/houseDetail/getPriceTrends', {housesId: houseId}, context),
            //     fetch('/houseDetail/getSurround', {houseId: houseId}, context)                
            // ]).then(result => {
            //     commit('SET_DETAIL_HDETAIL', result[0] || {});
            //     commit('SET_NEWS_HDETAIL', result[1] || {});
            //     commit('SET_COMMENTS_HDETAIL', result[2] || {});
            //     commit('SET_PRICES_HDETAIL', result[3] || {});
            //     commit('SET_SURROUNDS_HDETAIL', result[4] || {});
            // });
            return fetch('/houseDetail/getAll', {
                curPage: 1,
                pageSize: 1,
                housesId: houseId,
                type: 1
            }, context).then(result => {
                commit('SET_DETAIL_HDETAIL', result[0] || {});
                commit('SET_NEWS_HDETAIL', result[1] || {});
                commit('SET_COMMENTS_HDETAIL', result[2] || {});
                commit('SET_PRICES_HDETAIL', result[3] || {});
                commit('SET_SURROUNDS_HDETAIL', result[4] || {});
            })
        },

        GET_HOUSE_DETAIL({commit}, {context, houseId}) {
            if (houseId == null) {
                return;
            }
            return fetch('/houseDetail/getDetail', {
                houseId: houseId
            }, context) .then(result => {
                commit('SET_DETAIL_HDETAIL', result || {});
            });
        },
        GET_HOUSEIMGS_HDETAIL({commit}, {context, houseId}) {
            if (houseId == null) {
                return;
            }
            return fetch('/houseDetail/getHouseImgs', {
                houseId: houseId
            }, context) .then(result => {
                commit('SET_HOUSEIMGS_HDETAIL', result || {});
            });
        },
        // 订阅 - 状态
        HOUSEDETAIL_SUBSCRIBE_STATUS_FETCH({commit}, {params, context}){
            return fetch('/house/substatus', params, context).then(res => {
              if(res.code === 0){
                commit('HOUSEDETAIL_SET', {
                    target: 'isSubscribeNews',
                    data: res.data.subStatus
                })
                return res
              }else{
                commit('HOUSEDETAIL_SET', {
                    target: 'isSubscribeNews',
                    data: false
                })
                tools.clearUserInfo({
                    commit,
                    res,
                })
              }
            })
        },
        // 已登录 - 订阅
        HOUSEDETAIL_SUBSCRIBE_LOGINED_POST({commit}, {params, context}){
            return fetch('/house/subscribe', params, context).then(res => {
              if(res.code == 0){
                commit('HOUSEDETAIL_SET', {
                  target: 'isSubscribeNews',
                  data: true
                })
                return res
              }else{
                tools.clearUserInfo({
                    commit,
                    res,
                })
                return Promise.reject(res)
              }
            }, res => {
              return Promise.reject(res)
            })
        },
        // 未登录 - 订阅
        HOUSEDETAIL_SUBSCRIBE_UNLOGINED_POST({commit}, {params, context}){
            return fetch('/house/loginsubscribe', params, context).then(res => {
              if(res.code == 0){
                setTimeout(() => {
                  commit('ACCOUNT_SET', {
                    target: 'userInfo',
                    data: res.data
                  })
                }, 10)
                commit('HOUSEDETAIL_SET', {
                  target: 'isSubscribeNews',
                  data: true
                })
                return res
              }else{
                return Promise.reject(res)
              }
            })
        },
        // 取消订阅
        HOUSEDETAIL_UNSUBSCRIBE_FETCH({commit}, {params, context}){
            return fetch('/house/unsubscribe', params, context).then(res => {
                if(res.code === 0){
                    return res
                }else{
                    tools.clearUserInfo({
                        commit,
                        res,
                    })
                    return Promise.reject(res)
                }
            }, res => {
              
            })
        },
    }
}