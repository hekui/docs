import houseSearch from './house-search';
import houseDetail from './house-detail';
import householdDetail from './household-datail';
import searchResult from './search-result';
import homePage from './home-page';
import householdList from './household-list';
import Search from './search';
import houseDynamic from './house-dynamic';
import comment from './comment';
import account from './account';
import my from './my';
import presell from './presell';

export default {
	houseSearch,
    houseDetail,
    householdDetail,
    searchResult,
	homePage,
    houseDynamic,
    householdList,
    Search,
    account,
    my,
    comment,
    presell,
}