import {fetch} from 'utils';
//status
const state = {
	ctx: {}, //全局信息
	errorStatus: "",
	status: 1,//面板类型
	search: "", //查询参数
	checkSearch: null, //选中
	clearSearch: null, //清理
	searchArr: {}, //选中对象
	nowExhibitions: -1, //面板
	houseList: {curPage: 0, nextPage: 1, list: []},//查询楼盘列表
	houseKaipanList: {curPage: 0, nextPage: 1, list: [], pageSize: 20},//即将开盘列表
	houseSellingList: {curPage: 0, nextPage: 1, list: [], pageSize: 20},//正在销售
	exhibitions: [
		{name: "区域", param: "region", status: 2, defaultName: "区域"},
		{name: "面积", param: "area", status: 2, defaultName: "面积"},
		{name: "价格", param: "price", status: 2, defaultName: "价格"},
		{name: "更多", param: "more", status: 3, defaultName: "更多", checkName: "多选", checkCount: 0}
	],
	panels: [],
	panel: {}
};
const mutations = {
	SETH_HOUSE_SEARCH_STATUS(state, status){
		state.status = status;
	},
	SET_NOW_EXHIBITIONS(state, index){
		state.nowExhibitions = index;
	},
	SET_CONTEXT(state, ctx){
		state.ctx.city = ctx.city;
	},
	SET_ERROR_STATUS(state, status){
		state.errorStatus = status;
	},
	SET_KAIPAN_INIT(state){
		state.houseKaipanList.curPage = 0
		state.houseKaipanList.nextPage = 1
	},
	SET_SELLING_INIT(state){
		state.houseSellingList.curPage = 0
		state.houseSellingList.nextPage = 1
	},
	CLEAR_HOUSE_LIST(state){
		state.houseList.curPage = 0;
		state.houseList.nextPage = 1;
		state.houseList.list.splice(0, state.houseList.list.length);
	},
	PUSH_HOUSE_LIST(state, houseList){
		let oldHouseList = state.houseList.list, nowHouseList = houseList.list;
		delete houseList.list;
		state.houseList = {
			...houseList,
			list: oldHouseList.concat(nowHouseList)
		};
	},
	PUSH_HOUSEKAIPAN_LIST(state, houseList){
		let oldHouseList = state.houseKaipanList.list, nowHouseList = houseList.list;
		delete houseList.list;
		state.houseKaipanList = {
			...houseList,
			list: houseList.curPage <= 1 ? nowHouseList : oldHouseList.concat(nowHouseList)
		};
	},
	PUSH_HOUSESELLING_LIST(state, houseList){
		let oldHouseList = state.houseSellingList.list, nowHouseList = houseList.list;
		delete houseList.list;
		state.houseSellingList = {
			...houseList,
			list: houseList.curPage <= 1 ? nowHouseList : oldHouseList.concat(nowHouseList)
		};
	},
	UPDATE_SEARCH_STR(state){
		let search = [], searchArr = state.searchArr;
		for (let key in searchArr) search.push(getSearchStr(searchArr[key]));
		state.search = search.join("#");
	},
	RESET_SEARCH_CHECKED(state){
		state.checkSearch = undefined;
		state.clearSearch = undefined;
	},
	ADD_SEARCH_ARR(state){
		let checkSearch = state.checkSearch, searchArr = state.searchArr, status = true;
		if (!checkSearch) return;
		!searchArr.hasOwnProperty(checkSearch.type) && (searchArr[checkSearch.type] = []);
		for (let i = 0, len = searchArr[checkSearch.type].length; i < len; i++) {
			if (searchArr[checkSearch.type][i].id == checkSearch.id) {
				status = false;
				break;
			}
		}
		if (status)searchArr[checkSearch.type].push(checkSearch);
	},
	CLEAR_SEARCH_ARR(state){
		let clearSearch = state.clearSearch, searchArr = state.searchArr, clientIndex = -1;
		if (!clearSearch || !searchArr.hasOwnProperty(clearSearch.type) || (state.checkSearch && state.checkSearch.id == clearSearch.id)) return;
		for (let i = 0, len = searchArr[clearSearch.type].length; i < len; i++) {
			if (searchArr[clearSearch.type][i].id == clearSearch.id) {
				clientIndex = i;
				break;
			}
		}
		if (clientIndex != -1) {
			searchArr[clearSearch.type].splice(clientIndex, 1);
			searchArr[clearSearch.type].length == 0 && (delete searchArr[clearSearch.type]);
		}
	},
	SET_MORE_SEARCH_ACTIVE(state, {index,activeIndex}){
		let panel = state.panels[state.nowExhibitions][index], target = panel.render[activeIndex],
			cursorIndex = panel.active.indexOf(activeIndex), exhibitions = state.exhibitions[state.nowExhibitions];
		if (cursorIndex == -1) {
			panel.active.push(activeIndex);
			state.checkSearch = target;
			exhibitions.checkCount += 1;
		} else {
			panel.active.splice(cursorIndex, 1);
			state.clearSearch = target;
			exhibitions.checkCount -= 1;
		}

	},
	SWITCH_PANEL(state, index){
		let panel = state.panel = state.panels[index], status = state.exhibitions[index].status;
		if (status != 3 && panel.active.length == 0) panel.render[0] = panel.data[0];
		else if (status == 3) panel = state.panels[index];
		state.status = state.exhibitions[index].status;
	},
	RESIZE_STORE(state){
		state.panels = [];
		state.panel = {};
		state.status = 1;
		state.search = "";
		state.checkSearch = null;
		state.clearSearch = null;
		state.searchArr = {};
		state.nowExhibitions = -1;
		state.exhibitions = [
			{name: "区域", param: "region", status: 2, defaultName: "区域"},
			{name: "面积", param: "area", status: 2, defaultName: "面积"},
			{name: "价格", param: "price", status: 2, defaultName: "价格"},
			{name: "更多", param: "more", status: 3, defaultName: "更多", checkName: "多选", checkCount: 0}
		];
		state.houseList = {curPage: 0, nextPage: 1, list: []};
	},
	INIT_PANEL(state, regionId){
		recursionPanls(regionId, state.panels, state.exhibitions, state)
	},
	INIT(state, data){
		let exhibitions = state.exhibitions, status,
			exhData, panels = state.panels;
		exhibitions.map((item, key)=> {
			exhData = data[item.param];
			status = item.status;
			recursionArray(exhData, factoryPanle(panels, key, status).data, 0, factoryPanle(panels, 3, 3), {
				type: "",
				pType: ""
			});
		});
	},
	SET_PANEL_NAME(state, status){
		let exhibitions = state.exhibitions[state.nowExhibitions], name;
		if (state.checkSearch) name = state.checkSearch.name;
		if (exhibitions.checkName) {
			if (exhibitions.checkCount > 0) name = exhibitions.checkName;
			else name = exhibitions.defaultName;
		}
		name && (exhibitions.name = name);
		if ((name && state.status != 3) || status) state.nowExhibitions = -1;
	},
	FILTER_PANEL(state, {index, activeIndex}){
		let panel = state.panel, filterCondition;
		if (activeIndex == -1) {
			if (index == 0) filterCondition = {
				id: activeIndex,
				name: state.exhibitions[state.nowExhibitions].defaultName
			};
			else filterCondition = panel.render[index - 1][panel.active[index - 1]];
		} else filterCondition = panel.render[index][activeIndex];
		let pushArr = [], data = panel.data[index + 1];
		if (!data && (state.status = 1,
				state.clearSearch = panel.checkSearch,
				panel.checkSearch = filterCondition,
				state.checkSearch = filterCondition, true)) return;
		panel.data[index + 1].map((item)=> {
			if (item.pType == filterCondition.id) pushArr.push(item);
		});
		if (pushArr.length == 0 && (state.status = 1,
				state.clearSearch = panel.checkSearch,
				panel.checkSearch = filterCondition,
				state.checkSearch = filterCondition, true)) return;
		panel.render[index + 1] = pushArr;
		return true;
	},
	UPDATE_PANEL(state, {index, activeIndex}){
		let panel = state.panel;
		panel.active[index] = activeIndex;
		panel.active = panel.active.splice(0, index + 1);
		panel.render = panel.render.slice(0, index + 1);
	}
};
const actions = {
	HOUSE_SEARCH_STATUS({commit}, status){//修改显示状态
		commit('SETH_HOUSE_SEARCH_STATUS', status);
	},
	HOUSE_SWITCH_PANEL({commit}, index){ //切换面板
		commit("SWITCH_PANEL", index);
	},
	HOUSE_UPDATE_PANEL({commit}, data){ //普通显示面板修改
		commit("UPDATE_PANEL", data);
		commit("FILTER_PANEL", data);
		commit('SET_PANEL_NAME');
		commit("ADD_SEARCH_ARR");
		commit("CLEAR_SEARCH_ARR");
		commit("UPDATE_SEARCH_STR");
		commit("RESET_SEARCH_CHECKED");
	},
	HOUSE_SET_NOW_EXHIBITIONS({commit}, index){//修改显示面板对应值
		commit("SET_NOW_EXHIBITIONS", index);
	},
	HOUSE_UPDATE_SEARCH_STR({commit}){
		commit("UPDATE_SEARCH_STR");
	},
	HOUSE_SET_MORE_SEARCH_ACTIVE({commit}, data){ //多选时选中后调用
		commit("SET_MORE_SEARCH_ACTIVE", data);
		commit('SET_PANEL_NAME');
		commit("ADD_SEARCH_ARR");
		commit("CLEAR_SEARCH_ARR");
		commit("RESET_SEARCH_CHECKED");
	},
	HOUSE_CLEAR_HOUSE_LIST({commit}){
		commit("CLEAR_HOUSE_LIST");
	},
	HOUSE_RESIZE_STORE({commit}){
		commit('RESIZE_STORE');
	},
	HOUSE_FETCH_LIST({commit,state}, {callback,ctx}){
		let search = state.search,
			curPage = state.houseList.nextPage || state.houseList.curPage + 1;
		return fetch('/house/listcriteria', {queryData: search, curPage: curPage}, ctx || state.ctx).then(result=> {
			if (result.code != 0) return commit("SET_ERROR_STATUS", result.code);
			commit('PUSH_HOUSE_LIST', result.data);
			callback && callback(state.houseList.hasNext == true ? undefined : 1);
		});
	},
	HOUSE_KAIPAN_LIST({commit, state}, {callback, ctx, keyword}){
		let curPage = state.houseKaipanList.nextPage || state.houseKaipanList.curPage + 1,
				pageSize = state.houseKaipanList.pageSize || 20;
		if(ctx){
			commit('SET_CONTEXT', ctx);
		}
		return fetch('/presell/listhouseswillsale', {keyword, curPage, pageSize}, ctx || state.ctx).then(result => {
			commit('PUSH_HOUSEKAIPAN_LIST', result.data);
			callback && callback(state.houseKaipanList.hasNext == true ? undefined : 1);
		});
	},
	HOUSE_SELLING_LIST({commit, state}, {callback, ctx, keyword}){
		let curPage = state.houseSellingList.nextPage || state.houseSellingList.curPage + 1,
				pageSize = state.houseSellingList.pageSize || 20;
		if(ctx){
			commit('SET_CONTEXT', ctx);
		}
		return fetch('/presell/listhousesonsale', {keyword, curPage, pageSize}, ctx || state.ctx).then(result => {
			if(result.code === 0){
				commit('PUSH_HOUSESELLING_LIST', result.data);
				callback && callback(state.houseSellingList.hasNext == true ? undefined : 1);
			}
		});
	},
	HOUSE_INIT({commit,dispatch,state}, {context,regionId}){//初始化显示数据
		return fetch('/house/getcriteria', {}, context).then(result=> {
			commit('INIT', result.data);
			commit('INIT_PANEL', regionId);
			commit('SET_CONTEXT', context);
		}).then(()=> {
			return dispatch("HOUSE_FETCH_LIST", {
				ctx: context,
				search: state.search,
				curPage: state.houseList.nextPage
			})
		});
	},
};

function type(obj) {
	return Object.prototype.toString.call(obj).replace(/\[object ([\S]*)\]/ig, "$1");
}

function getSearchStr(searchArr, prefix) {
	let search = prefix || "";
	searchArr.map((item, key)=> {
		if (item.id == -1) return;
		if (key == 0) {
			if (item.type == item.id) search += item.type;
			else search += item.type + "_" + item.id;
		} else {
			if (item.type == item.id) return;
			search += "," + item.id;
		}
	});
	return search;
}

function factoryPanle(panels, key, status) {
	return panels[key] || (panels[key] = function () {
			let panel;
			switch (status) {
				case 2:
					panel = {active: [], checkSearch: null, data: [], render: []};
					break;
				case 3:
					panel = [];
					break;
			}
			return panel;
		}());
}

function recursionArrayIndex(list, active, render, regionId) {
	let j, z, k, i;
	for (i = list.length - 1; i >= 0; i--) {
		let item = list[i];
		for (j = item.length - 1; j >= 0; j--) {
			if (item[j].id == regionId) {
				!active.check && (active.check = item[j]);
				active.status = true;
				regionId = item[j].pType;
				render.unshift([]);
				break;
			}
		}
		if (active.status) {
			for (z = 0, k = -1; z < item.length; z++) {
				if (regionId == item[z].pType) {
					k++;
					render[0].push(item[z]);
				}
				if (item[j] == item[z]) {
					active.arr.unshift(k);
				}
			}
		}
	}
}

function recursionMoreIndex(list, active, regionId) {
	let status = false;
	for (let i = list.length - 1; i >= 0; i--) {
		let item = list[i];
		if (item.id == regionId) {
			active.arr.push(i);
			active.check = item;
			status = true;
		}
	}
	return status;
}
function recursionPanls(regionId, panels, exhibitions, state) {
	let active = {
		check: null,
		arr: [],
		status: false
	};
	panels.map((item, key)=> {
		if (type(item.data) === "Array") {
			recursionArrayIndex(item.data, active, item.render, regionId);
			if (active.status) {
				exhibitions[key].name = active.check.name;
				panels[key].active = active.arr;
				panels[key].checkSearch = active.check;
				active.status = false;
			}
		} else if (type(item) === "Array") {
			item.map(item1=> {
				if (recursionMoreIndex(item1.render, active, regionId)) {
					item1.active = active.arr;
					exhibitions[key].checkCount++;
					exhibitions[key].name = exhibitions[key].checkName;
				}
			});

		}
	});
	if (active.check) {
		state.search = active.check.type + "_" + active.check.id;
		state.searchArr[active.check.type] = [active.check];
	}
}


function recursionArray(data, arr, index, moreArr, context) {
	if (type(data) != "Array") return;
	data.map((item)=> {
		if (index == 0) context.type = item.id;
		if (!item.multiple && arr) radioType(item, arr, index, moreArr, context);
		else checkboxType(item, moreArr);
	});
}

function radioType(item, arr, index, moreArr, context) {
	let pushArr, list = item.list;
	pushArr = arr[index] || (arr[index] = []);
	delete item.list;
	pushArr.unshift({
		...item,
		...context
	});
	recursionArray(list, arr, index + 1, moreArr, {
		type: context.type,
		pType: item.id
	});

}
function checkboxType(data, moreArr) {
	moreArr.push(data);
	data.active = [];
	data.render = [];
	data.list.map((item)=> {
		data.render.unshift({
			...item,
			...{
				type: data.id,
				pType: data.id
			}
		});
	});
	delete data.list;
}
export default {
	state,
	mutations,
	actions
}