import { fetch } from 'utils';

export default {
    state: {
        listInfo: {list: []},
        reply: {list: []},
        critic: {}
    },

    mutations: {
        SET_LISTINFO_COMMENT(state, {data, code, msg}) {
            if (code == 0) {   
                state.listInfo.hasNext = data && data.hasNext;
                state.listInfo.total = (data && data.totalRecords) || 0;             
                state.listInfo.list = (data && data.list) || [];
            } else {
                console.log(msg);
            }
        },

        ADD_LISTINFO_COMMENT(state, {data, code, msg}) {
            if (code == 0) {        
                state.listInfo.list = state.listInfo.list.concat(data.list || []);
            } else {
                console.log(msg);
            }
        },

        SET_REPLY_COMMENT(state, {data, code, msg}) {
            if (code == 0) {   
                state.reply.hasNext = data && data.hasNext;
                state.reply.total = (data && data.totalRecords) || 0;             
                state.reply.list = (data && data.list) || [];
            } else {
                console.log(msg);
            }
        },

        ADD_REPLY_COMMENT(state, {data, code, msg}) {
            if (code == 0) {        
                state.reply.list = state.reply.list.concat(data.list || []);
            } else {
                console.log(msg);
            }
        },

        SET_CRITIC_COMMENT(state, {data, code, msg}) {
            if (code == 0) {   
                let list = (data && data.list) || [];
                state.critic = list[0] || {};
            } else {
                console.log(msg);
            }
        }
    },

    actions: { 
        GET_LIST_COMMENT({commit}, {context, params}) {
            return fetch('/houseDetail/getComments', {
                houseId: params.houseId,
                curPage: params.page || 1,
                pageSize: params.pageSize || 10
            }, context).then(result => {
                commit('SET_LISTINFO_COMMENT', result || {});
            });
        },

        GET_REPLY_COMMENT({commit}, {context, params}) {
            return Promise.all([
                fetch('/houseDetail/getReply', {
                    estimateId: params.estimateId,
                    curPage: params.page || 1,
                    pageSize: params.pageSize || 10
                }, context),
                fetch('/houseDetail/getComments', { estimateId: params.estimateId }, context)
            ]).then(result => {
                commit('SET_REPLY_COMMENT', result[0] || {});
                commit('SET_CRITIC_COMMENT', result[1] || {});
            });
        }

    }
}