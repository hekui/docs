/**
 * Created by chuangjia05 on 2016/12/29.
 */
import { fetch } from 'utils';

export default {
    state: {
        ctx: {},
        info: {list: []}
    },
    mutations: {
        SET_SEARCH_RESULT(state,{data, code, msg}) {
            if (code == 0) {
                let list = data.list;
                delete data.list;
                state.info = {
                    ...data,
                    list:list
                }
            } else {
                console.log(msg);
            }
        },
        ADD_SEARCH_RESULT(state, {data, code, msg}) {
            if (code == 0) {
                state.info.list = state.info.list.concat(data.list || []);
            } else {
                console.log(msg);
            }
        }
    },
    actions: {
        GET_SEARCH_RESULT({commit}, {context, params}) {
            return fetch('/searchResult/getSearchResult', {
                keyword:params.keyword, 
                curPage: params.page || 1,
                pageSize: params.pageSize || 10
            }, context).then(result => {
                    commit('SET_SEARCH_RESULT', result.data);
          
            });
        },
        GET_SEARCH_RESULT({commit},{context, params}) {
            return fetch('/searchResult/getSearchResult', {
                keyword: params.keyword,
                curPage: params.page || 1,
                pageSize: params.pageSize || 10
            }, context).then(result => {
                commit('SET_SEARCH_RESULT', result || {});
            });
        }
    }
}