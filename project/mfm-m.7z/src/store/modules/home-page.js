/**
 * Created by wo on 2016/12/29.
 */
import {fetch} from "utils";
export default{
    state: {
        cityList:{},
        listHot:{total:"",list:[],},
        region:{},
        sysdict:{},
        banner: [],

    },
    mutations: {
        FETCH_LIST_CITY(state,{data}){
            state.cityList = data.list;
        },
        FETCH_HOUSE_HOT(state,{data}){
            state.listHot.total = data.totalRecords;
            state.listHot.list = state.listHot.list.concat(data.list);
        },
        FETCH_HOUSE_HOT_REGION(state,{data}){
            state.region = data;
        },
        FETCH_HOUSE_HOT_SYSDICT(state,{data}){
            state.sysdict = data.list.slice(0,3);
        },
        FETCH_HOME_BANNER(state,{data}){
            state.banner = data.list;
        },
        RESET(state){
            state.listHot={total:"",list:[]};
        }
    },
    actions: {
         FETCH_LIST_CITY({commit,dispatch}, context){
           return fetch("/homePage/listcity",{}, context).then(res=>{
               if(res.code == 0){
                   commit("FETCH_LIST_CITY",res);
                   return dispatch('FETCH_HOUSE_HOT',context);
               }
           })
        },
        FETCH_HOUSE_HOT({commit,dispatch}, context){
            return fetch("/homePage/listhot",{longitude:context.longitude,latitude:context.latitude,curPage:1,pageSize:10,},context).then(res=>{
                if(res.code == 0){
                    commit("FETCH_HOUSE_HOT",res);
                    let region = dispatch("FETCH_HOUSE_HOT_REGION",context);
                    let sysdict = dispatch("FETCH_HOUSE_HOT_SYSDICT",context);
                    let banner = dispatch("FETCH_HOME_BANNER",context);
                    return  Promise.all([region,sysdict,banner]);
                }
            })
        },
        FETCH_HOUSE_HOT_REGION({commit}, context){
            return fetch("/homePage/hotRegion",{module:"hotRegion",cityId:context.curCity.id},context).then(res=>{
                if(res.code == 0){
                    commit("FETCH_HOUSE_HOT_REGION",res);
                }
            })
        },
        FETCH_HOUSE_HOT_SYSDICT({commit}, context){
            return fetch("/homePage/sysdict",{type:109},context).then(res=>{
                if(res.code == 0){
                    commit("FETCH_HOUSE_HOT_SYSDICT",res);
                }
            })
        },
        FETCH_HOME_BANNER({commit},context){
            return fetch("/homePage/activitys",{curPage:1,pageSize:3,location:2},context).then(res=>{
                if(res.code == 0){
                    commit("FETCH_HOME_BANNER",res);
                }
            })
        }
    }
}





