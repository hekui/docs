/**
 * Created by chuangjia05 on 2016/12/29.
 */
import { fetch } from 'utils';

export default {
    state: {
        info:{}
    },
    mutations: {
        SET_INFO(state, data) {
            state.info = data || {};
        }
    },
    actions: {
        GET_INFO({commit}, {context, id}) {
            if (id == null) {
                return;
            }
            return fetch('/householdDetail/getdoorinfo', {id: id}, context).then(result => {
                if (result.code == 0) {
                    commit('SET_INFO', result.data);
                } else {
                    console.log(result.msg);
                }
            });
        }
    }
}