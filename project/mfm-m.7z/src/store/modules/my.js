
import { fetch } from "utils";

export default {
  state: {
    ctx: {}, //全局信息
    subscribeList: {curPage: 0, nextPage: 1, list: [], pageSize: 20}, // 我的订阅
  },
  mutations: {
    MY_SET(state, data){
      state[data['target']] = data.data
    },
    SET_CONTEXT(state, ctx){
      state.ctx.city = ctx.city;
    },
    SET_SUBSCRIBE_INIT(state){
      state.subscribeList.curPage = 0
      state.subscribeList.nextPage = 1
    },
  },
  actions: {
    MY_SUBSCRIBE_LIST({commit, state}, {context, params}){
      let curPage = state.subscribeList.nextPage || state.subscribeList.curPage + 1,
          pageSize = state.subscribeList.pageSize || 20;
      return fetch('/house/sublist', {
        curPage, pageSize,
      }, context || state.ctx).then(res => {
        if(res.code === 0){
          commit('MY_SET', {
            target: 'subscribeList',
            data: res.data
          })
          return Promise.resolve(res)
        }else{
          return Promise.reject(res)
        }
      }, res => {
        return Promise.reject(res)
      })
    }
  }
}