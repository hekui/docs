/**
 * Created by chuangjia05 on 2016/12/30.
 */
import { fetch } from 'utils';

export default {
    state: {
        info:{},
        history:[]
    },
    mutations: {
        SET_SEARCH(state, data) {
            state.info = data || {};
        },
        PUSH_HISTORY(state,str){
            let status = true;
            for(let i = 0 , len = state.history.length;i < len ; i++){
                if(state.history[i] == str) {
                    status = false;
                    break;
                }
            }
            if(status) state.history.unshift(str);
        },
        RESIZE_HISTORY(state){
            let history = window.localStorage.getItem("SEARCH_HISTORY");
            state.history = JSON.parse(history || "[]");
        },
        WRITE_HISTORY(state){
            window.localStorage.setItem("SEARCH_HISTORY",JSON.stringify(state.history));
        },
        DELETE_HISTORY(state,index){
            state.history.splice(index,1);
        },
        CLIENT_HISTORY(state){
            state.history.splice(0,state.history.length);
        }
    },
    actions: {
        GET_SEARCH({commit}, {context, keyword}) {
            return fetch('/searchResult/listkeyword', {keyword: keyword}, context).then(result => {
                if (result.code == 0) {
                    commit('SET_SEARCH', result.data);
                    console.log(result.data)
                } else {
                    console.log(result.msg);
                }
            });
        },
        PUSH_HISTORY({commit},str){
            commit("PUSH_HISTORY",str);
        },
        INIT_HISTORY({commit}){
            commit("RESIZE_HISTORY");
        },
        WRITE_HISTORY({commit}){
            commit("WRITE_HISTORY");
        }
    }
}