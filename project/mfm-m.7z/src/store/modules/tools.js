function clearUserInfo({
  commit, res
}){
  if(res && commit && res.code == 1014){
    setTimeout(function(){
      commit('ACCOUNT_SET', {
        target: 'userInfo',
        data: {}
      })
    }, 500)
  }
}

export default {
  clearUserInfo,
}