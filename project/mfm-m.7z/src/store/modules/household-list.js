/**
 * Created by chuangjia05 on 2016/12/30.
 */
import { fetch } from 'utils';

export default {
    state: {
        info:{list: []},
        type:{},
        ctx:{},
        length:-1
    },
    mutations: {
        SET_HOUSEHOLD_LIST(state,{data, code, msg}) {
            if (code == 0) {
                state.info = data || {};
                state.length == -1 && (state.length = state.info.list.length);
            } else {
                console.log(msg);
            }
        },
        ADD_HOUSEHOLD_LIST(state, {data, code, msg}) {
            if (code == 0) {
                state.info.list = state.info.list.concat(data.list || []);
            } else {
                console.log(msg);
            }
        },
        SET_HOUSEHOLD_TYPE(state, {data, code, msg}) {
            if (code == 0) {
                state.type = data || {};
            } else {
                console.log(msg);
            }
        },
        SET_CONTEXT(state, ctx){
            state.ctx.city = ctx.city;
            state.ctx.params = ctx.params;
        }
    },
    actions: {
        GET_HOUSEHOLD_LIST({commit}, {context, houseId,dwellingSize,name}) {
            if (houseId == null) {
                return;
            }
            return Promise.all([
                fetch('/householdDetail/listdoor', {houseId: houseId,dwellingSize:dwellingSize,name:name}, context),
                fetch('/householdDetail/gethousestype', {houseId: houseId}, context)
            ]).then(result => {
                commit('SET_HOUSEHOLD_LIST',result[0] || {});
                commit('SET_CONTEXT', context);
                commit('SET_HOUSEHOLD_TYPE', result[1] || {});
            });
        }
    }
}