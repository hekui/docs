import Vue from 'vue';
import Vuex from 'vuex';
import modules from './modules';
Vue.use(Vuex)
export default function createStore(){
	return new Vuex.Store({
		modules: modules,
		state: {
			cityCode: "cd",
			routeStatus: false,
			routerTransition: 'fade',
			scrollPosition: {
				x: 0,
				y: 0
			},
		},
		mutations: {
			SET_CITY(state, city) {
				state.cityCode = city.curCity.code;
				state.city = city;
			},
			SET_CITY_CODE(state, city_code) {
				state.cityCode = city_code;
			},
			CHANGE_CITY(state, city) {
				state.city.curCity = city;
				state.cityCode = city.code;
			},
			FETCH_LIST_CITY(state, result) {
				state.listCity = result;
			},
			SET_ROUTE_STATUS(state, status) {
				state.routeStatus = status;
			},
			SET_ISSHOWNAV(state, isShowNav) {
				state.isShowNav = isShowNav;
			},
			SET_TRANSITION(state, routerTransition) {
				state.routerTransition = routerTransition;
			},
			SET_SCROLL_POSITION(state, scroll) {
				state.scrollPosition = scroll;
			}
		},
		actions: {
			SET_HIDENAV({commit}, isShowNav) {
				commit('SET_ISSHOWNAV', isShowNav);
			},
		}
	})
}