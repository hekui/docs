import Vue from 'vue'
import VueRouter from 'vue-router'
import pages from './pages'
import helper from './utils/helper';
Vue.use(VueRouter);
export default function createRouter (config){
	let key
	const router = new VueRouter({
		mode: 'history',
		...eachRoutes(pages, config)
	});
	for (key in config) {
		router[key] && router[key](config[key])
	}
	return router;
}

function factoryComponent(vm, config) {
	return {
		path: helper.isNoCityPage(vm.route.path) ? vm.route.path : `/:city${vm.route.path}`,
		component: {
			name: `${vm.name.toLowerCase() || ""}-component`,
			preFetch: vm.preFetch,
			render: (h) => {
				return h(vm);
			}
		},
		meta: {
			title: vm.route.title || "",
		},
		...vm.route.config
	}
}

function eachRoutes(routeList, config) {
	let routes = [],
		key;
	for (key in routeList) {
		routes.push({
			...factoryComponent(routeList[key], config)
		});
	}
	return {
		routes: routes
	};
}