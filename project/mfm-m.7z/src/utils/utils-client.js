import 'whatwg-fetch';
const fetchUtil = self.fetch;
export const fetch = (url, body, {city})=> {
	if(!(/http(s)\:\/\//.test(url))){
		url = `/${city}`+ url
	}

	let param = {
		credentials: "include",
		// timeout: 3000,
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
	}
	if(body.method === 'get'){
		param.method = body.method
	}else{
		param.method = body.method || 'post'
		delete body.method
		param.body = JSON.stringify(body)
	}

	return fetchUtil(url, param).then(res => {
		return res.json();
	}).catch(e => {
		console.log('error in fetch at utils-server.js：', e);
		return e;
	});
};