import fetchUtil from 'node-fetch';
import {localhost} from './../../config/sys.config';
export const fetch = (url, body, {req, city})=> {
	// console.log('fetch url:', localhost + `/${city}` + url, ' - ', JSON.stringify(body));
	return fetchUtil(localhost + `/${city}` + url, {
		method: "POST",
		body: JSON.stringify(body),
		// timeout: 3000,
		headers: {
			'cookie': req.headers.cookie,
			'Content-Type': 'application/json'
		}
	}).then(res => {
		return res.json();
	}).catch(e => {
		console.log('fetch url:', localhost + `/${city}` + url, ' - ', JSON.stringify(body));
		console.log('error in fetch at utils-server.js：', e);
		return e;
	});
};