import { fetch } from 'utils';
function initShare(){
  var ssid = window.localStorage.CJSSID || "",
  shareData = {
    title: '买房吗',
    desc: '一个有温度的购房平台',
    link: 'http://m.maifangma.com/',
    imgUrl: 'http://m.maifangma.com/images/logo-b.png'
  }
  // console.log('init share')
  fetch("https://zt.maifangma.com/wxsso/sign", {
    method: 'get',
    ssid: ssid
  }, {}).then(res => {
    // alert(JSON.stringify(res))
    if (res.code == 200) {
      if (res.ssid) {
        window.localStorage.CJSSID = res.ssid
      }
      var sign = res.sign
      sign.jsApiList = [
        'onMenuShareTimeline',
        'onMenuShareAppMessage',
        'onMenuShareQQ',
        'onMenuShareWeibo',
        'onMenuShareQZone'
      ]

      wx.config(sign)
      wx.ready(function() {
        wx.onMenuShareTimeline(shareData); // 分享给朋友
        wx.onMenuShareAppMessage(shareData); // 分享到朋友圈
        wx.onMenuShareQQ(shareData); // 分享到QQ
        wx.onMenuShareWeibo(shareData); // 分享到腾讯微博
        wx.onMenuShareQZone(shareData); // 分享到QQ空间
      })
      wx.error(function(res) {
        console.log(res.errMsg);
      });
    }
  })
}
function hasEmoji(str = ''){
  return new RegExp(/\ud83d[\udc00-\ude4f\ude80-\udfff]/g).test(str)
}

export default {
  initShare,
  hasEmoji,
}