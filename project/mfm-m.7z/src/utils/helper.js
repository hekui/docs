export default {
    isNoCityPage(pathStr) {
        let pagePaths = ['/about', '/agreement', '/download'];
        return pagePaths.indexOf(pathStr) > -1;
    }
}