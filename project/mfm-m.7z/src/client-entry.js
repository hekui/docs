import Vue from 'vue'
import {createApp} from './app';
import helper from './utils/helper';
import ProgressBar from './components/ProgressBar.vue'

// global progress bar
const bar = Vue.prototype.$bar = new Vue(ProgressBar).$mount()
document.body.appendChild(bar.$el)


const {
	app,
	store,
	util,
} = createApp({
	routeConfig: {
		beforeEach: (toRoute, redirect, next) => {
			if (window["__INITIAL_STATE__"] && (next(true), 1)) return;
			let routeStatus = store.state.routeStatus;
			if (!routeStatus && toRoute.params.city != store.state.cityCode && !helper.isNoCityPage(toRoute.path)) {
				next(`/${store.state.cityCode + toRoute.path}`);
				return;
			}
			let context = {
				path: toRoute.path,
				city: toRoute.params.city,
				curCity: store.state.city.curCity,
				params: toRoute.params,
				query: toRoute.query,
			};
			store.commit("SET_CITY_CODE", context.city);
			bar.start()
			return Promise.all(toRoute.matched.map(item => {
				if (item.components.default.preFetch && !routeStatus) return item.components.default.preFetch({
					store,
					context
				});
			})).then(() => {
				bar.finish()
				next(true);
			});
		},
		afterEach(toRoute) {
			clientTitle(toRoute.meta.title);
			if (window["__INITIAL_STATE__"]) return;
			if (store.state.routeStatus) util.backReplaceState();
		}
	}
});
store.replaceState(window.__INITIAL_STATE__);
delete window["__INITIAL_STATE__"];
// let resource = document.getElementById("resource");
// resource.parentNode.removeChild(resource);
// get the initialstate from server-rendering.
app.$mount('#app');

function clientTitle(title) {
	if(!title)return;
	let iframe = document.createElement('iframe');
	document.title = title;
	iframe.style.visibility = 'hidden';
	iframe.style.width = '1px';
	iframe.style.height = '1px';
	iframe.src = '/favicon.ico'; // 这里
	iframe.onload = function () {
		setTimeout(function () {
			document.body.removeChild(iframe);
		}, 0);
	};
	document.body.appendChild(iframe);
}


//cookie 方法
window.Cookie = {
	set: function (name, value, expires, path, domain) {
		if (expires) {
			expires = new Date(new Date().getTime() + expires * 1000);
		}
		document.cookie = name + "=" + encodeURIComponent(value) + ((expires) ? "; expires=" + expires.toGMTString() : "") + ((path) ? "; path=" + path : "; path=/") + ((domain) ? ";domain=" + domain : "");
	},
	get: function (name) {
		var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
		if (arr !== null) {
			return decodeURIComponent(arr[2]);
		}
		return null;
	},
	clear: function (name, path, domain) {
		if (this.get(name)) {
			document.cookie = name + "=" + ((path) ? "; path=" + path : "; path=/") + ((domain) ? "; domain=" + domain : "") + ";expires=Fri, 02-Jan-1970 00:00:00 GMT";
		}
	}
};

//获取参数
function getQueryParams() {
	let qs = document.location.search;
	qs = qs.split('+').join(' ');
	var params = {},
		tokens,
		re = /[?&]?([^=]+)=([^&]*)/g;
	while (tokens = re.exec(qs)) {
		params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
	}
	return params;
}

(function () {
	let query = getQueryParams();
	if (query.chnType) {
		Cookie.set('chnType', query.chnType, 2592000);
	}
})()

//版本号
// console.log(VERSION);