<style lang="less" src="./style.less" scoped></style>
<template src="./page.html"></template>

<script>
    export default {
        name: 'agreement',
        route: {
            path: "/agreement",
            title: "用户协议"
        },
        preFetch({store, context}) {
            store.dispatch('SET_HIDENAV', true);
        },
    }
</script>