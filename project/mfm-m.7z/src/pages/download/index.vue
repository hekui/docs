<template src="./download.html"></template>
<style lang="less" src="./download.less" scoped></style>
<script src="./download.js"></script>