export default {
    name: 'download',

    route: {
        path: '/download',
        title: '买房吗APP下载'
    },
    preFetch({
        store,
        context
    }) {
        store.dispatch('SET_HIDENAV', true);
    },
    mounted() {
        //挂载时跳 APP
        let schemeUrl = 'maifangma://welcome';
        if (this.isIos()) {
            // let aLink = document.createElement("a");
            // aLink.href = schemeUrl;
            // document.body.appendChild(aLink);
            // aLink.click();
        } else {
            var ifr = document.createElement('iframe');
            ifr.src = schemeUrl;
            ifr.style.display = 'none';
            document.body.appendChild(ifr);
        }
    },
    methods: {
        download() {
            let appMarketType = (this.isIos() || this.$util.isWechat()) ? 0 : 1;
            this.$util.fetch('/houseDetail/download', {
                appMarketType: appMarketType,
                productType: 1
            }).then(result => {
                if (result.code == 0) {
                    let data = result.data || {};
                    location.href = data.url;
                }
            });
        },

        isIos() {
            let UA = window.navigator.userAgent.toLowerCase();
            return UA && /iphone|ipad|ipod|ios/.test(UA);
        }
    }
}