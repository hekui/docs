import { CommentItem, Scroller } from '../../components';
import { mapState } from 'vuex';

export default {
    name: 'comment',
    route: {
        path: '/comment/:houseId',
        title: '全部评价'
    },
    components: { CommentItem, Scroller },

    preFetch({store, context}) {
        let params = {
            houseId: context.params.houseId,
            page: 1
        }
        return store.dispatch('GET_LIST_COMMENT', {context, params});
    },

    data() {
        return {
            page: 1
        }
    },

    mounted() {
        this.$refs.cSroller.reset(this.listInfo.hasNext ? 0 : 1);
    },

    computed: {
        ...mapState({
            listInfo: state => state.comment.listInfo
        })
    },

    methods: {
        refresh() {
            this.page = 1;
            return this.getList(true);
        },

        loadMore() {
            if (this.listInfo.list.length == this.listInfo.total) {
                return Promise.resolve(1);
            }
            this.page++;
            return this.getList();
        },

        getList(isRefresh) {
            return this.$util.fetch('/houseDetail/getComments', {
                houseId: this.$route.params.houseId,
                curPage: this.page || 1,
                pageSize: 10
            }).then(result => {
                if (isRefresh) {                    
                    this.$store.commit('SET_LISTINFO_COMMENT', result || {});
                } else {
                    this.$store.commit('ADD_LISTINFO_COMMENT', result || {});                    
                }
                if (result && result.data && !result.data.hasNext) {
                    return 1;
                }
            });
        },

        goToDownload() {
            this.$util.push('/download');
        }
    }
    
}