<template>
    <div class="comment-page">        
        <div class="comment-wrapper">
            <scroller :onRefresh="refresh" :onLoadMore="loadMore" ref="cSroller">
                <comment-item v-for="(item, key) in listInfo.list" :key="key" :data="item" :isBottomBorder="true"></comment-item>
            </scroller>
        </div>
        <div class="download">
            <div>想吐槽点什么？立即下载买房吗app</div>
            <a @click="goToDownload" class="download-btn">立即下载</a>
        </div>
    </div>
</template>

<style lang="less" src="./comment.less" scoped></style>

<script src="./comment.js"></script>