/**
 * Created by xiongyan on 2016/12/22.
 */
import {Icon} from '../../components';
import {houseList} from '../../components';
import {BottomLayer} from '../../components';
import { mapState } from 'vuex';
export default {
    name: 'SearchResult',
    route: {
        path: '/searchresult/:keyword',
        title: '搜索结果'
    },
    components: {Icon,houseList,BottomLayer},
    preFetch({store, context}) {
        let keyword =  context.params.keyword == "_" ? "": context.params.keyword;
        let params = {
            keyword: keyword,
            page: 1
        };
        return store.dispatch('GET_SEARCH_RESULT', {context,params});
    },
    data() {
        return {
            page:1
        }
    },
    computed: {
        ...mapState({
            info: state => state.searchResult.info,
            scrollPosition: state=>state.scrollPosition
        })
    },
    mounted(){
        this.$refs.list.resizeScroll(this.info.hasNext == true ? undefined:1);
        this.$refs.list.setScrollPosition(this.scrollPosition.x, this.scrollPosition.y);
    },
    methods:{
        loadMore(callback) {
            if (this.info.list.length == this.info.total) {
                return Promise.resolve(1);
            }
            this.page++;
            return this.getResult().then(result=>{
                callback(result);
            });
        },
        getResult(isRefresh) {
            return this.$util.fetch('/searchResult/getSearchResult', {
                keyword: this.$route.params.keyword,
                curPage: this.page || 1,
                pageSize: 10
            }).then(result => {
                if (isRefresh) {
                    this.$store.commit('SET_SEARCH_RESULT', result || {});
                } else {
                    this.$store.commit('ADD_SEARCH_RESULT', result || {});
                    if (!result.data.hasNext) {
                        return 1;
                    }
                }
            })
        },
        setScrollPosition(){
            this.$util.setScrollPosition(this.$refs.list.getScrollPosition());
        }
    }
}