<template src="./page.html"></template>
<style lang="less" src="./style.less" scoped></style>
<script src="./script.js"></script>
