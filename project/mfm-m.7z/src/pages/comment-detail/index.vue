<template src="./detail.html"></template>
<style lang="less" src="./detail.less" scoped></style>
<script src="./detail.js"></script>