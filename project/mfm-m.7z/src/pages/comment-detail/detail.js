import { CommentItem, Scroller } from '../../components';
import { mapState } from 'vuex';

export default {
    name: 'comment-default',
    route: {
        path: '/commentdetail/:estimateId',
        title: '评价详情'
    },
    components: { CommentItem, Scroller },

    data() {
        return {
            page: 1
        }
    },

    preFetch({store, context}) {
        let params = {
            estimateId: context.params.estimateId,
            page: 1
        }
        return store.dispatch('GET_REPLY_COMMENT', {context, params});
    },

    mounted() {
        this.$refs.cdSroller && this.$refs.cdSroller.reset(this.reply.hasNext ? 0 : 1);
    },

    computed: {
        ...mapState({
            reply: state => state.comment.reply,
            critic: state => state.comment.critic
        })
    },

    methods: {
        refresh() {
            this.page = 1;
            return this.getList(true);
        },

        loadMore() {
            if (this.reply.list.length == this.reply.total) {
                return Promise.resolve(1);
            }
            this.page++;
            return this.getList();
        },

        getList(isRefresh) {
            return this.$util.fetch('/houseDetail/getReply', {
                estimateId: this.$route.params.estimateId,
                curPage: this.page || 1,
                pageSize: 10
            }).then(result => {
                if (isRefresh) {                    
                    this.$store.commit('SET_REPLY_COMMENT', result || {});
                } else {
                    this.$store.commit('ADD_REPLY_COMMENT', result || {});                                      
                }
                if (result && result.data && !result.data.hasNext) {
                    return 1;
                } 
            });
        },

        goToDownload() {
            this.$util.push('/download');
        }
    }
}