import {
    Icon,
    Carousel,
    Scroller,
    FooterInfo,
} from '../../components';
export default {
    name: 'Home',
    route: {
        path: '/',
        title: '成都新房，尽在买房吗'
    },
    data() {
        return {
            isShow: true,
            page: 1,
            scrollPosition: {
                top: 0,
                left: 0,
            }
        }
    },
    components: {
        Icon,
        Carousel,
        Scroller,
        FooterInfo,
    },
    computed: {
        cityList() {
            return this.$store.state.homePage.cityList;
        },
        listHot() {
            return this.$store.state.homePage.listHot;
        },
        region() {
            let region = this.$store.state.homePage.region;
            region = region.hotRegion ? region.hotRegion.slice(0, 3) : {};
            return region;
        },
        sysdict() {
            return this.$store.state.homePage.sysdict;
        },
        curCity() {
            return this.$store.state.city.curCity;
        },
        imgList() {
            return this.$store.state.homePage.banner;
        },
        carouselOpts() {
            return {
                auto: true,
                loop: true,
                field: 'filePath',
                haveDot: true,
                urlField: 'linkUrl'
            };
        }
    },
    mounted(){
        console.log('userInfo', this.$store.state.account.userInfo)
    },
    methods: {
        routeGo(url) {
            this.$util.push(url);
        },
        route(id) {
            this.$util.push(`/cate/${id}`);
        },
        houseDetails(id) {
            this.$util.push(`/housedetails/${id}`);
        },
        selectCity() {
            this.$util.push(`/location`);
        },
        hideFooter() {
            this.isShow = false;
        },
        loadMore() {
            if (this.listHot.list.length == this.listHot.total) {
                return Promise.resolve(1);
            }
            this.page++;
            return this.getList();
        },
        getList() {
            let curCity = this.$store.state.city.curCity;
            return this.$util.fetch('/homePage/listhot', {
                longitude: curCity.longitude,
                latitude: curCity.latitude,
                curPage: this.page || 1,
                pageSize: 10
            }).then(result => {
                this.$store.commit('FETCH_HOUSE_HOT', result || {});
                if (result && result.data && !result.data.hasNext) {
                    return 1;
                }
            });
        },
        search() {
            this.$util.push(`/search`);
        },
        download() {
            this.$util.push(`/download`);
        },
        scroll(position){
            this.scrollPosition = position;
        }
    },
    preFetch({
        store,
        context
    }) {
        store.commit("RESET");
        return store.dispatch("FETCH_LIST_CITY", context);
    },
}