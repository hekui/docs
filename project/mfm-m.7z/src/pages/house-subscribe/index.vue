<style lang="less" src="./styles.less"></style>
<template src="./page.html"></template>
<script src="./script.js"></script>