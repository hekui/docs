import {
    mapState
} from 'vuex';
import { Toast } from './../../components';
const phoneExp = /^1\d{10}$/;
const codeExp = /^\d{6}$/;
const userNameExp = /^[a-zA-Z\u4e00-\u9fa5]+$/;
const regEn = /(\d|[`~!@#$%^&*()_+<>?:"{},.\/;'[\]])/im,
    regCn = /(\d|[·！#￥（——）：；“”‘、，|《。》？、【】[\]])/im;


export default {
    name: 'housesubscribe',
    route: {
        path: '/housesubscribe/:houseId',
        title: '订阅动态'
    },
    data() {
        return {
            legend: [],
            subscribeDialogVisible: false,
            subscribeResultDialogVisible: false,
            unsubscribeDialogVisible: false,
            subForm: {
                userName: "",
                sex: "0",
                phone: "",
                verifyCode: "",
                imgCaptcha: "",
                checked: true
            },
            canSend: true,
            isSend: false,
            seconed: 60, // 多少秒后可发送短信
            timer: null,

            isSubscribeNews: true, // 获取订阅状态，调用 后台接口
            isValid: false, 
            houseId: this.$route.params.id,
            isMessage: false,
            message: '',
            subTitle: false, //切换title 效果
            // userInfo: {
            //     account: true
            // },
        }
    },
    preFetch({ store, context }) {
        let houseId = context.params.houseId || '808882104573100032';
        return store.dispatch('GET_HOUSE_DETAIL', {
            context,
            houseId: houseId
        });
    },
    computed: {
        ...mapState({
            info: state => state.houseDetail.info,
            userInfo: state => state.account.userInfo,
        })
    },
    methods: {
        housedetails(id){
            // this.$router.go(-1)
            this.$router.push(`/housedetails/${id}`); 
        },
        mysubscribe(){
            this.$util.push(`/mysubscribe/`); 
        },
        inputFocus(){
            this.subTitle = true;
        },
        inputBlur(){
            this.subTitle = false;
        },
        initSend() {
            clearInterval(this.timer);
            this.canSend = true;
            this.seconed = 60;
            this.isSend = false;
        },
        validName() {
            let user = this.subForm.userName;
            return userNameExp.test(user)
        },
        validPhone() {
            return phoneExp.test(this.subForm.phone);
        },
        validCode() {
            return codeExp.test(this.subForm.verifyCode);
        },
        sendCode() {
            if(!this.validPhone()){
                this.$refs.toast.pos();
                this.message = false;
                this.Toast('手机号格式错误');
                return false
            }
            if(!this.canSend){
                return false;
            }
            this.canSend = false
            this.$store.dispatch('ACCOUNT_SENDCODE', {
                params: {
                    account: this.subForm.phone,
                    captcha: this.subForm.imgCaptcha,
                    type: 9
                },
                context: {
                    city: this.$route.params.city
                }
            }).then(res => {
                this.subForm.verifyCode = ''
                clearInterval(this.timer)
                this.canSend = false
                this.isSend = true
                this.timer = setInterval(function(){
                    this.seconed --
                    if(this.seconed === 0){
                        this.initSend()
                    }
                }.bind(this), 1000)
            }, res => {
                this.$refs.toast.pos();
                this.message = false;
                this.Toast('验证码发送失败，请稍后重试');
                this.initSend()
            })
        },
        submitUnfilledForm() {
            let username = this.subForm.userName;
            if(username.trim() == '' || !this.validName()){
                this.$refs.toast.pos();
                this.message = false;
                this.Toast('仅支持5个字以内的中文或英文字符');
                return false
            }
            // 请勾选买房吗用户使用协议
            // console.log('调用登录接口1')

            // 订阅 - 已登陆
            this.$store.dispatch("HOUSEDETAIL_SUBSCRIBE_LOGINED_POST", {
                params: {
                    userName: username.trim(),
                    sex: this.subForm.sex,
                    sourceType: -3,
                    houseId: this.info.id
                },
                context: {
                    city: this.$route.params.city
                }
            }).then(res => {

                this.subscribeResultDialogVisible = true;
                this.subForm = {
                    userName: "",
                    sex: "0",
                }
                this.isSubscribeNews = true
                
            }, res => {
                console.log("reject res", res);
                if (res.code == 1035) { // 验证码不对
                    this.$refs.toast.pos();
                    this.message = false;
                    this.Toast(res.msg);
                    return false
                } else {
                    this.$refs.toast.pos();
                    this.message = false;
                    this.Toast(res.msg);            
                }
                // 请勾选买房吗用户使用协议
                // console.log('调用登录接口1')

                // 订阅 - 已登陆
                this.$store.dispatch("HOUSEDETAIL_SUBSCRIBE_LOGINED_POST", {
                    params: {
                        userName: this.subForm.userName,
                        sex: this.subForm.sex,
                        sourceType: -6,
                        houseId: this.info.id
                    },
                    context: {
                        city: this.$route.params.city
                    }
                }).then(res => {

                    this.subscribeResultDialogVisible = true;
                    this.subForm = {
                        userName: "",
                        sex: "0",
                    }
                    this.isSubscribeNews = true
                    
                }, res => {
                    console.log("reject res", res);
                    if (res.code == 1035) { // 验证码不对
                        this.$refs.toast.pos();
                        this.message = false;
                        this.Toast(res.msg);
                        return false
                    } else {
                        this.$refs.toast.pos();
                        this.message = false;
                        this.Toast(res.msg);            
                    }
                })
            })
        },
        submitSubForm() {
            let username = this.subForm.userName;
            if( this.subForm.userName && this.subForm.phone && this.subForm.verifyCode){
                if(username.trim() == '' || !this.validName()){
                    this.$refs.toast.pos();
                    this.message = false;
                    this.Toast('仅支持5个字以内的中文或英文字符');
                    return false
                }
                if(!this.validPhone()){
                  this.$refs.toast.pos();
                  this.message = false;
                  this.Toast('手机号格式错误');
                  return false
                }
                if(!this.validCode()){
                  this.$refs.toast.pos();
                  this.message = false;
                  this.Toast('验证码错误');
                  return false
                }
                // 请勾选买房吗用户使用协议
                
                var params = {
                    phone: this.subForm.phone,
                    userName: username.trim(),
                    verifyCode: this.subForm.verifyCode,
                    sex: this.subForm.sex,
                    sourceType: -3,
                    houseId: this.info.id
                }

                // console.log('调用登录接口2', params)

                // 订阅 - 未登陆
                this.$store.dispatch("HOUSEDETAIL_SUBSCRIBE_UNLOGINED_POST", { params ,
                    context: {
                        city: this.$route.params.city
                    }
                }).then(result => {
                    // 成功 清空表单数据
                    this.initSend();
                    this.subscribeResultDialogVisible = true;
                    this.subForm = {
                        userName: "",
                        sex: "0",
                        phone: "",
                        verifyCode: "",
                        imgCaptcha: "",
                        checked: true
                    }
                    this.isSubscribeNews = true

                }, res => {
                    if (res.code == 1035) { // 验证码不对
                        this.$refs.toast.pos();
                        this.message = false;
                        this.Toast('验证码不正确');
                        return false
                    } else {
                        this.initSend();
                        this.subForm = {
                            userName: "",
                            sex: "0",
                            phone: "",
                            verifyCode: "",
                            imgCaptcha: "",
                            checked: true
                        }
                        this.isSubscribeNews = false // 失败弹窗
                        this.subscribeResultDialogVisible = true;
                    }
                });
            }
        },
        clearValue(event) {
            if(event == 'userName'){
                this.subForm.userName = ''
            }else if(event == 'phone'){
                this.subForm.phone = ''
            }else if(event == 'verifyCode'){
                this.subForm.verifyCode = ''
            }
        },
        Toast(msg){
            this.isMessage = true;
            this.message = msg
            setTimeout(()=>{
                this.isMessage = false;
            },2000)
        },
    },
    components: {
        Toast,
    },
}
