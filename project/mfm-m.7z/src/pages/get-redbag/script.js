import {Icon, Toast} from './../../components';
export default {
    name: 'getRedBag',
    data(){
        return {
            isShow: false,
            username: "",
            phone: "",
            message: "",
        }
    },
    route: {
        path: '/getredbag/:housesId/:name',
        title: '领取红包'
    },
    components: {Icon, Toast},
    computed: {
        redHouseName(){
            return this.$route.params.name;
        }
    },
    methods: {
        openProcess(){
            this.isShow = true;
        },
        closeProcess(){
            this.isShow = false;
        },
        submit(){
            let validataObj = new validate(),
                username = validataObj.getResult(this.username || ""),
                phone = validataObj.getResult(this.phone || ""),
                msg = Object.assign(username, phone);
            this.$refs.toast.pos();
            this.message = false;
            if (!msg.state) {
                let params = Object.assign({}, {
                    userName: this.username,
                    phone: this.phone
                }, this.$route.params);
                this.$store.dispatch("FETCH_USER_INFO", params).then(res=> {
                    let msg = res.code === 0 ? "提交成功!<br/><p style='text-align: left;padding: 0.1rem; line-height: 20px;'>买房吗客服将会尽快与您取得联系</p>" : res.msg
                    this.Toast(msg);

                })
            } else {
                this.Toast(msg.msg);
            }
        },
        Toast(msg){
            setTimeout(function(){
                this.message = msg;
            }.bind(this), 10)
        },
    }
}

class validate {
    constructor() {
        this.valiCofig = {
            required: {
                reg: /\S+/,
                msg: "输入框不能为空"
            },
            phone: {
                reg: /^1(3|4|5|7|8)\d{9}$/,
                msg: "手机号码错误"
            }
        }
    }

    getResult(val) {
        let filed = this.valiCofig;
        return (()=> {
            let result = {state: false}
            for (let o in filed) {
                let tempObj = filed[o];
                if (!result.state && !tempObj.reg.test(val)) {
                    result.state = true;
                    result.msg = filed[o].msg;
                }
            }
            return result;
        })()

    }
}

