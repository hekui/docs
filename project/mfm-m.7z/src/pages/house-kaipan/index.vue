<template>
  <div class="kaipan-page">
    <div class="parent box-flex flex-column" :class="{fixed:status!=1}">
      <div class="input-search box-flex flex-row">
          <div class="input flex-1">
            <div class="search-group">
              <icon name="search"></icon>
              <form action="" onSubmit="return false;">
              <input type="search" placeholder="请输入楼盘名称/区域搜索" v-model="keyword"  @keyup.enter="search" ref="searchInput">
              </form>
              <span class="css_sprites clear-input" v-if="keyword" @click="clearSearch"></span>
            </div>
          </div>
          <a class="css_sprites home-button" @click="jumpPage('/')"></a>
          <!-- <a @click="jumpPage('/')" class="home" >
              <icon name="home"></icon>
          </a> -->
      </div>
    </div>
    <houseList :info="houseKaipanList" v-on:loadMore="loadMore" v-on:jumpDetails="setScrollPosition" ref="list"></houseList>
  </div>
</template>
<script>
import {
	HouseSearch,
	houseList,
} from './../../components';
import {
	mapState
} from 'vuex';
export default {
  name: 'houseKaipan',
  route: {
    path: '/housekaipan/',
    title: '即将开盘的成都新房'
  }, 
  data(){
    return {
      keyword: ''
    }
  },
	computed: {
		...mapState({
			houseKaipanList: state => state.houseSearch.houseKaipanList,
      scrollPosition: state => state.scrollPosition,
      status: state=>state.houseSearch.status,
		})
  },
	preFetch({store, context}) {
    store.commit('SET_KAIPAN_INIT')
		return store.dispatch("HOUSE_KAIPAN_LIST", {
      ctx: context,
      keyword: ''
    });
  },
	mounted() {
    console.log('this.$refs.list', this.$refs.list)
    if(this.$refs.list){
      this.$refs.list.setScrollPosition(this.scrollPosition.x, this.scrollPosition.y);
      this.$refs.list.resizeScroll(this.houseKaipanList.hasNext == true ? undefined : 1);
    }
  }, 
  methods: {
		loadMore(callback) {
			this.$store.dispatch("HOUSE_KAIPAN_LIST", {
        callback,
        keyword: this.keyword    
			});
    },
    clearSearch(){
      this.keyword = ''
      this.search()
    },
    search(){
      console.log('search')
      this.$store.commit('SET_KAIPAN_INIT')
      this.$store.dispatch("HOUSE_KAIPAN_LIST", {
        keyword: this.keyword,
        callback: status => this.$refs.list.resizeScroll(status)
      });
      this.$refs.searchInput.blur();
    },
		setScrollPosition() {
			this.$util.setScrollPosition(this.$refs.list.getScrollPosition());
    },
    jumpPage(path){
			// this.$emit('jump', path);
			this.$util.push(path);
		},
  },
  components: {
	  HouseSearch,
		houseList,
  },
}
</script>
<style lang="less">
.kaipan-page{
  .box-flex {
    display: flex;
  }

  .flex-column {
    flex-direction: column;
  }

  .flex-row {
    flex-direction: row;
  }

  .flex-wrap {
    flex-wrap: wrap;
  }

  .flex-1 {
    flex: 1;
  }

  .input-search {
    padding: .08rem .2rem;
    background: #F9F9F9;
    .home-button{
      width: 0.21rem; height: 0.2rem;
      background-position: -3.34rem -3.39rem;
      margin: .06rem 0 0 .2rem;
      &:active{
        background-position: -3.64rem -3.39rem;
      }
    }
    // .home {
    //   width: 40px;
    //   padding-top: 4px;
    //   line-height: 30px;
    //   font-size: 0.14rem;
    //   .icon-home{
    //     font-size: 0.28rem;
    //     margin-left: 0.1rem;
    //     color: #666;
    //   }
    // }
  }

}
</style>
