<template>
  <div class="result-detail" :class="{ 'focus': fixBg}">
    <div class="header">
      <div class="nav">
        <div class="back" @click="back">
            <div class="css_sprites back-button"></div>
        </div>
        <div class="title">摇号结果</div>
        <div class="css_sprites home-button" @click="home"></div>
      </div>
      <div class="h1">{{houseDetail.housesName}}</div>
      <div class="search-box border-bottom-line">
        <div class="search-wrapper">
          <div class="search-group">
            <icon name="search"></icon>
            <form action="" onSubmit="return false;">
            <input type="search" placeholder="请输入公正预售编码或购房登记号" v-model="keyword" @focus="inputFocus" @blur="inputBlur" @keyup.enter="search" ref="searchInput">
            </form>
            <span class="css_sprites clear-input" v-if="keyword" @click="clearSearch"></span>
          </div>
        </div>
        <div class="search-button" @click="search">搜索</div>
      </div>
    </div>
    <div class="body">
      <!-- <Scroller v-if="lotteryDetail.list.length > 0" :on-load-more="loadMore" ref="scroll">
        <div class="result-list border-bottom-line" v-for="(item, index) in lotteryDetail.list" :key="index">
          <p>选房顺序：<span>{{lotteryType[item.resultType]}}</span><span class="order">{{item.selectOrder}}</span></p>
          <p>公正预售编码： <span>{{item.notarizeNumber}}</span></p>
          <p>购房登记号：<span>{{item.registNumber}}</span></p>
        </div>
      </Scroller> -->
      <!-- <div class="result-content" v-if="lotteryDetail.list.length > 0">
        <div class="result-list border-bottom-line" v-for="(item, index) in lotteryDetail.list" :key="index">
          <p>选房顺序：<span>{{lotteryType[item.resultType]}}</span><span class="order">{{item.selectOrder}}</span></p>
          <p>公正预售编码： <span>{{item.notarizeNumber}}</span></p>
          <p>购房登记号：<span>{{item.registNumber}}</span></p>
        </div>
      </div> -->
      
      <!-- <div class="no-result-data" v-else>
        <span class="css_sprites no-result-icon"></span>
        <p class="ts-text">暂无搜索结果</p>
      </div> -->
      <houseLotteryDetail :info="lotteryDetail" v-on:loadMore="loadMore" v-on:jumpPage="setScrollPosition" ref="list"></houseLotteryDetail>
      <div class="fix-bg" v-show="fixBg" @click="keyword = '';" ></div>
    </div>
  </div>
    

</template>
<script>
import {
	mapState
} from 'vuex';
import {
	houseLotteryDetail,
} from './../../components';
export default {
  name: "presellResult",
  route: {
    path: "/houselotterydetail/:presellId",
    title: "成都新房摇号结果"
  },
  data() {
    return {
      resultData: false,
      fixBg: false,
      keyword: '',
    };
  },
  preFetch({store, context}) {
    let presellId = context.params.presellId
    let params = {
      presellId: presellId,
      keyword: '',
    };
    store.commit('SET_LOTTERY_DETAIL_INIT')
    return Promise.all([
      store.dispatch('GET_LOTTERY_DETAIL', {context, params}),
      store.dispatch('GET_HOUSE_DETAIL_BY_PRESELLID', {context, presellId})
    ]);
  },
  computed: {
		...mapState({
      // info: state => state.houseDetail.info,
      scrollPosition: state => state.scrollPosition,
      houseDetail: state => state.presell.houseDetail,
      lotteryDetail: state => state.presell.lotteryDetail,
		})
  },
  mounted() {
    console.log('this.$refs.list', this.$refs.list)
    if(this.$refs.list){
      this.$refs.list.setScrollPosition(this.scrollPosition.x, this.scrollPosition.y);
      this.$refs.list.resizeScroll(this.lotteryDetail.hasNext == true ? undefined : 1);
    }
  }, 
  methods: {
    loadMore(callback) {
      let presellId = this.$route.params.presellId
      let params = {
        presellId: presellId,
        keyword: this.keyword,
      };
			this.$store.dispatch("GET_LOTTERY_DETAIL", {
        callback,
        params,  
			});
    },
    setScrollPosition() {
      // console.log('this.$refs.list.getScrollPosition()', this.$refs.list.getScrollPosition())
			this.$util.setScrollPosition(this.$refs.list.getScrollPosition());
    },
    clearSearch(){
      this.keyword = ''
      this.search()
    },
    search(){
      let presellId = this.$route.params.presellId
      let params = {
        presellId,
        keyword: this.keyword,
      }
      this.$store.commit('SET_LOTTERY_DETAIL_INIT')
      this.$store.dispatch('GET_LOTTERY_DETAIL', {
        params,
        callback: status => this.$refs.list.resizeScroll(status)
      })
      if(this.$refs.searchInput){
        this.$refs.searchInput.blur()
      }
    },
    inputFocus(){
      this.fixBg = true;
    },
    inputBlur(){
      this.fixBg = false;
    },
    back() {
      this.$util.back(true);
    },
    home() {
      this.$util.push(`/`);
    }
  },
  components: {
		houseLotteryDetail,
  },
};
</script>
<style lang="less">
.result-detail {
  padding-top: 1.52rem;
  .header{
    background: #F9F9F9; 
    position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;
  }
  .body{
    flex: 1; position: relative; z-index: 10;
  }
  &.focus{
    overflow: hidden;
  }
  .h1 {
    font-size: 0.18rem;
    color: #333;
    margin-top: 0.1rem;
    font-weight: 700;
    padding: 0 0.1rem;
    white-space: nowrap; 
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .search-box {
    width: 3.55rem;
    height: 0.32rem;
    line-height: 0.32rem;
    padding-top: .18rem;
    padding-bottom: .18rem;
    display: flex;
    justify-content: space-between;
    .search-wrapper{
      width: 2.9rem;
    }
    .search-button{
      width: .54rem;
      font-size: .14rem;
      text-align: center;
      background-image: linear-gradient(48deg, #FDB117  0%, #FF9733 100%);
      border-radius: 0.01rem;
      color: #fff;
      &:active{
        background-image: linear-gradient(45deg, #FF9733 0%, #FDB117 100%);
      }
    }
  }
  .result-content{
    z-index: 1;
    // position: absolute;
    width: 100%;
  }
  .result-list{
    padding: 0.1rem 0;
    .order{
      color: #FDB117
    }
    p{
      font-size: 0.14rem;
      color: #333;
      text-align: left;
      &:first-child{
        letter-spacing: 0.07rem;
      }
      &:nth-child(2){
        letter-spacing: 0;
      }
      &:last-child{
        letter-spacing: 0.028rem;
      }
      > span{
        letter-spacing: 0;
      }
    }
  }
  // background: rgba(216,216,216,0.20);
  .no-result-data {
    text-align: center;
    .no-result-icon {
      display: block;
      width: 2.02rem;
      height: 1.48rem;
      background-position: -0.05rem -1.61rem;
      margin: .5rem auto .1rem;
    }
    .ts-text {
      font-size: 0.16rem;
      font-weight: bold;
      color: #636c7b;
      margin-bottom: 0.12rem;
    }
  }
  .border-bottom-line{
    border-bottom: 0.01rem solid #ddd;
    padding-left: .1rem;
    padding-right: .1rem;
  }
  .fix-bg{
    width: 100%;
    height: 100%;
    top: 0; left: 0;
    background: rgba(0,0,0,0.40);
    position: absolute;
    z-index: 2000;
  }

}

</style>

