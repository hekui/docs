<style lang="less" src="./styles.less" scoped></style>
<template src="./page.html"></template>
<script src="./script.js"></script>