import {Icon,commDialog} from '../../components';

export default {
    name: 'Home',
    route: {
        path: '/housedynamic/:id/:name',
        title: '楼盘动态'
    },
    components: {Icon,commDialog},
    data(){
        return {isShow:false}
    },
    computed:{
        houseId(){
            return this.$route.params.id;
        },
        news(){
            return this.$store.state.houseDetail.news;
        }
    },
    methods:{
        download() {
            this.$util.push(`/download`);
        },
        openDialog(){
            this.isShow = true;
        },
        close(){
            this.isShow = false;
        }
    },
    preFetch({store,context}){
        return store.dispatch("HOUSE_DYNAMIC_LIST",context);
    },
}