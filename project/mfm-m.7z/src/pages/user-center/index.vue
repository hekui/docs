<template>
  <div class="user-center">
    <!-- <div class="css_sprites home-button"  v-if="isShowNav" @click="home"></div> -->
    <div class="nav">
      <div class="back" @click="back">
          <div class="css_sprites back-button"></div>
      </div>
      <div class="title">个人中心</div>
      <div class="css_sprites home-button" @click="home"></div>
    </div>
    <div class="login-list">
      <div v-if="userInfo.account">
        <a>{{ userInfo.account | phoneSecurity }}</a>
        <p class="css_sprites light-icon"></p>
        <img src="../../app/img/default-head.png" class="icon">
      </div>
      <div v-else>
        <router-link to="/login">点击登录</router-link>
        <span class="css_sprites default-icon icon"></span>
      </div>
      <p>好房尽在买房吗</p>
    </div>
    <section class="user-section">
      <a @click="mysubscribe"><span class="css_sprites subscribe-icon"></span>我的订阅<s class="css_sprites rectangle-right"></s></a>
      <a href="/about"><span class="css_sprites about-icon"></span>关于我们<s class="css_sprites rectangle-right"></s></a>
      <a href="javascript: void(0);" v-if="userInfo.account" @click="logout"><span class="css_sprites logout-icon"></span>退出登录<s class="css_sprites rectangle-right"></s></a>
    </section>
    <div class="css_sprites a"></div>
    <Toast v-show="isMessage" ref="toast" :message="message"></Toast>
  </div>
</template>
<script>
import {mapState} from 'vuex'
import { Toast } from './../../components';

export default {
  name: 'userCenter',
  route: {
    path: '/usercenter/',
    title: '个人中心'
  },
  computed: {
    ...mapState({
      userInfo: state => state.account.userInfo,
    })
  },
  data(){
    return {
      checked: true,
      isMessage: false,
      message: '',
    }
  },
  mounted(){
    console.log('userInfo', this.userInfo)
  },
  methods: {
    login() {
      this.$util.push(`/login/`);
    },
    mysubscribe(){
      if( this.userInfo.account ){
        this.$util.push(`/mysubscribe/`);
      }else{
        if(this.isMessage){
          return false;
        }
        this.$refs.toast.pos();
        this.message = false;
        this.Toast('请先登录');
      }
    },
    logout(){
      this.$store.dispatch('ACCOUNT_LOGOUT').then(res => {
        this.$refs.toast.pos();
        this.message = false;
        this.Toast('已退出登录');
        this.$util.push('/');
        // location.reload()
        // console.log('userInfo', this.userInfo)
      })
    },
    Toast(msg){
      this.isMessage = true;
      this.message = msg
      setTimeout(()=>{
        this.isMessage = false;
      },2000)
    },
    back() {
      this.$util.back(true);
    },
    home() {
      this.$util.push(`/`);
    }
  },
  components: {
    Toast,
  },
}
</script>
<style lang="less">
.user-center{

  .login-list{
    padding: 0.4rem 0.2rem 0.32rem 0.2rem;
    position: relative;
    a{
      font-size: 0.24rem;
      color: #333;
      line-height: 0.33rem;
      margin-top: 0.03rem;
    }
    p{
      font-size: 0.13rem;
      color: #999999;
      line-height: 0.18rem;
    }
    .icon{
      display: block;
      width: 0.62rem;
      height: 0.62rem;
      position: absolute;
      top: .4rem;
      right: .2rem;
    }
    .default-icon{
      background-position: -3.185rem -1.81rem;
      border-radius: 100%;
    }
  }
  .user-section{
    border-top: 0.1rem #F5F4F4 solid;
    a{
      // width: 3.36rem;
      display: block;
      margin: 0 .2rem;
      padding-left: .26rem;
      height: .46rem;
      line-height: 0.46rem;
      border-bottom: 1px solid #efefef;
      position: relative;
      font-size: 0.15rem;
      span{
        display: inline-block;
        position: absolute;
        top: 0.14rem;
        left: 0;
      }
      .subscribe-icon{
        width: .2rem; height: .17rem;
        background-position: -3.94rem -3.39rem;
      }
      .about-icon{
        width: .2rem; height: .17rem;
        background-position: -4.23rem -3.39rem;
      }
      .logout-icon{
        width: .2rem; height: .17rem;
        background-position: -3.95rem -3.7rem;
      }
      .rectangle-right{
          width: 0.08rem; height: 0.15rem;
          background-position: -1.1rem -4.11rem;
          position: absolute;
          right: .17rem;
          top: .17rem;
      }

    }

  }
}

</style>



