<template>
<div class="presell-detail">
  <div class="nav">
    <div class="back" @click="back">
        <div class="css_sprites back-button"></div>
    </div>
    <div class="title">{{presellDetail.houseName || '楼盘名称'}}</div>
    <div class="css_sprites home-button" @click="home"></div>
  </div>
  <!--  :style="{backgroundImage: 'url(' + presellDetail.picture + ')'}" -->
  <div class="presell-list">
    <div class="presell-cover" @click="goPage('/album/'+ presellDetail.housesId)">
      <img :src="presellDetail.picture" :alt="presellDetail.houseName">
    </div>
    <div class="enrol-content">
        <div class="enrol-info">
            <p class="edge-txt">{{presellDetail.presellSaleStatus}}</p>
            <div class="jiage">本期预售价 <span class="number">{{presellDetail.thisPresellPrice}}元/㎡ </span> </div>
            <div class="fdb">装修报价：{{presellDetail.decoratePrice || '价格待定'}}</div>
            <div class="address">{{presellDetail.housePlace }}</div>
        </div>
        <div class="enrol-info enrol-pages">
            <div>上市时间
                <span>{{presellDetail.intoMarketAt | date('YYYY-MM-DD') || '暂无'}}</span>
            </div>
            <div>网上登记开始
                <span>{{presellDetail.registerStartAt | date('YYYY-MM-DD HH:mm') || '暂无'}}</span>
            </div>
            <div>网上登记结束
                <span>{{presellDetail.registerEndAt | date('YYYY-MM-DD HH:mm') || '暂无'}}</span>
            </div>
            <div>线下交资料截止时间
                <span>{{presellDetail.submitEndAt | date('YYYY-MM-DD HH:mm') || '暂无'}}</span>
            </div>
        </div>
        <div class="enrol-info enrol-pages">
            <div>房源总数
                <span>{{presellDetail.houseSum}}套</span>
            </div>
            <div>棚改套数
                <span>{{presellDetail.remouldSum}}套</span>
            </div>
            <div>刚需套数
                <span>{{presellDetail.demandSum}}套</span>
            </div>
            <div>普通套数
                <span>{{presellDetail.generalSum}}套</span>
            </div>
        </div>
        <div class="enrol-info" v-if="presellDetail.houseModel">
            <div class="type-distribution"><span class="css_sprites distribution-icon"></span> 户型分布</div>
            <div>{{presellDetail.houseModel}}</div>
        </div>
    </div>
    <div class="fixed-botton">
        <span @click="goPage('/housedetails/'+ presellDetail.housesId)">楼盘详情</span>
        <span @click="goPage('/houselotterydetail/'+ presellDetail.id)">摇号结果</span>
    </div>
  </div>
</div>
</template>
<script>
import {
	mapState
} from 'vuex';
export default {
  name: 'housePresellDetail',
  route: {
    path: '/housepreselldetail/:id',
    title: '预售信息'
  },
  preFetch({store, context}) {
    let id = context.params.id;
    return store.dispatch("GET_PRESELL_DETAIL", {
      ctx: context,
      params: {
        id,
      }
    }).then(res => {
      // let houseId = res.data.housesId
      // store.dispatch('GET_HOUSE_DETAIL', {
      //   context,
      //   houseId
      // })
    }, res => {})
  },
	computed: {
		...mapState({
      // info: state => state.houseDetail.info,
			presellDetail: state => state.presell.presellDetail,
		})
  },
  methods: {
    goPage(url) {
      this.$util.push(url);
    },
    back() {
      this.$util.back(true);
    },
    home() {
      this.$util.push(`/`);
    }
  },
}
</script>
<style lang="less">
.presell-detail{
  .presell-cover{
    height: 2.8rem;
    img{
      width: 100%; height: 100%;
    }
  }
.presell-list{
  background-size: 100% 1.4rem;
  background-repeat: no-repeat;
  background-color: #f9f9f9;
  .enrol-content{
    margin-top: -0.82rem;
    margin-left: 0.1rem;
    padding-bottom: .64rem;
    .enrol-info{
      margin-bottom: .14rem;
      width: 3.25rem;
      padding: 0.2rem 0.14rem 0.1rem;
      position: relative;
      background: #fff;
      box-shadow: 0 0.02rem 0.04rem 0 rgba(0,0,0,0.08);
      border-radius: 0.04rem;
      .edge-txt{
        font-size: 0.1rem;
        color: #fff;
        line-height: 0.16rem;
        text-align: center;
        width: 0.5rem;
        height: 0.16rem;
        position: absolute;
        top: -0.08rem;
        left: 0.14rem;
        background-image: linear-gradient(48deg, #fc8076 0%, #fd655b 100%); 
        border-radius: 2px;
      }
      div{
        margin-bottom: .12rem;
        color: #999;
        font-size: .14rem;
        line-height: .14rem;
      }
      .jiage{
        color: #000;
        font-size: 0.16rem;
        line-height: 0.16rem;
      }
      .fdb{
        font-size: 0.12rem;
        color: #fdb117;
        line-height: .12rem;
      }
      .number{
        color: #ff5858;
      }
      .address{
        color: #666;
        font-size: 0.16rem;
        line-height: 0.16rem;
      }
      .type-distribution{
        color: #333;
        .distribution-icon{
          display: inline-block;
          width: 0.19rem; height: 0.19rem;
          background-position:  -4.78rem -3.35rem;
          vertical-align: sub;
        }
      }
    }
    .enrol-pages{
      span{
        float: right;
        color: #333;
      }
    }
  }
  .fixed-botton{
    width: 100%;
    height: 0.45rem;
    line-height: 0.45rem;
    background: #fff;
    position: fixed;
    bottom: 0;
    left: 0;
    box-shadow: 0 0 10px 0 rgba(0,0,0,0.10);
    padding: .1rem 0;
    span{
      display: inline-block;
      width: 1.75rem;
      text-align: center;
      margin-left: 0.1rem;
      color: #fff;
      font-size: .16rem;
      background-image: linear-gradient(48deg, #45dfcb 0%, #13d1a1 100%);
      border-radius: 0.04rem;
      &:active{
        background-image: linear-gradient(-126deg, #3DE1CC 0%, #00CF9C 100%);
      }
      &:last-child{
        margin-left: .05rem;
        background-image: linear-gradient(48deg, #fdb117 0%, #ff9732  100%);
        &:active{
          background-image: linear-gradient(45deg, #FF9733 0%, #FDB117 100%);
        }
      }
    }
  }
}
}
</style>
