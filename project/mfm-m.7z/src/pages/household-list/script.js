/**
 * Created by xiongyan on 2016/12/22.
 */
import { mapState } from 'vuex';
export default {
    name: 'householdlist',
    route: {
        path: '/householdlist/:houseId/:dwellingSize?/:name',
        title: '户型列表'
    },
    data() {
        return {
            activeIndex:0,
            page:1
        }
    },
    computed: {
        ...mapState({
            info: state => state.householdList.info,
            type: state => state.householdList.type,
            ctx: state=>state.householdList.ctx,
            length:state=>state.householdList.length
        })
    },
    preFetch({store, context}) {
        let houseId = context.params.houseId ;
        let dwellingSize = context.params.dwellingSize == "_" ? "" :context.params.dwellingSize;
        return store.dispatch('GET_HOUSEHOLD_LIST', {context, houseId: houseId,dwellingSize:dwellingSize});
    },
    methods:{
        houseType(id,activeIndex){
            let houseId = this.$route.params.houseId;
            this.$route.params.dwellingSize = id;
            this.$store.dispatch('GET_HOUSEHOLD_LIST', {
                context:this.ctx,
                houseId: this.ctx.params.houseId,
                dwellingSize:id
            });
            this.activeIndex = activeIndex;
        },
        gotoDetail(id){
            let name = this.$route.params.name;
            let houseId = this.$route.params.houseId;
            this.$util.push(`/householddetail/${houseId}/${id}/${name}`);
        },
        refresh() {
            this.page = 1;
            return this.getHouseholdList(true);
        },
        getHouseholdList(isRefresh) {
            let dwellingSize =  this.$route.params.dwellingSize == "_" ? "" : this.$route.params.dwellingSize;
            return this.$util.fetch('/householddetail/listdoor', {
                dwellingSize:dwellingSize,
                houseId: this.$route.params.houseId,
                curPage: this.page || 1,
                pageSize: 10
            }).then(result => {
                if (isRefresh) {
                    this.$store.commit('SET_HOUSEHOLD_LIST', result || {});
                } else {
                    this.$store.commit('ADD_HOUSEHOLD_LIST', result || {});
                    if (result && result.data && !result.data.hasNext) {
                        return 1;
                    }
                }
            });
        }
    }
}
