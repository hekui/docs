export default {
    name: 'About',
    route: {
        path: "/about",
        title: "关于我们"
    },
    data() {
        return {
            version: '2.0'
        }
    },
    preFetch({store, context}) {
        store.dispatch('SET_HIDENAV', true);
    },
    mounted() {
        this.version = this.getVersion();
    },

    methods: {
        getVersion() {
            let arr = window.location.search.match(/version=([^&]+)/);
            if (arr) {
                return arr[1];
            }
            return '2.0';
        }
    }
}