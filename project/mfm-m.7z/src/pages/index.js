import page404 from './404';
import About from './about';
import Home from './home';
import HouseDetails from './house-details';
import SearchResult from './search-result';
import HomePage from './home-page';
import HouseholdDdetail from './household-detail';
import Search from './search';
import Location from './location';
import houseDynamic from './house-dynamic';
import Comment from './comment';
import CommentDetail from './comment-detail';
import HouseholdList from './household-list';
import GetRedBag from './get-redbag';
import Album from './album';
import HouseholdAlbum from './household-album';
import Download from './download';
import Agreement from './agreement';

import UserCenter from './user-center'
import Login from './login';
import userAgreement from './user-agreement';
import mySubscribe from './my-subscribe';
import HouseKaipan from './house-kaipan'  // 即将开盘
import HouseSelling from './house-selling'  // 正在销售
import HouseResult from './house-result' // 摇号列表
import HouseResultDetail from './house-result-detail'  // 摇号结果
import HousePresell from './house-presell' // 预售列表
import HousePresellDetail from './house-presell-detail' // 预售详情
import HouseSubscribe from './house-subscribe'

export default {
    Home,
    About,
    Agreement,
    Download,
    Album,
    HouseDetails,
    SearchResult,
    HomePage,
    HouseholdDdetail,
    Search,
    Location,
    houseDynamic,
    Comment,
    CommentDetail,
    HouseholdList,
    GetRedBag,
    HouseholdAlbum,
    UserCenter,
    HouseKaipan,
    HouseSelling,
    HouseResult,
    HouseResultDetail,
    HousePresell,
    HousePresellDetail,
    userAgreement,
    Login,
    mySubscribe,
    HouseSubscribe,
    page404,
};
