<template src="./album.html"></template>
<style lang="less" src="./album.less" scoped></style>
<script src="./album.js"></script>