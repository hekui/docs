import { Carousel } from '../../components';
import { mapState } from 'vuex';

export default {
    name: 'album',

    route: {
        path: '/album/:houseId',
        title: '楼盘图片'
    },

    components: { Carousel },

    data() {
        let self = this;
        return {
            carouselOpts: {
                field: 'filePath',
                isAutoH: true,
                imgSize: '@!w430',
                onChange(item, index) {
                    self.imgIndex = index + 1;
                }
            },
            imgIndex: 1,
            imgTypeId: null,
        } 
    },

    computed: {
        imgList() {
            if (this.imgTypeId == null) {                
                let list = [];
                this.houseImgs.forEach(v => {
                    list = list.concat(v.list);
                });
                return list;
            }   
            let imgObj = this.houseImgs.filter(v => {
                return v.id == this.imgTypeId;
            })[0] || {};
            return imgObj.list || [];
        },

        ...mapState({           
            houseImgs: state => state.houseDetail.houseImgs
        })
    },

    preFetch({store, context}) {
        let houseId = context.params.houseId;
        return store.dispatch('GET_HOUSEIMGS_HDETAIL', {context, houseId: houseId});
    },

    methods: {
        changeImg(id) {
            this.imgIndex = 1;
            this.imgTypeId = id;
        },

        goBack() {
            this.$util.back();
        }
    }
}