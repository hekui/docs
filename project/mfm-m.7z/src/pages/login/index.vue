<template>
	<div class="login-wrapper">
    <span class="css_sprites close-icon" @click="back"></span>
    <div class="fix-title"  :class="{ 'active': subTitle }">
      <h3>手机号快捷登录</h3>
      <p class="sub-title gray">未注册过的手机号将自动创建买房吗账号</p>
    </div>
    <div class="my-form clearfix" :class="{ 'active': subTitle }">
        <div class="input-style">
          <el-input type="number" v-model="loginForm.phone" placeholder="请输入手机号" auto-complete="off" @focus="inputFocus" @blur="inputBlur" oninput="if(value.length>11)value=value.slice(0,11)"></el-input>
          <span class="css_sprites close-input" v-if="loginForm.phone" @click="clearValue('phone')"></span>
        </div>
        <div class="input-style sc">
            <a href="javascript:void(0);" class="send-code" v-if="isSend">{{seconed}}s</a>
            <a href="javascript:void(0);" class="send-code" v-else :class="{'active': validPhone()}" @click="sendCode" @focus="inputFocus" @blur="inputBlur">获取验证码</a>
          </div>
        <div class="input-style wi">
            <el-input type="number" v-model="loginForm.verifyCode" placeholder="请输入验证码" auto-complete="off" @focus="inputFocus" @blur="inputBlur" oninput="if(value.length>6)value=value.slice(0,6)"></el-input>
            <span class="css_sprites close-input"  v-if="loginForm.verifyCode" @click="clearValue('verifyCode')"></span>
        </div>
        <div class="user-style">
          <el-checkbox v-model="loginForm.checked">登录即代表同意</el-checkbox>
          <router-link to="/useragreement">《买房吗用户使用协议》</router-link>
        </div>
        <div class="mt10">
          <div class="submit-button" :class="{ 'disabled' : !loginForm.phone || !loginForm.verifyCode || !loginForm.checked }" @click="login">登 录</div>
        </div>
        <p class="get-voice">如果长时间没有收到验证码，<span @click="sendVoice">点击获取语音验证</span></p>
      </div>
      <Toast v-show="isMessage" ref="toast" :message="message"></Toast>
  </div>
</template>
<script>
const phoneExp = /^1\d{10}$/;
const codeExp = /^\d{6}$/;
import { Toast } from './../../components';

export default {
  name: "Login",
  route: {
    path: "/login",
    title: "手机快捷登录"
  },
  data() {
    return {
      loginForm: {
        phone: "",
        verifyCode: "",
        checked: true
      },
      canSend: true,
      isSend: false,
      seconed: 60, // 多少秒后可发送短信
      timer: null,
      subTitle: false, //title 动画
      isMessage: false, // 默认关闭弹窗
      message: '', // 错误信息内容
    };
  },
  mounted(){
    console.log(this.$route)
  },
  methods: {
    inputFocus() {
      this.subTitle = true;
    },
    inputBlur() {
      this.subTitle = false;
    },
    back() {
      this.$util.back(true);
    },
    initSend() {
      clearInterval(this.timer);
      this.canSend = true;
      this.seconed = 60;
      this.isSend = false;
    },
    validPhone() {
      return phoneExp.test(this.loginForm.phone);
    },
    validCode() {
      return codeExp.test(this.loginForm.verifyCode);
    },
    sendVoice(){
      if(this.validPhone()){
        this.$store.dispatch('ACCOUNT_SENDVOICE', {
          context: {
            city: this.$route.params.city
          },
          params: {
            account: this.loginForm.phone,
            type: 9
          }
        }).then(res => {
          this.$refs.toast.pos();
          this.message = false;
          this.Toast('已发送，请等待接听电话');
        }, res => {

        })
      }else{
        this.$refs.toast.pos();
        this.message = false;
        this.Toast('手机号格式错误');
      }
    },
    sendCode() {
      console.log('in method')
      if(this.validPhone() && this.canSend){
        console.log('发送验证码逻辑')
        this.canSend = false
        this.$store.dispatch('ACCOUNT_SENDCODE', {
          context: {
            city: this.$route.params.city
          },
          params: {
            account: this.loginForm.phone,
            type: 9
          }
        }).then(res => {
          this.loginForm.code = ''
          clearInterval(this.timer)
          this.canSend = false
          this.isSend = true
          this.timer = setInterval(function(){
            this.seconed --
            if(this.seconed === 0){
              this.initSend()
            }
          }.bind(this), 1000)
        }, res => {
          this.$refs.toast.pos();
          this.message = false;
          this.Toast('验证码发送失败，请稍后重试');
          this.initSend()
        })
      }
    },
    login(formName) {
      if( this.loginForm.phone && this.loginForm.verifyCode && this.loginForm.checked){
        if(!this.validPhone()){
          this.$refs.toast.pos();
          this.message = false;
          this.Toast('手机号格式错误');
          return false
        }
        if(!this.validCode()){
          this.$refs.toast.pos();
          this.message = false;
          this.Toast('验证码错误');
          return false
        }
        // 请勾选买房吗用户使用协议
        // console.log('调用登录接口')
        // 调用登录接口
        // console.log(this.$route)
        this.$store.dispatch('ACCOUNT_CODE_LOGIN', {
          context: {
            city: this.$route.params.city
          },
          params:{
            phone: this.loginForm.phone, 
            verifyCode: this.loginForm.verifyCode, 
            sourceType: -6
          }
        }).then(res => {
            console.log('登录成功')
            // this.$message({type: 'success', message: '登录成功'})
            this.loginForm = {
              phone: '',
              verifyCode: '',
              imgCaptcha: '',
              checked: true,
            };
            // this.$store.commit('INDEX_SET', {
            //   target: 'showLoginDialog',
            //   data: false
            // });
            this.initSend()
            this.$util.push(`/usercenter/`);
          }, res => {
            if(res.code === 1035){
              this.$refs.toast.pos();
              this.message = false;
              this.Toast('验证码错误');
            }else{
              this.$refs.toast.pos();
              this.message = false;
              this.Toast('登录失败：'+ res.msg);
            }
          })
      }
    },
    clearValue(event) {
      if(event == 'phone'){
        this.loginForm.phone = ''
      }else{
        this.loginForm.verifyCode = ''
      }
    },
    Toast(msg){
      this.isMessage = true;
      this.message = msg
        setTimeout(()=>{
            this.isMessage = false;
        },2000)
    },
  },
  components: {
      Toast,
  },
};
</script>
<style lang="less">
.login-wrapper {
  margin: 0.2rem 0.2rem 0 0.2rem;
  line-height: 1;
  position: relative;
  .clearfix:after {
    content: "";
    display: block;
    clear: both;
  }

  .close-icon {
    display: block;
    width: 0.18rem;
    height: 0.18rem;
    background-position: -4rem -2.73rem;
    position: absolute;
  }
  .fix-title {
    transition: all 0.3s;
    h3 {
      font-size: 0.26rem;
      color: #333;
      margin-top: 0.38rem;
      margin-bottom: 0.16rem;
      font-weight: bold;
      transition: all 0.3s;
    }
    .sub-title {
      margin-bottom: 0.3rem;
      font-size: 0.16rem;
      color: #c8c8c8;
      transition: all 0.3s;
    }
    &.active {
      margin-left: 0.2rem;
      margin-bottom: 0.3rem;
      text-align: center;
      h3{
        font-size: 0.18rem;
        color: #666;
        margin-top: 0;
        margin-bottom: 0;
      }
      .sub-title{
        display: none;
      }
    }
  }
  .rules {
    margin-top: 16px;
    a {
      color: #fdb117;
    }
  }

  .input-style {
    width: 2.15rem;
    float: left;
    height: 0.55rem;
    line-height: 0.55rem;
    border-bottom: 0.01rem solid #efefef;
    position: relative;
    font-size: 0.16rem;
    &.sc{
      width: 1.2rem;
    }
    &.wi {
      width: 100%;
    }
    .send-code {
      // padding: 0 0.1rem;
      width: 1.12rem; height: 0.33rem;
      text-align: center;
      line-height: 0.33rem;
      position: absolute;
      right: 0;
      top: 0.12rem;
      color: #999;
      background: #f9f9f9;
      &.active {
        color: #fff;
        background-image: linear-gradient(48deg, #fdb117 0%, #ff9733 100%);
        border-radius: 0.02rem;
      }
    }
    .close-input{
      display: block;
      width: 0.14rem;
      height: 0.14rem;
      background-position: -4.53rem -3.39rem;
      position: absolute;
      top: .2rem;
      right: .1rem;
    }
  }
  .user-style {
    float: left;
    font-size: 0.14rem;
    margin: 0.14rem 0 0.2rem;
    a{
      color: #ffbc21;
    }
  }

  .mt10 {
    float: left;
    width: 100%;
    margin-top: 0.23rem;
    margin-bottom: .14rem;
    background: #f6f6f6;
    border-radius: 0.02rem;
    font-size: 0.17rem;
    color: #999999;
    line-height: 0.46rem;
    .submit-button {
      width: 100%;
      height: 0.46rem;
      line-height: 0.46rem;
      display: inline-block;
      color: #fff;
      background-image: linear-gradient(48deg, #fdb117 0%, #ff9733 100%);
      border-radius: 2px;
      text-align: center;
      font-size: 0.16rem;
      cursor: pointer;
      &.disabled {
        background-image: linear-gradient(48deg, #f6f6f6 0%, #f6f6f6 100%);
        color: #999;
      }
    }
  }

  .get-voice{
    float: left;
    width: 100%;
    text-align: center;
    font-size: .14rem;
    color: #999;
    span{
       color: #ffbc21;
    }
  }

}
</style>