
import { mapState } from 'vuex';

export default {
    name: 'household_album',

    route: {
        path: '/householdalbum/:id',
        title: '户型图片'
    },
    computed: {
        ...mapState({
            info: state => state.householdDetail.info
        })
    },
    preFetch({store, context}) {
        let id = context.params.id;
        return store.dispatch('GET_INFO', {context, id: id});
    },
    methods:{
        goBack() {
            this.$util.back();
        }
    }

}