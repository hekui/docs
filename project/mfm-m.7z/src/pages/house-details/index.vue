<template src="./details.html"></template>
<style lang="less" src="./details.less" scoped></style>
<script src="./details.js"></script>