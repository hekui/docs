import {
    Icon,
    CommentItem,
    FooterInfo,
    Toast,
} from '../../components';
import {
    mapState
} from 'vuex';

export default {
    name: 'house-details',
    route: {
        path: '/housedetails/:houseId',
        title: '新房楼盘详情'
    },
    data() {
        return {
            isShowMore: false,
            unsubscribeDialogVisible: false,
            isMessage: false,
            message: '',
            // isSubscribeNews: true, // 当前楼盘订阅状态
        }
    },

    computed: {
        ...mapState({
            info: state => state.houseDetail.info,
            news: state => state.houseDetail.news,
            types: state => state.houseDetail.types,
            commentInfo: state => state.houseDetail.commentInfo,
            prices: state => state.houseDetail.prices,
            surrounds: state => state.houseDetail.surrounds,
            isSubscribeNews: state => state.houseDetail.isSubscribeNews // 已订阅动态
        })
    },

    preFetch({
        store,
        context
    }) {
        let houseId = context.params.houseId || '808882104573100032';
        return store.dispatch('GET_DETAIL_HDETAIL', {
            context,
            houseId: houseId
        });
    },

    watch: {
        prices: function (value) {
            this.$nextTick(function () {
                this.initChart();
            });
        }
    },

    
    created() {
        // this.fetchSubscribeNewsStatus();
    },

    mounted() {
        document.body.addEventListener('touchstart', function () { 
			//...空函数即可
		});
        if (!window.Chart) {
            let script = document.createElement('script');
            script.src = '/js/Chart.min.js';
            script.addEventListener('load', this.initChart);
            this.$el.appendChild(script);
        } else {
            this.initChart();
        }

        this.fetchSubscribeNewsStatus();
    },

    methods: {
        fetchSubscribeNewsStatus() {
            this.$store.dispatch("HOUSEDETAIL_SUBSCRIBE_STATUS_FETCH", {
                params: {
                    houseId: this.info.id,
                    cookies: {}
                },
                context: {
                    city: this.$route.params.city
                }
            });
        },
        subNews(status) {
            if (status) {
                this.$util.push(`/housesubscribe/${this.$route.params.houseId}`);
            } else {
              // 取消订阅弹窗
              this.unsubscribeDialogVisible = true;
            }
        },
        cancelButton(){
            // 取消订阅
            this.$store.dispatch("HOUSEDETAIL_UNSUBSCRIBE_FETCH", {
                params: {
                    houseId: this.info.id,
                },
                context: {
                    city: this.$route.params.city
                }
            }).then( res => {
                this.$refs.toast.pos();
                this.message = false;
                this.Toast("取消成功");
  
                this.$store.commit("HOUSEDETAIL_SET", {
                    target: "isSubscribeNews",
                    data: false
                });
                
                this.unsubscribeDialogVisible = false;
            },res => {
                this.$refs.toast.pos();
                this.message = false;
                this.Toast("取消订阅失败：" + res.msg);
                this.unsubscribeDialogVisible = false;
            }); 
        },
        goToPresell() {
            this.$util.push(`/housepresell/${this.$route.params.houseId}`);
        },
        goToSubscribe() {
            
        },
        download() {
            this.$util.push(`/download`);
        },
        toggle() {
            this.isShowMore = !this.isShowMore;
        },

        goToDynamic() {
            this.$util.push(`/housedynamic/${this.$route.params.houseId}/${encodeURIComponent(this.info.name)}`);
        },

        goToModel() {
            this.$util.push(`/householdlist/${this.$route.params.houseId}/_/${encodeURIComponent(this.info.name)}`);
        },

        goToSelf(id) {
            this.$emit('jumpDetails');
            this.isShowMore = false;
            this.$el.querySelector('.house-content').scrollTop = 0;
            this.$util.push(`/housedetails/${id}`);
        },

        goToModelDetail(id) {
            this.$util.push(`/householddetail/${this.$route.params.houseId}/${id}/${encodeURIComponent(this.info.name)}`);
        },

        goToComment() {
            this.$util.push(`/comment/${this.$route.params.houseId}`);
        },

        goToRedBag() {
            this.$util.push(`/getredbag/${this.$route.params.houseId}/${encodeURIComponent(this.info.name)}`);
        },
        
        back() {
            this.$util.back(true);
        },
        home() {
            this.$util.push(`/`);
        },

        goToAlbum() {
            this.$util.push(`/album/${this.$route.params.houseId}`);
        },

        initChart() {
            if (this.prices.length < 1) {
                return;
            }
            let ctx = document.getElementById('myChart').getContext('2d');
            let labels = [];
            let points = [];
            this.prices.forEach(v => {
                labels.push(v.priceDateDisplay);
                points.push(v.price);
            });
            let data = {
                labels: labels,
                datasets: [{
                    fill: false,
                    backgroundColor: "rgba(142,192,238,0.5)",
                    borderColor: "rgba(127,183,236,1)",
                    pointBackgroundColor: "rgba(106,171,234,1)",
                    borderWidth: 1,
                    data: points
                }, ]
            }
            let config = {
                type: 'line',
                data: data,
                options: {
                    legend: {
                        display: false
                    },
                    tooltips: {
                        displayColors: false,
                        backgroundColor: 'rgba(0,0,0,.6)',
                        callbacks: {
                            title: function () {
                                return '';
                            },
                            dataPoints: function () {
                                return '';
                            },
                            label: function (items) {
                                return items.yLabel + '元/㎡';
                            }
                        }
                    },
                    scales: {
                        xAxes: [{
                            gridLines: {
                                drawOnChartArea: false,
                                tickMarkLength: 5,
                                color: 'rgba(201,215,230,1)'
                            }
                        }],
                        yAxes: [{
                            gridLines: {
                                drawTicks: false,
                                drawBorder: false
                            },
                            ticks: {
                                callback: function (value) {
                                    return value + '元/㎡';
                                },
                                min: 0
                            }
                        }]
                    }
                }
            }
            new Chart(ctx, config);
        },
        Toast(msg){
            this.isMessage = true;
            this.message = msg
            setTimeout(()=>{
                this.isMessage = false;
            },2000)
        },
    },
    components: {
        Icon,
        CommentItem,
        FooterInfo,
        Toast,
    }
}
