export default {
	name: 'page404',
	route: {
		path: "*",
		title: "404"
	}
}