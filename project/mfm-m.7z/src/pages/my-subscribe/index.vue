<template>
  <div class="my-subscribe">
    <div class="nav">
      <div class="back" @click="back">
          <div class="css_sprites back-button"></div>
      </div>
      <div class="title">我的订阅</div>
      <div class="css_sprites home-button" @click="home"></div>
    </div>
    <houseList v-if="subscribeList.list.length > 0" :info="subscribeList" v-on:loadMore="loadMore" v-on:jumpDetails="setScrollPosition" ref="list"></houseList>
    <div class="no-subscribe" v-else>
       <span class="css_sprites no-subscribe-icon"></span>
       <p class="ts-text">您还没有订阅任何楼盘</p>
       <p class="ms-text">快去添加一个楼盘吧~获取楼盘最新动态哦</p>
       <p class="selling-button" @click="routeGo('/houseselling/')">正在销售的楼盘</p>
    </div>
  </div>
</template>
<script>
import { HouseSearch,houseList } from './../../components';
import { mapState } from 'vuex';

export default {
  name: "mySubscribe",
  route: {
    path: "/mysubscribe",
    title: "我的订阅"
  },
  data () {
    return {
      noData: false
    }
  },
  mounted() {
    if(this.$refs.list){
      this.$refs.list.setScrollPosition(this.scrollPosition.x, this.scrollPosition.y);
		  this.$refs.list.resizeScroll(this.subscribeList.hasNext == true ? undefined : 1);
    }
	},
	computed: {
		...mapState({
			subscribeList: state => state.my.subscribeList,
			scrollPosition: state => state.scrollPosition
		})
  },
  preFetch({store, context}) {
    store.commit('SET_SUBSCRIBE_INIT')
		return store.dispatch("MY_SUBSCRIBE_LIST", {
      context
    }).then(res =>{}, res => {
      return Promise.reject(res)
    });
  },
  watch: {
		search() {
			this.$store.dispatch("HOUSE_CLEAR_HOUSE_LIST");
			this.loadMore(status => this.$refs.list.resizeScroll(status));
		}
  },
  methods: {
    routeGo(url){
      this.$util.push(url);
    },
		loadMore(callback) {
			this.$store.dispatch("HOUSE_FETCH_LIST", {
				callback
			});
		},
		setScrollPosition() {
			this.$util.setScrollPosition(this.$refs.list.getScrollPosition());
		},
    back() {
      this.$util.back(true);
    },
    home() {
      this.$util.push(`/`);
    }
  },
  components: {
    HouseSearch,
		houseList,
	},
};
</script>
<style lang="less">
.my-subscribe{
  .no-subscribe{
    text-align: center;
    .no-subscribe-icon{
      display: block;
      width: 1.83rem; 
      height: 1.39rem;
      background-position:  -4.29rem -1.71rem;
      margin: 0.5rem auto 0.36rem; 
     }
    .ts-text{
      font-size: 0.16rem;
      font-weight: bold;
      color: #636C7B;
      margin-bottom: .12rem;
    }
    .ms-text{
      font-size: 0.14rem;
      color: #C5CCD7;
      margin-bottom: 0.26rem;
    }
    .selling-button{
      width: 1.83rem;
      height: 0.45rem;
      line-height: .45rem;
      background-image: linear-gradient(48deg, #FDB117 0%, #FF9733 100%);
      border-radius: 0.04rem;
      font-size: 0.17rem;
      color: #FFFFFF;
      margin: 0 auto;
    }

  }
}
  
</style>
