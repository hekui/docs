<style lang="less" src="./style.less" scoped></style>
<template src="./page.html"></template>
<script src="./script.js"></script>