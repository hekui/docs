import {
	HouseSearch,
	BottomLayer,
	houseList,
} from './../../components';
import {
	mapState
} from 'vuex';
export default {
	name: 'Home',
	components: {
		HouseSearch,
		BottomLayer,
		houseList,
	},
	watch: {
		search() {
			this.$store.dispatch("HOUSE_CLEAR_HOUSE_LIST");
			this.loadMore(status => this.$refs.list.resizeScroll(status));
		}
	},
	methods: {
		loadMore(callback) {
			this.$store.dispatch("HOUSE_FETCH_LIST", {
				callback
			});
		},
		setScrollPosition() {
			this.$util.setScrollPosition(this.$refs.list.getScrollPosition());
		}
	},
	mounted() {
		this.$refs.list.setScrollPosition(this.scrollPosition.x, this.scrollPosition.y);
		this.$refs.list.resizeScroll(this.houseList.hasNext == true ? undefined : 1);
	},
	computed: {
		...mapState({
			search: state => state.houseSearch.search,
			houseList: state => state.houseSearch.houseList,
			scrollPosition: state => state.scrollPosition
		})
	},
	preFetch() {
		return HouseSearch.preFetch.apply(this, arguments);
	},
	route: {
		path: "/cate/:regionId",
		title: "成都新房，尽在买房吗", // 正在销售的成都新房
	}
}