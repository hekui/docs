import {
    Icon
} from '../../components';

export default {
    name: 'location',
    data() {
        return {
            curCity: {
                ...this.$store.state.city.curCity,
            },
            obj: {},
            latitude: "",
            longitude: "",
            localState: "",
            refresh: false
        };
    },
    route: {
        path: '/location',
        title: '成都新房，尽在买房吗'
    },
    components: {
        Icon
    },
    computed: {
        cityList() {
            return this.$store.state.city.cityList;
        },
    },
    mounted(){
        this.localtion();
    },
    methods: {
        changeCity(obj) {
            this.$util.push(`/`, obj);
        },
        localtion(e){
            if(e){
                e.stopPropagation();
            }
            this.refresh = true;
            this.localState = this.latitude ? false : "获取中...";
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((position)=> {
                    if (position.coords) {
                        this.localState = false;
                        this.latitude = position.coords.latitude;
                        this.longitude = position.coords.longitude;
                        this.$util.fetch('/api/getcity', {
                            latitude: position.coords.latitude,
                            longitude: position.coords.longitude
                        }, {city: 'cd'}).then(data => {
                            this.refresh = false;
                            if (data.code === 0) {
                                this.localState = false;
                                this.obj = data.data;
                            } else {
                                this.localState = "定位失败,请重试！";
                            }
                        }).catch(error=> {
                            this.refresh = false;
                        })
                    } else {
                        this.refresh = false;
                        this.localState = "定位失败,请重试！";
                    }
                }, (error)=> {
                    this.refresh = false;
                    this.localState = "定位失败,请重试！";
                });
            } else {
                this.refresh = false;
                this.localState = "定位失败,请重试！";
            }

        }
    }
}