<template src="./index.html"></template>
<style lang="less" src="./index.less"></style>
<script>
import {
    mapState
} from 'vuex';

export default {
    name: 'preselllist',
    route: {
        path: '/preselllist/:houseId',
        title: '预售信息'
    },
    data() {
        return {
            houseId: this.$route.params.id,
        }
    },
    preFetch({ store, context }) {
        let houseId = context.params.houseId || '808882104573100032';
        return store.dispatch('GET_DETAIL_HDETAIL', {
            context,
            houseId: houseId
        });
    },
    computed: {
        ...mapState({
            info: state => state.houseDetail.info
        })
    },
    methods: {
        houseDetails(id) {
            this.$util.push(`/housedetails/${id}`);
        },
        houseResult(id) {
            this.$util.push(`/presellresult/${id}`);
        },
    },

}

</script>