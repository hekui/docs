<template>
  <div class="house-result-page">
    <div class="nav">
      <div class="back" @click="back">
          <div class="css_sprites back-button"></div>
      </div>
      <div class="title">历史摇号结果</div>
      <div class="css_sprites home-button" @click="home"></div>
    </div>
    <lotteryList :info="lotteryList" v-on:loadMore="loadMore" v-on:jumpPage="setScrollPosition" ref="list"></lotteryList>
  </div>
</template>
<script>
import {mapState} from 'vuex'
import {lotteryList} from './../../components';
export default {
  name: 'houseResult',
  route: {
    path: '/houselottery',
    title: '成都新房摇号结果'
  },
  data () {
    return {
      resultData: true,
      curPage: 1,
      loading: false,
    }
  },
  computed: {
    ...mapState({
      scrollPosition: state => state.scrollPosition,
      lotteryList: state => state.presell.lotteryList,
    })
  },
  preFetch({store, context}) {
    store.commit('SET_LOTTERY_LIST_INIT')
    return store.dispatch('GET_LOTTERY_LIST', {context})
  },
	mounted() {
    this.$refs.list.setScrollPosition(this.scrollPosition.x, this.scrollPosition.y);
    this.$refs.list.resizeScroll(this.lotteryList.hasNext == true ? undefined : 1);
  }, 
  methods: {
    loadMore(callback) {
			this.$store.dispatch("GET_LOTTERY_LIST", {
        callback, 
			});
    },    
		setScrollPosition() {
      // console.log('this.$refs.list.getScrollPosition()', this.$refs.list.getScrollPosition())
			this.$util.setScrollPosition(this.$refs.list.getScrollPosition());
    },
    goDetail(item){
      if(item.presellSaleStatus){ // 摇号结束 进入详情
        this.$util.push(`/houselotterydetail/${item.id}`)
      }
    },
    back() {
      this.$util.back(true);
    },
    home() {
      this.$util.push(`/`);
    }
  },
  components: {
		lotteryList,
  },
}
</script>
<style lang="less">
.no-result-data{
  text-align: center;
  .no-result-icon{
    display: block;
      width: 2.02rem; 
      height: 1.65rem;
    background-position:  -2.17rem -0.05rem;
    margin: 0.5rem auto 0.36rem; 
    }
  .ts-text{
    font-size: 0.16rem;
    font-weight: bold;
    color: #636C7B;
    margin-bottom: .12rem;
  }
  .ms-text{
    font-size: 0.14rem;
    color: #C5CCD7;
    margin-bottom: 0.26rem;
  }

}
</style>

