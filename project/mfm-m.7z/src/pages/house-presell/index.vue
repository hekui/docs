<template>
  <div class="house-presell">
    <div class="nav">
      <div class="back" @click="back">
          <div class="css_sprites back-button"></div>
      </div>
      <div class="title">{{info.name || '楼盘名称'}}</div>
      <div class="css_sprites home-button" @click="home"></div>
    </div>
    <div v-if="presellList.list.length > 0">
      <div class="item" v-for="(item, index) in presellList.list" :key="index" @click="goPage(item.id)">
        <div>
          {{item.intoMarketAt | date('YYYY-MM-DD')}}&nbsp;&nbsp;{{item.presellSaleStatus}}
        </div>
        <Icon name="down"></Icon>
      </div>
    </div>
    <div class="no-search-data" v-else>
            <!-- <p>加载更多数据</p> -->
        <span class="css_sprites no-search-icon"></span>
        <p class="ts-text">本楼盘暂无预售信息</p>
        <p class="ms-text">请稍后再来哦</p>
    </div>
  </div>
</template>
<script>
import {
  Icon, Navbar
} from '../../components';
import {
	mapState
} from 'vuex';
export default {
  name: 'housePresell',
  route: {
    path: '/housepresell/:houseId',
    title: '成都新房预售列表'
  },
  preFetch({store, context}) {
    let houseId = context.params.houseId
    store.commit('SET_SELLING_INIT')
    
		return Promise.all([
      store.dispatch("GET_PRESELL_LIST", {
        ctx: context,
        params: {
          housesId: houseId,
          curPage: 1,
          pageSize: 20
        }
      }),
      store.dispatch("GET_HOUSE_DETAIL", {
        context,
        houseId
      }),
    ]);
  },
	computed: {
		...mapState({
      info: state => state.houseDetail.info,
			presellList: state => state.presell.presellList,
		})
  },
  methods: {
    goPage(id){
      this.$util.push(`/housepreselldetail/${id}`);
    },
    back() {
      this.$util.back(true);
    },
    home() {
      this.$util.push(`/`);
    }
  },
  components: {
    Icon
  }
}
</script>
<style lang="less">
.house-presell{
  color: #333;
  .item{
    display: flex; justify-content: space-between;
    border-bottom: 1px solid #f3f3f3; line-height: .48rem; padding: 0 .2rem; font-size: .17rem;
    i{
      display: inline-block;
      font-size: 0.1rem;
      transform: rotate(-90deg) scale(.8);
      color: #999;
    }
  }
  .no-search-data{
    text-align: center;
    .no-search-icon{
      display: block;
      width: 2.12rem; height: 1.48rem;
      background-position:  -0.05rem -0.05rem;
      margin: 0.5rem auto 0.1rem; 
    }
    .ts-text{
      font-size: 0.16rem;
      font-weight: bold;
      color: #636C7B;
      margin-bottom: .12rem;
    }
    .ms-text{
      font-size: 0.14rem;
      color: #C5CCD7;
      margin-bottom: 0.26rem;
    }  
  }
}

</style>

