/**
 * Created by xiongyan on 2016/12/22.
 */
import {Icon,commDialog} from '../../components';
import { mapState } from 'vuex';
export default {
    name: 'household_detail',
    route: {
        path: '/householddetail/:houseId/:id/:name',
        title: '户型详情'
    },
    components: {Icon,commDialog},
    computed: {
        ...mapState({
            info: state => state.householdDetail.info
        })
    },
    preFetch({store, context}) {
        let id = context.params.id;
        return store.dispatch('GET_INFO', {context, id: id});
    },
    data() {
        return {
            isShow: false,
            houseId:this.$route.params.houseId
        }
    },
    methods:{
        download() {
            this.$util.push(`/download`);
        },
        jumpPath(path){
            this.$util.beforePush();
        },
        openDialog(){
            this.isShow = true;
        },
        close(){

            this.isShow = false;
        },
        gotoImg(id){
            this.$util.push(`/householdalbum/${id}`);
        }
    }
}
