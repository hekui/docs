/**
 * Created by xiongyan on 2016/12/22.
 */
import {Icon} from '../../components';
import { mapState } from 'vuex';
import {BottomLayer} from '../../components';
export default {
    name: 'search',
    route: {
        path: '/search',
        title: '搜索'
    },
    components: {Icon,BottomLayer},
    data:function () {
        return {
            keyword: '',
            statu:0,
            myData:[],
            timer:"",
            isShow:true
        };
    },
    computed: {
        ...mapState({
            info: state => state.Search.info,
            history:state=>state.Search.history
        }),
    },
   /* preFetch({store, context}) {
        //store.dispatch('GET_SEARCH', {context, keyword: "星"});
    },*/
    methods:{
        gotoSearch(){
            let keyword = this.keyword.replace(/(^\s*)|(\s*$)/g,"") || "_";
            this.$util.push(`/searchresult/${keyword}`);
        },
        clearSearch(){
            this.keyword = ''
        },
        deleteHistory(index){
            this.$store.commit("DELETE_HISTORY",index);
            this.$store.dispatch("WRITE_HISTORY");
        },
        clearHistory(){
            this.$store.commit("CLIENT_HISTORY");
            this.$store.dispatch("WRITE_HISTORY");
        },
        selectClick(index){
            let keyword = this.myData[index].name;
            this.$util.push(`/searchresult/${keyword}`);
        },
        historyClick(index){
            let keyword = this.history[index];
            this.$util.push(`/searchresult/${keyword}`);
        },
        back() {
            this.$util.back(true);
        },
        change(){
           this.isShow = !this.isShow;
        }
        
    },
    watch:{
        keyword(value){
            clearTimeout(this.timer);
            this.timer = setTimeout(()=>{
                if(value == ""){
                    this.statu = 0;
                }else {
                    this.statu = 1;
                    this.$util.fetch('/searchResult/listkeyword', {keyword: value}).then(res => {
                        if(res.code == 0){
                            this.myData = res.data.list;
                        }
                    });
                }
            },1000)
        }

    },
    mounted () {
        this.$refs.searchInput.focus();
        this.$store.dispatch('INIT_HISTORY');
    },
    destroyed(){
        if(!this.keyword.replace(/(^\s*)|(\s*$)/g,"")) return;
        this.$store.dispatch("PUSH_HISTORY",this.keyword.replace(/(^\s*)|(\s*$)/g,""));
        this.$store.dispatch("WRITE_HISTORY");
    }
}
