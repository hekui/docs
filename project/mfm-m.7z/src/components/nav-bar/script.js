export default {
    computed: {
        title() {
            return this.$title;
        }
    },
    methods: {
        back() {
            this.$util.back(true);
        },
        home() {
            this.$util.push(`/`);
        }
    }
}