<template src="./index.html"></template>

<script>
export default {
  data() {
    return { isShow: true };
  },
  methods: {
    hideFooter() {
      this.isShow = false;
    },
    download() {
      this.$util.push(`/download`);
    }
  }
};
</script>