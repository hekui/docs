<template src="./index.html"></template>
<style lang="less" src="./index.less"></style>
<script>
import FooterInfo from '../footer-info';

 export default {
    name:"house_list",
    data(){
        return {
            loadCallBacks:{},
            sellStatus: {
                '即将开盘': 0,
                '售罄': 1,
                '正在销售': 2,
                '正在报名': 4,
            }
        }
    },
    props: {
        info: Object
    },
    components: {
        FooterInfo,
    },
    methods:{
         goToDetail(id){
            this.$emit('jumpDetails');
            this.$util.push(`/housedetails/${id}`);
         },
         getScrollPosition(){
            return this.$refs.scroll.getScrollPosition();
         },
         setScrollPosition(x,y){
            this.$refs.scroll && this.$refs.scroll.setScrollPosition(x,y);
         },
         resizeScroll(status){
            this.$refs.scroll && this.$refs.scroll.reset(status);
         },
         loadMore(){
            return new Promise((resolve, reject)=>{
                this.$emit('loadMore',(status)=>{
                    resolve(status);
                });
            });
         },
         pushLoadCallBack(key,fn){
            this.loadCallBacks[key] = fn;
         },
         clearLoadCallBack(key){
            delete this.loadCallBacks[key];
         }
     }
 }
</script>