import Icon from './../icon';
import Toast from "../toast";
export default{
    name: "dialog",
    components: {
        Icon,
        Toast,
    },
    props:["slogan","houseId"],
    data(){
        return {
            currentView:'Toast',
            username: "",
            phone: "",
            message: "",
            text:{
                dynamic:"我们将会通过上面的联系方式通知您该楼盘最新的动态哦",
                feature:"买房吗客服会安排专业的置业顾问为您介绍该户型的特点"
            }
        }
    },
    computed:{
        dialogText(){
            return this.text[this.slogan];
        }
    },
    methods: {
        submit(){
            this.message = false;
            let validataObj = new validate(),
                username = validataObj.getResult(this.username || ""),
                phone = validataObj.getResult(this.phone || ""),
                msg = Object.assign(username, phone);
            if (!msg.state) {
                let params = Object.assign({}, {userName: this.username, phone: this.phone,housesId:this.houseId,city:this.$route.params.city});
                this.$store.dispatch("FETCH_USER_INFO", params).then(res=> {
                    if(res.code === 0){
                        setTimeout(()=>{
                            this.$emit("closeDialog");
                        },2500)
                    }
                    this.Toast(res.msg);
                })
            } else {
                this.Toast(msg.msg);
            }
        },
        Toast(msg){
            setTimeout(()=>{
                this.message = msg;
            },10)
        },
        closeDialog(){
            this.$emit("closeDialog");
        }

    }
}

class validate {
    constructor() {
        this.valiCofig = {
            required: {
                reg: /\S+/,
                msg: "输入框不能为空"
            },
            phone: {
                reg: /^1(3|4|5|7|8)\d{9}$/,
                msg: "手机号码错误"
            }
        }
    }

    getResult(val) {
        let filed = this.valiCofig;
        return (()=> {
            let result = {state: false}
            for (let o in filed) {
                let tempObj = filed[o];
                if (!result.state && !tempObj.reg.test(val)) {
                    result.state = true;
                    result.msg = filed[o].msg;
                }
            }
            return result;
        })()

    }
}
