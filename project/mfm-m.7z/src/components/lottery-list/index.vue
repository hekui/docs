<template src="./index.html"></template>
<style lang="less" src="./index.less"></style>
<script>
export default{
    name:"house_list",
    data(){
        return {
            loadCallBacks:{}
        }
    },
    props: {
        info: Object
    },
    methods:{
         goPage(item){
            this.$emit('jumpPage');
            // return;
            if(item.presellSaleStatus){ // 摇号结束 进入详情
                this.$util.push(`/houselotterydetail/${item.id}`)
            }
         },
         getScrollPosition(){
            return this.$refs.scroll.getScrollPosition();
         },
         setScrollPosition(x,y){
            this.$refs.scroll && this.$refs.scroll.setScrollPosition(x,y);
         },
         resizeScroll(status){
            this.$refs.scroll && this.$refs.scroll.reset(status);
         },
         loadMore(){
            return new Promise((resolve, reject)=>{
                this.$emit('loadMore',(status)=>{
                    resolve(status);
                });
            });
         },
         pushLoadCallBack(key,fn){
            this.loadCallBacks[key] = fn;
         },
         clearLoadCallBack(key){
            delete this.loadCallBacks[key];
         }
     }
 }
</script>