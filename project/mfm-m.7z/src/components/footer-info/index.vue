<style lang="less" src="./style.less"></style>
<template src="./page.html"></template>
<script src="./script.js"></script>