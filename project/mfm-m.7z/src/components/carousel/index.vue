<template>
    <div class="scroller">
        <ul :style="styleObj" @touchstart.stop="start" @touchmove.stop.prevent="move" @touchend.stop="end">
            <li v-for="(item, index) in list" :key="index" :class="{autoH: opts.isAutoH}">
                <a :href="opts.urlField ? item[opts.urlField] : false" target="_blank"><img :src="item[opts.field] + opts.imgSize" /></a>
            </li>
        </ul>
        <div class="dots" v-if="opts.haveDot && (list.length > 1)">
            <span v-for="(item, index) in imgList" :key="index" :class="{active: activeIndex == index}"></span>
        </div>
    </div>
</template>

<style lang="less" src="./carousel.less" scoped></style>

<script src="./carousel.js"></script>