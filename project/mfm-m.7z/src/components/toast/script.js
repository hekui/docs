export default{
    name: "Toast",
    props: ["message"],
    data(){
        return {
            isShow: false,
            timer: '',
            // msg: '',
            top: false,
        }
    },
    computed: {
        msg(){
            return this.message;
        }
    },
    // watch:{
    //     message: function(val, oldVal){
    //         console.log(val, oldVal)
    //         this.msg = val
    //         setTimeout(function(){
    //             this.msg = ''
    //         }.bind(this), 2500)
    //     }
    // },
    methods:{
        pos(){
          this.top = true;
        }
    }
}