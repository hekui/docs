<template><i class="iconfont" v-bind:class="'icon-' + name"></i></template>

<style src="./font/iconfont.css" scoped></style>

<script>
    export default {
        name: 'icon-font',
        props: ['name']
    }
</script>