// status of pull down
const STATUS_ERROR = -1;
const STATUS_START = 0;
const STATUS_READY = 1;
const STATUS_REFRESH = 2;
const STATUS_FINISH = 3;
// labels of pull down
const LABELS = ['数据异常', '下拉刷新数据', '松开刷新数据', '数据刷新中...'];
const LABELS2 = ['数据异常', '加载更多数据', '', '数据加载中...', '没有更多了'];
const PULL_DOWN_HEIGHT = 60;
/**
 * reset the status of pull down
 * @param {Object} pullDown the pull down
 */
let resetPullDown = (_self) => {
    _self.pullDown.height = 0;
    _self.pullDown.status = STATUS_START;
};
let resetPullUp = (_self, _state) => {
    _self.pullUp.status = _state || STATUS_START;
};


function getPlatform() {
    var _userAgent = navigator.userAgent.toLowerCase();
    if (_userAgent.indexOf("iphone") > -1 || _userAgent.indexOf("ipad") > -1) {
        return 'iOS';
    } else if (_userAgent.indexOf("android") > -1) {
        return 'Android';
    }
}

export default {
    props: {
        onRefresh: {
            type: Function
        },
        onLoadMore: {
            type: Function
        }
    },
    data() {
        return {
            pullDown: {
                status: 0,
                height: 0,
                msg: '',
                hasTransition: false,
            },
            pullUp: {
                status: 0,
                height: 0,
                msg: '',
                si: null
            },
            isTop: true,
        };
    },
    methods: {
        scroll(){
            this.$emit('scroll', this.getScrollPosition())
        },
        reset(state) {
            resetPullDown(this);
            resetPullUp(this, state == 1 ? STATUS_FINISH : 0)
        },
        getScrollPosition() {
            let main = this.$el;
            return {
                x: main.scrollLeft,
                y: main.scrollTop
            };
        },
        setScrollPosition(x = 0, y = 0) {
            let main = this.$el;
            main.scrollLeft = x;
            main.scrollTop = y;
        },
    },
    computed: {
        headLabel() {
            // label of pull down
            if (this.pullDown.status === STATUS_ERROR) {
                return this.pullDown.msg;
            } else {
                return LABELS[this.pullDown.status + 1];
            }
        },
        footLabel() {
            // label of pull up
            if (this.pullUp.status === STATUS_ERROR) {
                return this.pullUp.msg;
            } else {
                return LABELS2[this.pullUp.status + 1];
            }
        },
        // 下拉刷新图标
        iconClass() {
            if (this.pullDown.status === STATUS_REFRESH) {
                return 'refresh';
            } else if (this.pullDown.status === STATUS_ERROR) {
                return 'delete';
            } else {
                return 'xiala';
            }
        },
        // 加载更多图标
        iconClass2() {
            if (this.pullUp.status === STATUS_REFRESH) {
                return 'refresh';
            } else if (this.pullUp.status === STATUS_ERROR) {
                return 'delete';
            } else {
                return '';
            }
        }
    },
    destroyed() {
        clearInterval(this.pullUp.st);
    },
    mounted() {
        this.$nextTick(() => {
            let _self = this;
            let platform = getPlatform();
            let el = this.$el;
            let pullDownHeader = el.querySelector('.pull-down-header');
            let icon = pullDownHeader.querySelector('.pull-down-content--icon');
            let touchPosition = {
                start: 0,
                distance: 0
            };

            //加载更多
            function checkMore() {
                if (el.scrollHeight - el.scrollTop - el.clientHeight <= 40) {
                    if (_self.pullUp.st) {
                        clearInterval(_self.pullUp.st);
                        _self.pullUp.st = null;
                    }
                    if (_self.pullUp.status == STATUS_FINISH) {
                        return;
                    }
                    if (_self.pullUp.status == STATUS_START || _self.pullUp.status == STATUS_ERROR) {
                        _self.pullUp.status = STATUS_REFRESH;
                        if (_self.onLoadMore && typeof _self.onLoadMore === 'function') {
                            let res = _self.onLoadMore();
                            if (res && res.then && typeof res.then === 'function') {
                                res.then(result => {
                                    if (result == 1) {
                                        _self.pullUp.status = STATUS_FINISH;
                                    } else {
                                        _self.pullUp.status = STATUS_START;
                                    }
                                }, error => {
                                    _self.pullUp.msg = error || LABELS[0];
                                    _self.pullUp.status = STATUS_ERROR;
                                });
                            }
                        } else {
                            _self.pullUp.status = STATUS_START;
                        }
                    }
                }
            }

            el.addEventListener('touchstart', e => {
                touchPosition.start = e.touches.item(0).pageY;
                this.isTop = el.scrollTop > 0 ? false : true;
                if (this.onRefresh) {
                    this.pullDown.hasTransition = false;
                }
                if (this.onLoadMore && !this.pullUp.st && this.pullUp.status != STATUS_FINISH) {
                    this.pullUp.st = setInterval(checkMore, 500);
                }

                

                
                //优化 iOS 滚动问题
                if (platform == 'iOS') {
                    let startTopScroll = el.scrollTop;
                    if (!this.onRefresh) {
                        if (startTopScroll == 0) {
                            el.scrollTop = 1;
                        }
                    }
                    if (startTopScroll + el.offsetHeight >= el.scrollHeight) {
                        el.scrollTop = el.scrollHeight - el.offsetHeight - 1;
                    }
                }
            });

            el.addEventListener('touchmove', e => {
                let distance = (e.touches.item(0).pageY - touchPosition.start) / 2;

                let fix = document.querySelector('.home-search');
                if(fix){
                    if( el.scrollTop > 3){
                        fix.classList.add("fix-home-search");
                    }else{
                        fix.classList.remove("fix-home-search");
                    }
                }

                if (!this.onRefresh) {
                    return;
                }
                if (!this.isTop) {
                    return;
                } else if (distance < 0) {
                    return;
                }
                if (distance > 0) {
                    e.preventDefault();
                }

                distance = distance > 180 ? 180 : distance;
                touchPosition.distance = distance;
                this.pullDown.height = distance;
                if (distance > PULL_DOWN_HEIGHT) {
                    this.pullDown.status = STATUS_READY;
                    icon.style.transform = 'rotate(180deg)';
                } else {
                    this.pullDown.status = STATUS_START;
                    if (distance > 20) {
                        icon.style.transform = 'rotate(' + (distance - 20) / (PULL_DOWN_HEIGHT - 20) * 180 + 'deg)';
                    }
                }
            });

            el.addEventListener('touchend', e => {
                if (this.onRefresh) {
                    this.pullDown.hasTransition = true;
                    icon.style.transform = '';
                }

                if (touchPosition.distance > PULL_DOWN_HEIGHT) {
                    this.pullDown.height = PULL_DOWN_HEIGHT;
                    this.pullDown.status = STATUS_REFRESH;
                    if (this.onRefresh && typeof this.onRefresh === 'function') {
                        let res = this.onRefresh();
                        if (res && res.then && typeof res.then === 'function') {
                            res.then(result => {
                                setTimeout(() => {
                                    resetPullDown(this);
                                    resetPullUp(this, result);
                                }, 500)
                            }, error => {
                                // show error and hide the pull down after 1 second
                                this.pullDown.msg = error || LABELS[0];
                                this.pullDown.status = STATUS_ERROR;
                                setTimeout(() => {
                                    resetPullDown(this);
                                }, 1000);
                            });
                        } else {
                            resetPullDown(this);
                        }
                    } else {
                        resetPullDown(this);
                        console.warn('please use :on-refresh to pass onRefresh callback');
                    }
                } else {
                    resetPullDown(this);
                }
                touchPosition.distance = 0;
                touchPosition.start = 0;
            });

        });
    }
};