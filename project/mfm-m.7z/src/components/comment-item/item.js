import Icon from '../icon';

export default {
    name: 'comment-item',
    props: {
        noPadding: Boolean,
        noCount: Boolean,
        data: Object,
        curName: String,
        noClick: Boolean,
        isBottomBorder: Boolean
    },
    components: { Icon },

    methods: {
        goToDetail(id) {
            if (this.noClick) {
                return;
            }
            this.$util.push(`/commentdetail/${id}`);
        }
    }
}