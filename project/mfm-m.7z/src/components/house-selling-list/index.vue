<template src="./index.html"></template>
<style lang="less" src="./index.less"></style>
<script>
import FooterInfo from '../footer-info';

 export default {
    name: "house_list",
    data(){
        return {
            loadCallBacks: {

            },
            sellStatus: {
                '待摇号': 0,
                '正在报名': 4,
                '摇号完毕': 1
            }
        }
    },
    props: {
        info: Object
    },
    components: {
        FooterInfo,
    },
    methods:{
         goPage(item){
            this.$emit('jumpPage');
            // return;
            this.$util.push(`/housepresell/${item.id}`);
         },
         getScrollPosition(){
            return this.$refs.scroll.getScrollPosition();
         },
         setScrollPosition(x,y){
            this.$refs.scroll && this.$refs.scroll.setScrollPosition(x,y);
         },
         resizeScroll(status){
            this.$refs.scroll && this.$refs.scroll.reset(status);
         },
         loadMore(){
            return new Promise((resolve, reject)=>{
                this.$emit('loadMore',(status)=>{
                    resolve(status);
                });
            });
         },
         pushLoadCallBack(key,fn){
            this.loadCallBacks[key] = fn;
         },
         clearLoadCallBack(key){
            delete this.loadCallBacks[key];
         }
     }
 }
</script>