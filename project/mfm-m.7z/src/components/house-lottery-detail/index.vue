<template src="./index.html"></template>
<style lang="less" src="./index.less"></style>
<script>
export default{
    name: "houseLotteryDetail",
    data(){
        return {
            loadCallBacks:{},
            lotteryType: {
                1: "棚改",
                2: "刚需", 
                3: "普通",
            }
        }
    },
    props: {
        info: Object
    },
    methods:{
         getScrollPosition(){
            return this.$refs.scroll.getScrollPosition();
         },
         setScrollPosition(x,y){
            this.$refs.scroll && this.$refs.scroll.setScrollPosition(x,y);
         },
         resizeScroll(status){
            this.$refs.scroll && this.$refs.scroll.reset(status);
         },
         loadMore(){
            return new Promise((resolve, reject)=>{
                this.$emit('loadMore',(status)=>{
                    resolve(status);
                });
            });
         },
         pushLoadCallBack(key,fn){
            this.loadCallBacks[key] = fn;
         },
         clearLoadCallBack(key){
            delete this.loadCallBacks[key];
         }
     }
 }
</script>