import {mapState} from 'vuex';
export default{
	methods: {
		jumpPage(path){
			this.$emit('jump', path);
			this.$util.push(path);
		},
		showPanel(index){
			if (this.status != 1 && this.nowExhibitions == index) return this.hiddenPanel();
			this.$store.dispatch("HOUSE_SET_NOW_EXHIBITIONS", index);
			this.$store.dispatch("HOUSE_SWITCH_PANEL", index);
			if (this.panel.active && this.panel.active.length == 0) {
				this.updatePanel(0, 0);
				this.panel.active.push(-1);
			}
		},
		hiddenPanel(){
			this.$store.dispatch("HOUSE_SET_NOW_EXHIBITIONS", -1);
			this.$store.dispatch("HOUSE_SEARCH_STATUS", 1);
		},
		updatePanel(index, activeIndex){
			this.$store.commit('SWITCH_PANEL',this.nowExhibitions);
			this.$store.dispatch("HOUSE_UPDATE_PANEL", {
				index: index,
				activeIndex: activeIndex
			});
		},
		searchMore(index, index1){
			this.$store.commit('SWITCH_PANEL',this.nowExhibitions);
			this.$store.dispatch("HOUSE_SET_MORE_SEARCH_ACTIVE", {
				index: index,
				activeIndex: index1
			});
		},
		moreEnd(){
			this.$store.dispatch("HOUSE_UPDATE_SEARCH_STR");
			this.hiddenPanel();
		},
		clearMore(){
			this.panel.map((item,index)=>{
				for(let i = item.active.length-1; i >= 0 ; i--){
					this.searchMore(index,item.active[i]);
				}
			});
		}
	},
	computed: {
		...mapState({
			nowExhibitions: state=>state.houseSearch.nowExhibitions,
			search: state=>state.houseSearch.search,
			panel: state=>state.houseSearch.panel,
			panels: state=>state.houseSearch.panels,
			status: state=>state.houseSearch.status,
			exhibitions: state=>state.houseSearch.exhibitions,
			errorStatus: state=>state.houseSearch.errorStatus,
		})
	},
	preFetch({store,context}){
		store.dispatch('HOUSE_RESIZE_STORE');
		if (store) return Promise.all([
			store.dispatch("HOUSE_INIT", {
				context,
				regionId: context.params.regionId == "_" ? "" : context.params.regionId
			})
		]);
	}
}