'use strict'
const path = require('path')
const webpack = require('webpack')
const AssetsPlugin = require('assets-webpack-plugin')
const GitRevisionPlugin = require('git-revision-webpack-plugin')
const assetsPluginInstance = new AssetsPlugin({
	path: path.join(process.cwd(), 'dist/server')
})
const postcss = [
	require('precss')(),
	require('autoprefixer')({
		remove: false,
		browsers: [
			'Android >= 4',
			'Chrome >= 4',
			'Firefox >= 31',
			'iOS >= 7',
			'Opera >= 12',
			'Safari >= 7.1',
		]
	}),
]

const gitRevisionPlugin = new GitRevisionPlugin({
	versionCommand: 'describe --tags --long'
})

const DEBUG = process.env.NODE_ENV == 'development';

module.exports = {
	entry: [
		'./src/client-entry.js'
	],
	output: {
		path: path.join(process.cwd(), 'dist/static'),
		filename: 'bundle.js',
		publicPath: '/static/'
	},
	resolve: {
		extensions: ['', '.vue', '.js'],
		alias: {
			'utils': path.join(process.cwd(), 'src/utils/utils-client.js'),
		}
	},
	module: {
		loaders: [{
			test: /\.vue$/,
			loaders: ['vue']
		}, 
		{
			test: /\.js$/,
			loaders: ['babel'],
			exclude: [/node_modules/]
		}, 
		{
			test: /\.css$/,
			loader: 'style-loader!css-loader'
		},
		{
			test: /\.(png|jpg|gif|svg)$/,
			loader: 'url?limit=10000&name=images/[hash:7].[ext]',
			include: path.src,
		}, 
		{
			test: /\.woff($|\?)|\.woff2($|\?)|\.ttf($|\?)|\.eot($|\?)|\.svg($|\?)/,
			loader: 'url-loader',
			include: path.src,
		}]
	},
	postcss,
	vue: {
		postcss,
		loaders: [{
			test: /\.css$/,
			loader: 'style-loader!css-loader'
		}]
	},
	plugins: [
		new webpack.DefinePlugin({
			'VERSION': JSON.stringify(gitRevisionPlugin.version())
		}),
		...DEBUG ? [] : [assetsPluginInstance]
	]
}