export const port = process.env.PORT || 8088;
export const localhost = process.env.localhost ? `${process.env.localhost}` : `http://127.0.0.1:${port}`;
export const cdnHost = process.env.cdnHost || '';
export const redisConfig = {
    host: process.env.redisHost || "192.168.10.239", // 192.168.10.238
    port: process.env.redisPort || 6379, // 11001
    db: process.env.redisDB || 2,
    ttl: process.env.redisTTL || 30 * 24 * 60 * 60, // 单位：s  30天
};

let version = "1.0.0", //接口版本
    cityId = 51010000, //城市id: 51010000,成都
    deviceType = 2, //设备类型
    encryMode = 2,
    postHost = process.env.postHost || `http://127.0.0.1:${port}`, //本机服务端请求地址
    javaHost = process.env.javaHost || "http://mfmplatforms.test1.maifangma.com", //java api接口地址
    // javaHost = process.env.javaHost || "http://192.168.10.139:8081", //pc 指向周波电脑

    activeHost = process.env.activeHost || "http://activity.test1.maifangma.com", //活动接口 地址
    utilHost = process.env.utilHost || "http://passport.test1.maifangma.com", //工具接口 登陆 短信验证
    // utilHost = process.env.utilHost || "http://dev.passport.maifangma.com", // 开发环境 工具接口 登陆 短信验证
    // javaHost = process.env.javaHost || "http://dev.platforms.maifangma.com", //java api接口地址
    // activeHost = process.env.activeHost || "http://dev.activity.maifangma.com", //活动接口 地址
    
    // 没有使用pc接口
    // pcHost = process.env.webHost || "http://192.168.10.75:8091", //pc 指向张浩亮电脑
    // pcHost = process.env.webHost || "http://192.168.10.88", //pc 指向何洋电脑
    // pcHost = process.env.webHost || "http://dev.mfmweb.maifangma.com", //pc 端接口地址
    pcHost = process.env.webHost || "http://mfmweb.test1.maifangma.com", //测试环境
    // http://mfmplatforms.test1.maifangma.com
    bmapiHost = process.env.bmapiHost || "http://bmapi.test1.chuangjia.me", //线索收集
    requestTimeout = 20000; //超时时间

/**
 * 代理公共参数
 */
export default {
    deviceType,
    version,
    cityId,
    encryMode,
}

/**
 * 接口地址
 */
export {
    postHost,
    javaHost,
    activeHost,
    utilHost,
    requestTimeout,
    pcHost,
    bmapiHost,
}