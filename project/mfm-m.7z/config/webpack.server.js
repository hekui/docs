'use strict'
const path = require('path')
const externals = require('webpack-node-externals')
const webpack = require('webpack')
const postcss = [
	require('precss')(),
	require('autoprefixer')({
		remove: false,
		browsers: [
			'Android >= 4',
			'Chrome >= 4',
			'Firefox >= 31',
			'iOS >= 7',
			'Opera >= 12',
			'Safari >= 7.1',
		]
	}),
]
module.exports = {
  target: 'node',
  entry: [
    './server/index.js'
  ],
  output: {
    path: path.join(process.cwd(), 'dist/server'),
    filename: 'index.js'
  },
  resolve: {
    extensions: ['', '.vue', '.js', '.json'],
    alias: {
      'utils': path.join(process.cwd(), 'src/utils/utils-server.js'),
    }
  },
  module: {
    loaders: [{
      test: /\.json$/,
      loaders: ['json']
    }, {
      test: /\.vue$/,
      loaders: ['vue']
    }, {
      test: /\.js$/,
      loaders: ['babel'],
      exclude: [/node_modules/]
    },
    {
			test: /\.css$/,
			loader: 'style-loader!css-loader'
		},]
  },
  postcss,
	vue: {
		postcss,
		loaders: [{
			test: /\.css$/,
			loader: 'style-loader!css-loader'
		}]
	},
  externals: [externals()],
  plugins: []
}