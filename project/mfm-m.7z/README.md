# 买房吗移动端

服务端和客户端同时渲染 
使用 Vue2, Vuex, Vue-router, Express and Webpack 2

## 特征

- Vue 2 + ES6 + Webpack
- Express + ES6 + Webpack
- Nodemon
- **Hot Reloading**
- Optimized for production use

## 用法

```bash
# 运行开放服务器
# http://localhost:8080
$ npm run dev

# 构建服务端和客户端（生产环境）
# 生成文件放在 ./dist
$ npm run build

# 运行
$ npm run start
```

## 环境变量
```
PORT            服务端口
redisHost:      redis主机
redisPort:      redis端口
redisDB:        redis表
redisTTL:       redis 过期时间
cdnHost:        CDN 地址
javaHost        java api接口地址
activeHost      活动接口地址
utilHost        工具接口 登陆 短信验证
webHost         PC 端接口地址
bmapiHost       线索收集

```