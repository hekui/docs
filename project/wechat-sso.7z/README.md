# 微信 SSO 登录服务

## 安装

```bash
npm install
```

## 说明

开发模式
```bash
npm run dev
```
运行
```bash
npm run start
```

## 配置说明

配置环境变量
```bash
redisHost     redis 主机
redisPort     redis 端口
redisDB       redis 表
appId         微信 appId
appSecret     微信 appSecret
secret        加密字符串
webUrl        当前服务器地址，微信登录回调用
interfaceUrl  关注和取消关注调用的接口，用于获取 openid，小程序推送
```

## 请求接口

### /getbase 基本登录

未登录时，返回
```json
{
    "code":200,
    "ssid":"6d5cfd90-080c-11e7-ac5a-a1a0a5faf7f6",
    "url": "url"    //微信授权页面
}
```

登录后
```json
{
    "code":200,
    "ssid":"6d5cfd90-080c-11e7-ac5a-a1a0a5faf7f6"
}
```

### /getuser 获取用户信息

未登录时，返回
```json
{
    "code":200,
    "ssid":"6d5cfd90-080c-11e7-ac5a-a1a0a5faf7f6",
    "url": "url"    //微信授权页面
}
```

登录后
```json
{
    "code":200,
    "ssid":"6d5cfd90-080c-11e7-ac5a-a1a0a5faf7f6",
    "user":
    {
        "nickname":"Hao",
        "sex":1,
        "language":"zh_CN",
        "city":"Chengdu",
        "province":"Sichuan",
        "country":"China","headimgurl":"http://wx.qlogo.cn/mmopen/Q3auHgzwzM63awPWa4tjzmU1GwMS5kRzvTC1w4VCU2kBXFSHUOsyFlYB07vtb1Fwa2LMj1puz2J2Fxgen3XAtA/0","privilege":"",
        "uid":"3913ba8edeb474eb53968e30bad8b307"
    }
}
```

### /sign 获取签名

```json
{
    "code":200,
    "sign":
    {
        "nonceStr":"x9xirho4qcoozub",
        "timestamp":"1489423398",
        "url":"http://127.0.0.1/sign",
        "signature":"467d3dbaf83f068e0254c277b4bbc1d5bfdb4307",
        "appId":"wx305ddc665020b5ff"
    }
}
```

### /pay/config 获取支付配置

参数：
```bash
notify_url      //回调
body            //名称
attach          //
out_trade_no    //订单 No
fee             //金额
```

```json
{
    "code":200,
    "body":
    {
    }
}
```