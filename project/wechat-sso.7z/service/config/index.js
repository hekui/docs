import fs from 'fs';

const
    // redisConfig = {
    //     host: process.env.redisHost || "192.168.10.239",
    //     port: process.env.redisPort || 6379,
    //     db: process.env.redisDB || 6
    // },
    // wxConfig = {
    //     appId: process.env.appId || 'wx305ddc665020b5ff',
    //     appSecret: process.env.appSecret || 'e438a79410b128d687efeca12420447b',
    //     partnerKey: process.env.partnerKey || 'cjlivecjlivecjlivecjlivecjlivecj',
    //     mchId: process.env.mchId || '1374183402', //商户号
    //     pfx: fs.readFile(__dirname + '/keys/apiclient-cert.p12'), //支付证书
    //     token: process.env.token || 'cjlive666', //接口服务器 Token
    // },
    // interfaceUrl = process.env.interfaceUrl || 'https://api-proxy.test1.maifangma.com/broker/broker/bingding',
    // secret = process.env.secret || 'chuangjia No.1',
    // webUrl = process.env.webUrl || 'http://127.0.0.1:3000',
    // accessTokenTTL = 600,
    // 买房吗配置
    redisConfig = {
        host: process.env.redisHost || "192.168.10.239",
        port: process.env.redisPort || 6379,
        db: process.env.redisDB || 4
    },
    wxConfig = { // 买房吗
        appId: process.env.appId || 'wxb91f62f0fee58dc0',
        appSecret: process.env.appSecret || '15cbe8a6c97021c5fe685e8c72ac4c31',
        partnerKey: process.env.partnerKey || 'cjlivecjlivecjlivecjlivecjlivecj',
        mchId: process.env.mchId || '1359109902', //商户号
        pfx: fs.readFile(__dirname + '/keys/apiclient-cert.p12'), //支付证书
        token: process.env.token || 'cjlive666', //接口服务器 Token
    },
    interfaceUrl = process.env.interfaceUrl || 'https://api-proxy.test1.maifangma.com/broker/broker/bingding',
    secret = process.env.secret || 'wks0d2f9s9',
    webUrl = process.env.webUrl || 'https://zt.maifangma.com/wxsso',
    accessTokenTTL = 600;

export {
    redisConfig,
    wxConfig,
    interfaceUrl,
    secret,
    webUrl,
    accessTokenTTL,
}