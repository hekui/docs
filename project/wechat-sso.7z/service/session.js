import {
    getSession,
    saveSession,
    getSSID,
} from './utils';

function session(req, res, next) {
    if (['/sign', '/shorturl'].indexOf(req.path) > -1) {
        next();
    } else {
        let query = req.query;
        //微信回调时修正 ssid
        if (query.state) {
            query.ssid = query.state;
        }

        req.on("end", function () {
            saveSession(req.ssid, req.session);
        })

        if (query.ssid) {
            getSession(query.ssid)
                .then(_session => {
                    req.ssid = _session.ssid;
                    req.session = _session;
                    next();
                })
                .catch(() => {
                    req.ssid = getSSID();
                    req.session = {
                        ssid: req.ssid
                    };
                    next();
                })
        } else {
            req.ssid = getSSID();
            req.session = {
                ssid: req.ssid
            };
            next()
        }
    }
}

export default session;