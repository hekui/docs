import express from 'express';
import bodyParser from 'body-parser';
import route from './route';
import session from './session';

const port = process.env.PORT || 3000
const app = express();
app.set('x-powered-by', false);
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
	extended: true
}));
app.use(bodyParser.json());
app.use(function (req, res, next) {
	// console.log('path:', req.path);
	// console.log('originalUrl:', req.originalUrl);
	// console.log('hostname:', req.hostname);
	// console.log('headers:', req.headers);
	res.set({
		// "Access-Control-Allow-Origin": "*",
		"Access-Control-Allow-Credentials": true,
		"Access-Control-Allow-Origin": req.headers.origin,
		"Access-Control-Allow-Headers": "Content-Type,Content-Length, Authorization,'Origin',Accept,X-Requested-With",
		"Access-Control-Allow-Methods": "*",
	})

	next();
});

//处理自定义 session
app.use(session);

app.use(route);

app.listen(port, function (err) {
	if (err) {
		console.log(err)
		return
	}
	console.log(`server listen at http://localhost:${port}/` )
});