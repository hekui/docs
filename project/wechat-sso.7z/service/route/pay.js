import requestIp from 'request-ip';
import express from 'express';
import fetch from 'node-fetch';
import Payment from '../lib/payment';
import Middleware from '../lib/middleware';
import {
    wxConfig,
    webUrl,
} from '../config';

import {
    getAuthorizeURL,
    getOpenID,
    getUser,
    setTemp,
    getTemp,
} from '../utils';

const router = express.Router();
const payment = new Payment(wxConfig);

/**
 * 进行支付
 */
router.get('/config', async function (req, res, next) {
    let query = req.query;
    let openid = req.session.openid;

    if (openid) {
        let order = {
            body: query.body,
            detail: query.detail,
            attach: query.attach || '{}',
            out_trade_no: query.out_trade_no || ('CJ' + (+new Date)),
            total_fee: query.total_fee,
            spbill_create_ip: requestIp.getClientIp(req),
            openid: openid,
            trade_type: query.trade_type || 'JSAPI',
            // notify_url: webUrl + '/pay/back',
            notify_url: query.notify_url, // 直接使用给定回调
        };

        payment.getBrandWCPayRequestParams(order, function (err, payargs) {

            console.log('err', err)
            console.log('payargs', payargs)
            if (err) {
                res.json({
                    code: 100,
                    msg: err.message
                });
            } else {
                setTemp('notifyUrl:' + order.out_trade_no, decodeURIComponent(query.notify_url));
                res.json({
                    code: 200,
                    body: {
                        config: payargs,
                    }
                });
            }
        });
    } else {
        req.session.originUrl = req.headers.referer;
        console.log('need login')
        let _url = getAuthorizeURL(webUrl + '/login', req.ssid, 'snsapi_base');

        res.json({
            code: 201,
            ssid: req.ssid,
            url: _url
        });
    }
})

/**
 * APP 支付
 */
router.get('/appconfig', async function (req, res, next) {
    let ip = requestIp.getClientIp(req);
    // let ip = '127.0.0.1' || requestIp.getClientIp(req);
    let body = req.query;
    let order = {
        body: body.body,
        attach: body.attach || '{}',
        out_trade_no: body.out_trade_no || ('CJ' + (+new Date)),
        total_fee: body.total_fee,
        spbill_create_ip: ip,
        trade_type: body.trade_type || 'APP',
        notify_url: webUrl + '/pay/back',
    };

    payment.getBrandWCPayRequestParams(order, function (err, payargs) {
        if (err) {
            console.log(err);
            res.json({
                code: 100,
                msg: err.message
            });
        } else {
            setTemp('notifyUrl:' + order.out_trade_no, decodeURIComponent(body.notify_url));
            res.json({
                code: 200,
                body: payargs,
            });
        }
    });
})

/**
 * 接收微信付款确认请求
 */
router.use('/back', Middleware(wxConfig).getNotify().done(function (message, req, res, next) {
    var openid = message.openid;
    var order_id = message.out_trade_no;
    var attach = {};
    try {
        attach = JSON.parse(message.attach);
    } catch (e) {}

    console.log("Pay back:", order_id);

    getTemp('notifyUrl:' + order_id, function (err, result) {
        console.log("Pay back result:", err, result);
        if (err) {
            console.log("通知地址获取失败", new Date());
            res.reply(new Error('通知地址获取失败'));
        } else {
            if (result) {
                console.log('JSON.stringify(message)', JSON.stringify(message))
                fetch(result, {
                        method: 'POST',
                        body: JSON.stringify(message),
                        headers: {
                            'Content-Type': 'application/json'
                        },
                    })
                    .then(_res => {
                        return _res.json();
                    })
                    .then(_json => {
                        if (_json.code == 200) {
                            res.reply('success');
                        } else {
                            res.reply(new Error(_json.msg || '失败'))
                        }
                    })
                    .catch(_err => {
                        console.log("回调服务错误", new Date());
                        console.log(_err);
                        res.reply(new Error('通知失败'))
                    })
            } else {
                console.log('没有通知地址', new Date());
                res.reply(new Error('没有通知地址'))
            }
        }
    });
}));

/**
 * 订单查询
 */
router.get("/orderQuery", async function (req, res, next) {
    payment.orderQuery(req.query, function (err, result) {
        if (err) {
            res.json({
                code: 100,
                msg: err.message
            });
        } else {
            res.json({
                code: 200,
                body: result
            });
        }
    })
})

/**
 * 下载订单
 */
router.get("/bill", async function (req, res, next) {
    payment.downloadBill(req.query, function (err, result) {
        if (err) {
            res.json({
                code: 100,
                msg: err.message
            });
        } else {
            res.json({
                code: 200,
                body: result
            });
        }
    })
})

export default router;