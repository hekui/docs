import express from 'express';

import {
    pushMessage,
} from '../utils';

const router = express.Router();

/**
 * 消息推送
 */

// var exampleData = {
//     "touser": "oEw5Fw7207jwh9y0UJEwMGg3_mDI",
//     "template_id": "hnMnm5ffXrrdiosZ-Q2-s-HsOcCR51TAf5FfTwIkA5w",
//     "data": {
//         "first": {
//             "value": "你好，有新的公司公告发布",
//             "color": "#173177"
//         },
//         "keyword1": {
//             "value": "填写公告标题",
//             "color": "#FF0000"
//         },
//         "keyword2": {
//             "value": "公司公告",
//             "color": "#173177"
//         },
//         "remark": {
//             "value": "请尽快查看，感谢！",
//             "color": "#173177"
//         }
//     }
// }

router.post('/', async function (req, res, next) {
    let messageObj = Object.assign({}, req.body);
    pushMessage(messageObj).then(_url => {
        res.json({
            code: 200,
            url: _url,
        })
    }).catch(_err => {
        res.json({
            code: 100,
            msg: _err || '获取错误'
        })
    })
})


export default router;