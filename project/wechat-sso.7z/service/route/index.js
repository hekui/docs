import login from './login';
import pay from './pay';
import sign from './sign';
import shorturl from './shorturl';
import push from './push';
import wxInterface from './interface';
import express from 'express';
const router = express.Router();

router.use('/', login);
router.use('/sign', sign);
router.use('/pay', pay);
router.use('/shorturl', shorturl);
router.use('/push', push);
router.use('/interface', wxInterface);

export default router;