import XMLJS from 'xml2js';
import sha1 from 'sha1';
import express from 'express';
import fetch from 'node-fetch';
import {
    wxConfig,
    interfaceUrl,
} from '../config';
import {
    getUserByOpenID,
} from '../utils';
const parser = new XMLJS.Parser();
const builder = new XMLJS.Builder();
const router = express.Router();

function checkSignature(params, signature) {
    if (!Array.isArray(params)) {
        return false;
    }
    params.push(wxConfig.token);
    params.sort();
    let mySignature = sha1(params.join(''));
    return mySignature === signature;
}

//验证 Token 用
router.get('/', function (req, res, next) {
    //获取参数
    var query = req.query;
    //签名
    var signature = query.signature;
    var echostr = query.echostr;
    var oriArray = [query.nonce, query.timestamp];

    if (checkSignature(oriArray, signature)) {
        res.end(echostr);
    } else {
        res.end("Bad Token!");
    }
})

//微信事件推送的入口
router.post('/', function (req, res, next) {
    //获取参数
    var query = req.query;
    //签名
    var signature = query.signature;
    var echostr = query.echostr;
    var oriArray = [query.nonce, query.timestamp];

    //判断是否与你填写TOKEN相等
    if (checkSignature(oriArray, signature)) {
        //获取xml数据
        req.on("data", function (data) {
            //将xml解析
            parser.parseString(data.toString(), function (err, result) {
                if (!err) {
                    var body = result.xml;
                    var messageType = body.MsgType[0];
                    //用户点击菜单响应事件
                    if (messageType === 'event') {
                        var eventName = body.Event[0];
                        (EventFunction[eventName] || function () {})(body, req, res);
                        //自动回复消息
                    } else if (messageType === 'text') {
                        // EventFunction.responseNews(body, res);
                        //第一次填写URL时确认接口是否有效
                        res.end('ok');
                    } else {
                        res.end(echostr);
                    }
                } else {
                    var xml = {
                        xml: {
                            Content: 'OK'
                        }
                    };
                    xml = builder.buildObject(xml); //发送给微信
                    res.end(xml);
                }
            });
        });
    } else {
        //认证失败，非法操作
        res.end("Bad Token!");
    }
});

//微信客户端各类回调用接口
var EventFunction = {
    //关注
    subscribe: function (result, req, res) {
        //存入openid 通过微信的接口获取用户的信息同时存入数据库。
        getUserByOpenID(result.FromUserName[0])
            .then(_res => {
                fetch(interfaceUrl, {
                        method: "POST",
                        body: JSON.stringify({
                            openidServer: _res.openid,
                            unionid: _res.unionid,
                        }),
                        headers: {
                            'Content-Type': 'application/json; charset=utf-8'
                        }
                    })
                    .then(_res => {
                        return _res.json();
                    })
                    .then(_json => {
                        // console.log(_json)
                    })
                    .catch(_err => {
                        console.log(_err);
                    })
            }).catch(err => {
                console.log(err);
            })
        res.end('ok');
    },
    //注销
    unsubscribe: function (openid, req, res) {
        //删除对应id
        res.end('ok');
    },
    //打开某个网页
    VIEW: function () {
        //根据需求，处理不同的业务
    },
    //自动回复
    // responseNews: function (body, res) {
    //     //组装微信需要的json
    //     var xml = {
    //         xml: {
    //             ToUserName: body.FromUserName,
    //             FromUserName: body.ToUserName,
    //             CreateTime: +new Date(),
    //             MsgType: 'text',
    //             Content: '编辑@+您想说的话，我们可以收到'
    //         }
    //     };
    //     var reciviMessage = body.Content[]
    //     if (/^\@.*/.test(reciviMessage)) {
    //         xml.xml.Content = '已经收到您的建议，会及时处理！'
    //     } //将json转为xml
    //     xml = builder.buildObject(xml); //发送给微信
    //     res.send(xml);
    // }
}

export default router;