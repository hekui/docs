import OAuth from '../lib/oauth';
import express from 'express';
import {
    wxConfig,
    webUrl,
} from '../config';
import {
    getAuthorizeURL,
    getOpenID,
    getUser,
    getTicket,
    md5,
} from '../utils';
import sign from '../lib/sign';

const router = express.Router();

/**
 * 获取用户信息
 */
router.get('/getuser', async function (req, res, next) {
    let query = req.query;

    if (req.session.user) {
        let _user = Object.assign({}, req.session.user);
        // _user.uid = md5(_user.openid);
        _user.uid = _user.openid;
        delete _user.openid;
        res.json({
            code: 200,
            ssid: req.ssid,
            user: _user
        })
    } else {
        req.session.originUrl = req.headers.referer;
        let _url = getAuthorizeURL(webUrl + '/login', req.ssid, 'snsapi_userinfo');

        res.json({
            code: 201,
            ssid: req.ssid,
            url: _url
        });
    }
});

/**
 * 微信认证后登录
 */
router.get('/login', async function (req, res, next) {
    let query = req.query;
    console.log('query', query)
    if (query.code && req.session.originUrl) {
        let _result = await getUser(query.code);
        console.log('in router.login:')
        console.log('_result', _result)
        if (_result) {
            req.session.openid = _result.openid;
            req.session.user = _result;
            res.redirect(req.session.originUrl);
        } else {
            res.end('No User');
        }
    } else {
        res.end('Code Error');
    }
})

/**
 * 获取用户标示
 * 只获取 openid
 */
router.get('/getbase', async function (req, res, next) {
    let query = req.query;

    if (req.session.openid) {
        let _user = {
            // uid: md5(_user.openid)
            uid: _user.openid
        }
        res.json({
            code: 200,
            user: _user,
            ssid: req.ssid,
        })
    } else {
        req.session.originUrl = req.headers.referer;
        let _url = getAuthorizeURL(webUrl + '/loginbase', req.ssid, 'snsapi_base');

        res.json({
            code: 201,
            ssid: req.ssid,
            url: _url
        });
    }
})

/**
 * 微信认证登录
 * 只获取 openid
 */
router.get('/loginbase', async function (req, res, next) {
    let query = req.query;
    console.log('in loginbase query', query)
    if (query.code && req.session.originUrl) {
        let _result = await getOpenID(query.code);
        if (_result) {
            req.session.openid = _result.openid;
            res.redirect(req.session.originUrl);
        } else {
            res.end('No Got User');
        }
    } else {
        res.end('Code Error');
    }
})

export default router;