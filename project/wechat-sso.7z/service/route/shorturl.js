import express from 'express';

import {
    getShortUrl,
} from '../utils';

const router = express.Router();

/**
 * 短链接生成
 */
router.get('/', async function (req, res, next) {
    let query = req.query;
    getShortUrl(query.url).then(_url => {
        res.json({
            code: 200,
            url: _url,
        })
    }).catch(_err => {
        res.json({
            code: 100,
            msg: _err || 'URL获取错误'
        })
    })
})


export default router;