import express from 'express';
import {
    wxConfig,
    webUrl,
} from '../config';
import {
    getTicket,
} from '../utils';
import sign from '../lib/sign';

const router = express.Router();

/**
 * 公众号接口签名
 * sign
 */
router.get('/', async function (req, res, next) {
    getTicket().then(_ticket => {
        let _sign = sign(_ticket, req.headers.referer);
        _sign.appId = wxConfig.appId;
        delete _sign.jsapi_ticket;
        res.json({
            code: 200,
            ssid: req.ssid,
            sign: _sign,
        })
    }).catch(e => {
        res.json({
            code: 100,
            ssid: req.ssid,
            msg: '签名错误'
        })
    })
})


export default router;