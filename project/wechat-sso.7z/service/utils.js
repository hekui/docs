import crypto from 'crypto';
import redis from "redis";
import uuid from 'uuid';
import fetch from 'node-fetch';
import OAuth from './lib/oauth';
import {
    redisConfig,
    wxConfig,
    secret,
    webUrl,
    accessTokenTTL,
} from './config';

const ticketName = 'wx-Ticket:' + md5(webUrl).substring(1, 9);
const accessTokenName = 'wx-AccessToken:' + md5(webUrl).substring(1, 9);

// redis 实例
const redisClient = redis.createClient(redisConfig);
redisClient.on("error", function (err) {
    console.log("Redis Error: ", err);
});

function getSession(ssid) {
    return new Promise(function (resolve, reject) {
        if (ssid) {
            redisClient.get("SSID:" + ssid, function (err, report) {
                if (report) {
                    resolve(JSON.parse(report));
                } else {
                    reject(false);
                }
            });
        } else {
            reject(false);
        }
    })
}

function saveSession(ssid, session) {
    return new Promise(function (resolve, reject) {
        redisClient.set("SSID:" + ssid, JSON.stringify(session), function () {
            redisClient.expire("SSID:" + ssid, 2592000 * 1); //缓存1个月
            resolve(true);
        });
    })
}

// 创建一个新的 ssid
function getSSID() {
    return uuid.v1();
}

/**
 * 设置临时变量
 * @param {*} key 
 * @param {*} value 
 * @param {*} callback 
 */
function setTemp(key, value, callback) {
    redisClient.set("Temp:" + key, value, function () {
        redisClient.expire("Temp:" + key, 7200);
        callback && callback();
    });
}
/**
 * 获取临时变量
 * @param {*} key 
 * @param {*} callback 
 */
function getTemp(key, callback) {
    redisClient.get("Temp:" + key, function (err, report) {
        if (err) {
            callback && callback(err);
        } else {
            callback && callback(null, report);
        }
    });
}

// 微信认证实例
const authClient = new OAuth(wxConfig.appId, wxConfig.appSecret, function (openid, callback) {
    redisClient.get("wxsso:" + openid, function (err, report) {
        console.log('in redisClient.get')
        console.log('err:', err)
        console.log('report:', report)
        if (err) {
            callback && callback(err);
        } else {
            callback && callback(null, JSON.parse(report));
        }
    });
}, function (openid, token, callback) {
    redisClient.set("wxsso:" + openid, JSON.stringify(token), function () {
        redisClient.expire("wxsso:" + openid, 7000);
        callback && callback();
    });
});

function getAuthorizeURL(redirectUrl, state, scope) {
    return authClient.getAuthorizeURL(redirectUrl, state, scope)
}

function getAuthorizeURLForWebsite(redirectUrl, state, scope) {
    return authClient.getAuthorizeURLForWebsite(redirectUrl, state, scope)
}

// 加密
function encode(_str) {
    const cipher = crypto.createCipher('aes192', secret);
    let encrypted = cipher.update(_str, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

// 解密
function decode(_str) {
    const decipher = crypto.createDecipher('aes192', secret);
    let decrypted = decipher.update(_str, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

//md5
function md5(str) {
    let md5sum = crypto.createHash('md5');
    md5sum.update(str);
    str = md5sum.digest('hex');
    return str;
}

// 获取用户信息
function getOpenID(code) {
    return new Promise(function (resolve, reject) {
        authClient.getAccessToken(code, function (err, result) {
            if (!err) {
                resolve({
                    accessToken: result.data.access_token,
                    openid: result.data.openid
                })
            } else {
                reject(false);
            }
        })
    })
}

// 获取 OpenID 
function getUser(code) {
    return new Promise(function (resolve, reject) {
        authClient.getUserByCode(code, function (err, result) {
            console.log('in getUser:')
            console.log('err', err)
            console.log('result', result)
            if (!err) {
                resolve(result);
            } else {
                reject(false);
            }
        });
    })
}

// 获取用户信息
function getUserByOpenID(_openid) {
    return new Promise(function (resolve, reject) {
        getAccessToken().then((accessToken) => {
            fetch(`https://api.weixin.qq.com/cgi-bin/user/info?access_token=${accessToken}&openid=${_openid}&lang=zh_CN `)
                .then(_res => {
                    return _res.json();
                })
                .then(_json => {
                    resolve(_json);
                })
                .catch(e => {
                    reject(e);
                })
        })
    })
}

// 获取网页授权 AccessToken
function getAccessTokenSSO(openid) {
    return new Promise(function (resolve, reject) {
        authClient.getAccessTokenByOpenID(openid, function (err, result) {
            if (!err) {
                resolve(result);
            } else {
                reject(false);
            }
        })
    })
}

// 获取公众号 AccessToken
function getAccessToken() {
    return new Promise(function (resolve, reject) {
        redisClient.get(accessTokenName, function (err, report) {
            if (report) {
                resolve(report);
            } else {
                fetch(`https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${wxConfig.appId}&secret=${wxConfig.appSecret}`)
                    .then(_res => {
                        return _res.json();
                    })
                    .then(_json => {
                        redisClient.set(accessTokenName, _json.access_token, function () {
                            redisClient.expire(accessTokenName, accessTokenTTL);
                            resolve(_json.access_token);
                        });
                    })
                    .catch(e => {
                        reject(e);
                    })
            }
        });
    })
}

// 获取 jsapi_ticket
function getTicket() {
    return new Promise(function (resolve, reject) {
        redisClient.get(ticketName, function (err, report) {
            if (report) {
                resolve(report);
            } else {
                getAccessToken().then(_token => {
                    fetch(`https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=${_token}&type=jsapi`)
                        .then(_res => {
                            return _res.json();
                        })
                        .then(_json => {
                            if (_json.errcode == 0) {
                                redisClient.set(ticketName, _json.ticket, function () {
                                    redisClient.expire(ticketName, 7000);
                                    resolve(_json.ticket);
                                });
                            } else {
                                reject();
                            }
                        })
                        .catch(e => {
                            reject(e);
                        })
                }).catch(_err => {
                    reject(_err);
                })
            }
        });
    })
}

//Url短地址
function getShortUrl(longUrl) {
    return new Promise(function (resolve, reject) {
        if (longUrl) {
            getAccessToken()
                .then(_token => {

                    let postData = {
                        access_token: _token,
                        action: 'long2short',
                        long_url: longUrl,
                    };
                    fetch(`https://api.weixin.qq.com/cgi-bin/shorturl?access_token=${_token}`, {
                            method: 'POST',
                            body: JSON.stringify(postData),
                            headers: {
                                'Content-Type': 'application/json'
                            },
                        })
                        .then(_res => {
                            return _res.json();
                        })
                        .then(_json => {
                            if (_json.errcode == 0) {
                                resolve(_json.short_url);
                            } else {
                                reject(_json.errmsg);
                            }
                        })
                        .catch(e => {
                            reject(e.message || '请求错误');
                        })
                })
                .catch(() => {
                    reject(err);
                })
        } else {
            reject('没有URL');
        }
    })
}

//消息推送
function pushMessage(pushData) {
    return new Promise(function (resolve, reject) {
        if (pushData) {
            getAccessToken()
                .then(_token => {
                    let postData = Object.assign({}, pushData);
                    fetch(`https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=${_token}`, {
                            method: 'POST',
                            body: JSON.stringify(postData),
                            headers: {
                                'Content-Type': 'application/json'
                            },
                        })
                        .then(_res => {
                            return _res.json();
                        })
                        .then(_json => {
                            if (_json.errcode == 0) {
                                resolve(_json.short_url);
                            } else {
                                reject(_json.errmsg);
                            }
                        })
                        .catch(e => {
                            reject(e.message || '请求错误');
                        })
                })
                .catch(() => {
                    reject(err);
                })
        } else {
            reject('没有内容');
        }
    })
}

export {
    encode,
    decode,
    md5,
    getAuthorizeURL,
    getAuthorizeURLForWebsite,
    getSession,
    saveSession,
    getSSID,
    getOpenID,
    getUser,
    getUserByOpenID,
    getAccessToken,
    getTicket,
    getShortUrl,
    setTemp,
    getTemp,
    pushMessage,
}