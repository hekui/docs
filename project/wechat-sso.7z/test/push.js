const fetch = require('node-fetch');

var _postData = {
    "touser": "ox5zYviEb0iIyjHCgTdPEPBfLkyU",
    "template_id": "hnMnm5ffXrrdiosZ-Q2-s-HsOcCR51TAf5FfTwIkA5w",
    // "url": "http://m.fangguangcha.com",
    "miniprogram": {
        "appid": "wx13fd95a9af05f428"
        // "pagepath": "/pages/index/index"
    },
    "data": {
        "first": {
            "value": "你好，有新的公司公告发布",
            "color": "#173177"
        },
        "keyword1": {
            "value": "填写公告标题",
            "color": "#FF0000"
        },
        "keyword2": {
            "value": "公司公告",
            "color": "#173177"
        },
        "keyword3": {
            "value": "2017-12-15 15:30",
            "color": "#173177"
        },
        "remark": {
            "value": "请尽快查看，感谢！",
            "color": "#173177"
        }
    }
};

fetch("https://zt.maifangma.com/wxsso/push", {
        method: "POST",
        body: JSON.stringify(_postData),
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        }
    })
    .then(_res => {
        return _res.json();
    })
    .then(_json => {
        console.log(_json)
    })
    .catch(_err => {
        console.log(_err);
    })