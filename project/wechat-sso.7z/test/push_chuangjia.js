const fetch = require('node-fetch');

var _postData = {
  // "touser": "oEw5Fw0XGNZG4Zj1CTk0IPya7Q_U", // 何奎
  // "touser": "oEw5FwzrSk-4biMCjZL5lGR5uK5Q", // 唐肖测试号
  "touser": "oEw5Fw3ff6OSJ-mIQcXiZHAisxS4", // 运营 贺贺
  "template_id": "T3zw9gCG5zauY38Wfu0PXRpgRNc-XSYxnsLIxiPIcmg",
  "data": {
    "first": {
      "value": "您收到了一条新的订单。",
      "color": "#173177"
    },
    "tradeDateTime": {
      "value": new Date(),
      "color": "#FF0000"
    },
    "orderType": {
      "value": '测试标题',
      "color": "#173177"
    },
    "customerInfo": {
      "value": '测试用户名',
      "color": "#173177"
    },
    "orderItemName": {
      "value": "客户邮箱"
    },
    "orderItemData": {
      "value": 'aaa@163.com'
    },
    "remark": {
      "value": "请及时处理！"
    }
  }
};

fetch("https://prj.chuangjia.me/wxsso/push", {
        method: "POST",
        body: JSON.stringify(_postData),
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        }
    })
    .then(_res => {
        return _res.json();
    })
    .then(_json => {
        console.log(_json)
    })
    .catch(_err => {
        console.log(_err);
    })
