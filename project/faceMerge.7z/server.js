const express = require('express')
const app = express()
const port = '3009'

const axios = require('axios')

app.use(function (req, res, next) {
  res.set({
    'Access-Control-Allow-Origin': req.headers.origin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE',
    'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept',
  })
  next();
});

app.use(express.static(__dirname))


app.get('/', function(){
  var plateformApi = 'http://api.youtu.qq.com/cgi-bin/pitu_open_access_for_youtu.fcg'
  var config = {
    appId: '10117786',

  }

  var request = {
    app_id: config.appId,
    img_data: "xxxx...", // base64 编码后的输入图像
    rsp_img_type: "url",
    opdata: [{           // 注意opdata是一个数组
      cmd: "doFaceMerge",
      params: {
        model_id: "hezuo_junzhuangzhao_2007m_20170919141654" // 通用模板id
      }
    }]
  }
  axios.post(plateformApi, {
    Authorization: 
  })
})

app.listen(port, () => {
  console.log(`server started at localhost:${port}`)
})