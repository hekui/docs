const data = {
  curPage: 1,
  hasNext: true,
  hasPrevious: false,
  nextPage: 2,
  pageSize: 20,
  qualification: 'EQ',
  sortType: 'ASC',
  totalPage: 10,
  totalRecords: 214,
  'list|20': [{
    'id|+1': 1,
    userName: 'haha',
    createTime: '1533657600000',
    userId: 'afefefewfe34rfdsgfdg',
    openid: '2343254grgdfsggs',
    status: '第方',
    type: '暂无',
  }]
}

export default {
  code: 0,
  msg: 'success',
  data
}
