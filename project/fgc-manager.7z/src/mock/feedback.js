const data = {
  curPage: 1,
  hasNext: true,
  hasPrevious: false,
  nextPage: 2,
  pageSize: 20,
  qualification: 'EQ',
  sortType: 'ASC',
  totalPage: 10,
  totalRecords: 204,
  'list|20': [{
    'id|+1': 1,
    name: 'haha',
    createTime: '2018-09-21',
    content: '暂sdfasdf对方闪光点是的发个梵蒂冈地方上官方算大概小丑模式那个地方了那个sdafndskjfn成都市，v你的发' +
    '送方的美女岁的法国美丽的吗v巅峰时刻但是非官方的当时法国的风格的附属国豆腐干发生的规范第三方公司的过的是法国你我展现你飞度无',
  }]
}

export default {
  code: 0,
  msg: 'success',
  data
}
