import Koa from 'koa'
import serve from 'koa-static'
import serverRouter from './server/routes'
import log4js from 'log4js'

const port = 3000
const maxAge = 1000 * 60 *60 * 24 * 30 // ms,30天

const app = new Koa()

// replace this with the log4js connect-logger
// app.use(log4js.connectLogger(log4js.getLogger("http"), { level: 'auto' }));

app.use(serverRouter)

app.use(serve('./public/', {
  maxAge: maxAge
}))


app.listen(port, () => {
  console.log(`server listening at http://localhost:${port}`)
})