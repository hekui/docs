import log4js from 'log4js'

const isProd = process.env.NODE_ENV === 'production'
log4js.configure({
  appenders: {
    dateFile: {
      type: 'dateFile',
      filename: __dirname + '/../logs/log',
      pattern: '.yyyy-MM-dd',
      // compress: true
    },
    out: {
      type: 'stdout'
    }
  },
  categories: {
    default: {
      appenders: ['out'],
      level: isProd ? 'error' : 'trace'
    }
  }
})
// const logger = log4js.getLogger('thing');

// logger.trace('Entering cheese testing');
// logger.debug('Got cheese.');
// logger.info('Cheese is Gouda.');
// logger.warn('Cheese is quite smelly.');
// logger.error('Cheese is too ripe!');
// logger.fatal('Cheese was breeding ground for listeria.');


export default function(tag){
  return log4js.getLogger(tag);
}