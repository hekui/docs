
// redisHost=192.168.70.4
// redisPort=6379
// redisDB=6
// appId=wxcf011c09f1aa9a56
// appSecret=54bcc092f05fdf4df7cf1773e4cbffff
// mchId=1509086221
// secret=cxc2018
// partnerKey=cxc2018cxc2018cxc2018cxc2018cxc8
// webUrl=https://wxsso.maifangma.com/cxc/

const redisConfig = {
    host: process.env.redisHost || "192.168.10.239",
    port: process.env.redisPort || 6379,
    db: process.env.redisDB || 6,
    ttl: 600,
  },
  wxConfig = { // 买房吗
    appId: process.env.appId || 'wxcf011c09f1aa9a56',
    appSecret: process.env.appSecret || '54bcc092f05fdf4df7cf1773e4cbffff',
    partnerKey: process.env.partnerKey || 'cxc2018cxc2018cxc2018cxc2018cxc8',
    mchId: process.env.mchId || '1509086221', //商户号
    // pfx: fs.readFile(__dirname + '/keys/apiclient-cert.p12'), //支付证书
    // token: process.env.token || 'cjlive666', //接口服务器 Token
  },
  secret = process.env.secret || 'cxc2018',
  webUrl = process.env.webUrl || 'https://zt.maifangma.com/wxsso',
  accessTokenTTL = 600;

module.exports = {
  redisConfig,
  wxConfig,
  secret,
  webUrl,
  accessTokenTTL,
}