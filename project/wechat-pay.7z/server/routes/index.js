import Router from 'koa-router'
import payment from './../lib/payment'
import base from './../lib/base'

const router = new Router()

router.get('/sign', (ctx, next) => {
  payment.getTicket().then(res => {
    ctx.body = {
      code: 0,
      url: res.url
    }
  })
  next()
})

router.get('/getuser', async (ctx, next) => {
  let ticket = await base.getTicket()
  ctx.body = {
    ticket
  }
  next()
})

export default router.routes()