import axios from 'axios/dist/axios.min.js'
function initShare(){
  var ssid = window.localStorage.CJSSID || "",
  shareData = {
    title: '5.15新政购房资格查询神器',
    desc: '5月25日官方解读补充！',
    link: 'https://focus.maifangma.com/zgcx/',
    imgUrl: 'https://focus.maifangma.com/assets/images/shareface_zgcx.jpg'
  }
  console.log('init share')
  axios({
    method: 'get',
    // url: "http://localhost:3000/sign",
    url: "https://zt.maifangma.com/wxsso/sign",
    data: {
      ssid: ssid
    },
  }).then(result => {
    var res = result.data
    if (res.code == 200) {
      if (res.ssid) {
        window.localStorage.CJSSID = res.ssid
      }
      console.log('res sign')
      var sign = res.sign
      sign.jsApiList = [
        'onMenuShareTimeline',
        'onMenuShareAppMessage',
        'onMenuShareQQ',
        'onMenuShareWeibo',
        'onMenuShareQZone'
      ]

      wx.config(sign)
      wx.ready(function() {
        wx.onMenuShareTimeline(shareData); // 分享给朋友
        wx.onMenuShareAppMessage(shareData); // 分享到朋友圈
        wx.onMenuShareQQ(shareData); // 分享到QQ
        wx.onMenuShareWeibo(shareData); // 分享到腾讯微博
        wx.onMenuShareQZone(shareData); // 分享到QQ空间
      })
      wx.error(function(res) {
        console.log(res.errMsg);
      });
    }
  })
}
function hasEmoji(str = ''){
  return new RegExp(/\ud83d[\udc00-\ude4f\ude80-\udfff]/g).test(str)
}

export default {
  initShare,
  hasEmoji,
}