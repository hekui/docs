# 买房吗
PC新版-前端技术方案及文档

## 概要

1. 前端技术框架：使用`vue`全家桶（`vue`,`vuex`,`vue-router`,`axios`等），ui层自主实现。 
2. 前端工程化打包：使用`webpack 3.0`进行模块引入及打包发布，并实现异步加载模块。
3. 前端静态资源部署：部分内容（主要是产品图片）采用CDN缓存。
4. 服务端：`node + express`做服务支撑，主要实现SSR（Server Side Render,服务端渲染），以及与各端api中转，解决跨域。
5. 数据：前后端数据分离，各端口提供数据api。

  [更多详情及架构图>>](./project.md)

## API端口

与PC端有关的API端口：java端、用户登录端、线索收集端等，具体请查看代码中`/server/api/config.js`文件。  
[JAVA端API](http://apimanager.chuangjia.me/web.do#/webInterface/list/81ba09b0-2d42-43fd-b33b-ae89ad297c0f/%E9%A6%96%E9%A1%B5)


## 文档

1. [服务端渲染数据流转](./ssr_data.md)
2. [性能提升](./optimize.md)  
3. [首页点击事件统计打桩](./avatar_baidu.md)  
4. [一些兼容问题](./hack.md)

## 短信验证码防刷策略（思考）

用户刷验证码，分为两种情况：
一是同一用户，不停刷验证码；  
二是以恶意刷取目标网站短信费为目的。不良份子，绕过前端界面，通过直接调接口（每次提交不一样的手机号码，IP不停变换，伪装成普通用户），刷出大量短信。  

**情况一**  
1、直接使用倒计时发送验证码方式。  
**情况二**  
1、前端增加图形验证码。
2、程序自动做一次加密校验。比如：后端传递一个参数（类似token，通过一些加密手段加密）到前端，前端进行回传。（这个方案不是很靠谱，因为该方案利用的是自动参数，攻击方不一定理解那个参数的含义，但攻击者稍微花点心思，就能理解其中参数的含义。）

## 缓存策略

1. 使用`webpack`对静态资源使用hash指纹进行版本管理，在每次发布时，根据模块内容是否更新来跟新hash值，确保资源有更新时，生成的静态文件是新的hash指纹。  
2. html页面使用对比缓存，当服务端无更新时，返回304；有更新时，返回新内容。  
3. 静态资源（js,img,css等）使用强缓存:`Cache-Control:public, max-age=31536000`，有效期：1年。  

效果如下：  
![](./images/cache.png)

## 日志策略

node端日志，采用 `log4js` 实现，应运维要求，采用标准控制台输出，运维进行日志收集存放，（亦存放于项目根目录 `/logs/log.2018-01-02` 中，按天记录）。  
1. 所有前端http请求均有日志记录。  

```javascript
[2018-01-18T10:25:30.247] [INFO] http - ::1 - - "GET /xinfang HTTP/1.1" 200 - "" "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36"
```

2. 服务端对API端口的调用，有请求追踪：发起及响应，以及消耗时间，但仅在响应失败时将返回数据写入日志。  

```javascript
[2018-01-17T15:47:59.845] [TRACE] java - <<< fetch request - url: http://mfmweb.test1.maifangma.com/houses/listalbum - body: encryMode=2&version=1.0.0&cityId=51010000&deviceNo=WEqB0q7f63rtEkwAqC15EJBMpX-b-nlx&deviceType=2&data=eyJDSVRZX0lEIjoiNTEwMTAwMDAiLCJob3VzZUlkIjoiOTMxNDE4MDU2NDUyNzM0OTc2In0%3D
[2018-01-17T15:48:00.133] [TRACE] java - >>> fetch response - url: http://mfmweb.test1.maifangma.com/houses/listalbum [cost: 288ms] - 200
```

[log4js 介绍](https://github.com/log4js-node/log4js-node)

## 性能

采用 `microcache` 提升高并发能力，因为我们应用没有用户特定内容，每个页面均是一个微缓存。  
性能测试，采用 `loadtest` 进行并发压力测试。  
[详细介绍](./optimize.md#%E5%8E%8B%E5%8A%9B%E6%B5%8B%E8%AF%95)