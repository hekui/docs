# 一些兼容问题

1. `IE 11` 不支持 `Array.from`, `Object.assign`,  `Array.prototype.includes` 等  
解决方法：增加 `babel-polyfill`。详见：[http://babeljs.io/docs/usage/polyfill/](http://babeljs.io/docs/usage/polyfill/)

2. `IE9及以下` 不支持 `history.replaceState`、`history.pushState`  
解决方法：`history.js`，可支持IE8、9。详见：[https://github.com/devote/HTML5-History-API](https://github.com/devote/HTML5-History-API)