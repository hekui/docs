
## 数据请求

服务端->服务端（服务端渲染时），前端（浏览器端）->服务端，均使用axios，超时时间默认为：10000ms。  
服务端->API端口，使用node-fetch，超时时间默认为：3000ms。

## 打包性能优化
[webpack-visualizer-plugin](https://github.com/chrisbateman/webpack-visualizer)  
使用 `webpack-visualizer-plugin` 来进行打包性能分析，该插件可以生成非常直观的图形，来展示每个模块实际大小以及占比多少。  

![](./images/optimize-stat.png)

## moment.js  
`moment.js` 比较坑，默认引入全部语言包。
![](./images/moment.png)  

使用webpack plugin做性能调优，在 `plugins` 中加入：  
```javascript
  new webpack.ContextReplacementPlugin(
    /moment[\\\/]locale$/,
    /^\.\/(zh-cn)$/
  ),
```
使用该步骤后，可使 `bundle` 文件减小 **93KB** ！！！  

## 压力测试
采用 `microcache` 提升高并发能力，因为我们应用没有用户特定内容，每个页面均是一个微缓存。  
采用 `loadtest` 进行并发压力测试。  
[loadtest](https://github.com/alexfernandez/loadtest)  
```javascript
// -c  并发  
// --rps  每秒请求数(request per second)
// -t 时间ms
loadtest -c 10 --rps 50 -t 60 http://localhost:3002
```
结果如下：  
![](./images/loadtest-50.png)

```javascript
loadtest -c 10 --rps 100 -t 600 http://localhost:3002 // 每秒100，持续10分钟
```
结果如下：  
![](./images/loadtest-100.png)