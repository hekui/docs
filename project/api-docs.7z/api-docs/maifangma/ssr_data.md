# 服务端渲染数据流转

**背景介绍**
1. 由于需要SEO，node 服务端做了 `ssr` (服务端渲染)，这就存在服务端发送请求获取数据。
2. 由于我们网站是有城市区分的，需要根据域名来区分数据展示，并且在JAVA端的api中有字段cityId来指明城市。[详见公共参数说明](http://apimanager.chuangjia.me/web.do#/webInterfaceDetail/8c69a99f-9471-47c8-b71c-0da614ac0589/%E9%80%9A%E7%94%A8(common)/43f9eb15-3b2a-4e60-b345-5140e876235f)

由于在服务端渲染，需要在服务端获取数据，并且我们为了提升性能，使用了`runInNewContext: false`, 这就存在一个问题，在服务端获取数据呈现的网络请求形式是：`localhost`，这是无法根据域名来区分城市的。所以

**解决方案**  

是用cookie来区分，在每个请求中带上`cookie`来实现。  
城市转向流程：在服务端拿到入口页面请求的时候，根据域名来做区分，如果是`www.maifangma.com` 或者 `localhost`， 则根据`cookie`中是否有`CITY`字段来区分，如果没有，则根据百度接口来自动定位是哪个城市，并在已经开通的城市中匹配，转向到对应城市域名（比如:`cd.maifangma.com`）。  
在服务端拿到请求后，根据域名中城市`code`，确认出城市，然后将该城市数据写入`req.cookie`，并在后续调用 `asyncData()` 的时候传入该值，然后一层一层传给最终请求发起者`axios`，示例：
```javascript
// server.js
app.use(async function (req, res, next) {
  let city = await cityInfo(req, res, {
      hostname: req.body.hostname || req.hostname,
      ip: req.body.ip || req.ip
  });
  req.cookies.CITY = city.curCity.code
  // ...
  next()
});
// ...
const context = {
  // ...
  cookies: req.cookies,
  // ...
}

// entry-server.js
asyncData({
  store,
  route: router.currentRoute,
  cookies: context.cookies,
})

// index.vue 组件中
  asyncData ({ store, route, cookies}) {
    return Promise.all([
      store.dispatch('HOME_FILTERS_FETCH', { // 快速选房
        disNum: 4,
        cookies,
      }),
      // ...
    ])
  },

// home.js store中
import api from './../api'
  [HOME_FILTERS_FETCH]({commit}, params){
    let cookies
    if (params.cookies) {
        cookies = params.cookies
        delete params.cookies
    }
    return api.post('/home/wfilter', params, cookies).then(res => {
      commit('HOME_SET', {
        target: 'filterList',
        data: res.data.list
      })
    })
  },

// api中
import axios from 'axios'
var { localhost } = require('../../config/sys.config')
const apiContext = '/api'
let methods = ['get', 'post']

const parseCookie = cookies => {
  let cookie = ''
  Object.keys(cookies).forEach(item => {
      cookie += item + '=' + cookies[item] + '; '
  })
  return cookie
}

class Api {
  constructor (context) {
    methods.forEach(method => {
      this[method] = (path, data = {}, cookies = {}) => new Promise((resolve, reject) => {
        const cookie = parseCookie(cookies)
        let url = localhost + apiContext + context + path
        axios({
          method: method,
          url: url,
          data: data,
          timeout: 4800,
          headers: {
            'Content-Type': 'application/json',
            cookie  // <-- 这里
          },
        }).then(res => {
          // ...
        }).catch(error => {
          // ...
        })
      })
    })
  }
}
```