# PC官网自定义事件统计
买房吗PC首页，按模块统计用户的点击行为，使用百度统计的自定义事件统计功能实现。  
百度trackEvent说明：[http://tongji.baidu.com/web/help/article?id=236&type=0](http://tongji.baidu.com/web/help/article?id=236&type=0)

## 事件参数：  

```javascript
_hmt.push(['_trackEvent', category, action, opt_label, opt_value]);
```

 - category：要监控的目标的类型名称，通常是同一组目标的名字，比如"视频"、"音乐"、"软件"、"游戏"等等。该项必填，不填、填"-"的事件会被抛弃。
 - action：用户跟目标交互的行为，如"播放"、"暂停"、"下载"等等。该项必填，不填、填"-"的事件会被抛弃。
 - opt_label：事件的一些额外信息，通常可以是歌曲的名称、软件的名称、链接的名称等等。该项选填，不填、填"-"代表此项为空。
 - opt_value：事件的一些数值信息，比如权重、时长、价格等等，在报表中可以看到其平均值等数据。该项可选。


## 官网定义：

语法：  

name|value
---|---
category|  [city]-PC-[page]-[num]  
action|    [action]  
opt_label| [cityName]-[pageName]-[moduleName]-[target]  
opt_value:| (无)


值枚举：  

name|value
---|---
city|       cd(成都),cq(重庆)  
page|       SY(首页)  
num|        (数字值，由PRD需求定义)
action|     click(点击)  
moduleName| 导航,快速选房,...（跟页面模块挂钩，具体请查看下面文档）  
target|     (事件具体触发目标元素。)（跟页面元素挂钩，具体请查看下面文档）  


## 官网实现：

1. 首页-导航部分  
```javascript
_hmt.push(['_trackEvent', '[city]-PC-SY-1', 'click', '[cityName]-首页-导航-首页']); // 成都-首页-导航-首页
_hmt.push(['_trackEvent', '[city]-PC-SY-2', 'click', '[cityName]-首页-导航-全部好房']); // 全部好房
_hmt.push(['_trackEvent', '[city]-PC-SY-3', 'click', '[cityName]-首页-导航-资讯']); // 资讯
_hmt.push(['_trackEvent', '[city]-PC-SY-4', 'click', '[cityName]-首页-导航-工具']); // 工具
_hmt.push(['_trackEvent', '[city]-PC-SY-5', 'click', '[cityName]-首页-导航-登录或注册']); // 登录或注册
````

2. 首页-快速选房  
```javascript
_hmt.push(['_trackEvent', '[city]-PC-SY-6', 'click', '[cityName]-首页-快速选房-搜索']); // 首页
_hmt.push(['_trackEvent', '[city]-PC-SY-7', 'click', '[cityName]-首页-快速选房-地图找房']); // 地图找房
_hmt.push(['_trackEvent', '[city]-PC-SY-8', 'click', '[cityName]-首页-快速选房-立即选房']); // 立即选房
````

3. 首页-干货速递  
```javascript
_hmt.push(['_trackEvent', '[city]-PC-SY-9', 'click', '[cityName]-首页-干货速递']); // 干货速递
````

4. 首页-专题
```javascript
_hmt.push(['_trackEvent', '[city]-PC-SY-ZT-[suffix]-MORE', 'click', '[cityName]-首页-专题-[topicTitle]-更多']); // 例子：成都-首页-专题-铺子熟了-更多（右上角的“更多”链接）
_hmt.push(['_trackEvent', '[city]-PC-SY-ZT-[suffix]-ITEM', 'click', '[cityName]-首页-专题-[topicTitle]-链接']); // 例子：成都-首页-专题-铺子熟了-链接（具体的每个链接项）
````

5. 首页-资讯
```javascript
_hmt.push(['_trackEvent', '[city]-PC-SY-10', 'click', '[cityName]-首页-资讯-楼盘导购']); // 楼盘导购
_hmt.push(['_trackEvent', '[city]-PC-SY-11', 'click', '[cityName]-首页-资讯-买房头条']); // 买房头条
_hmt.push(['_trackEvent', '[city]-PC-SY-12', 'click', '[cityName]-首页-资讯-查看更多']); // 查看更多
````