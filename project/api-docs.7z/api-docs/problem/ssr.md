# ssr

`ssr` 纯渲染简单静态页面

loadtest -c 10 --rps 100 -t 300
`process.memoryUsage.rss` 维持在 80M 下