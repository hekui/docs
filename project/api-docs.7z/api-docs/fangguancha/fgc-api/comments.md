# 文章评论

- [1. 根据文章ID获取评论列表](#1-根据文章id获取评论列表)
- [2. 根据评论ID获取评论详情](#2-根据评论id获取评论详情)
- [3. 添加评论](#3-添加评论)
- [4. 增加评论点赞数](#4-增加评论点赞数)
- [5. 取消评论点赞数](#5-取消评论点赞数)

### 1. 根据文章ID获取评论列表  
  url: `/comments/list`  
  method: `POST`  
  request：
  ```javascript
  {
    "page":3,
    "pageSize":1,
    "articleId":201709221924421 // 文章id
  }
  ```

  response：  
  ```javascript
  data: [
    {
      "id":15089217882463,
      "content":"测试评论内容",
      "u_id":1,
      "username":"test",
      "comment_at":"2017-10-25 16:56:28",
      "like": 10, //点赞数
      "like_status": null, // 点赞状态，1已点赞，0/null 未点赞
      "revert_id":null, // 回复id
      "revert_content":null, // 回复内容
      "revert_at":null, // 回复时间
      "creater":null, // 回复人id
      "creater_user":null, // 回复人
      "revert_isread":null // 回复内容是否已读
    }
  ]
  ```
### 2. 根据评论ID获取评论详情  
  url: `/comments/details`  
  method: `POST`  
  request：
  ```javascript
  {
    "commentId":15089219829401 // 评论id
  }
  ```

  response：  
  ```javascript
    data: {
      "id":15089219829401,
      "content":"成都人居置业底价拿下一号宗地，成交单价583万元/亩，计算成交楼面价3498元/平米，获得青白江首宗人才公寓用地。而佳兆业拍下二号宗地，经过49轮厮杀，终落锤成交，成交单价定格在890万元/亩，计算楼面价4450元/平米，溢价率36.9%。",
      "u_id":1,
      "username":"test",
      "comment_at":"2017-10-25 16:59:42",
      "revert_id":1,
      "revert_content":"这条是有效的，谢谢你对房观察的关注。",
      "revert_at":"2017-10-25 17:58:36",
      "creater":1000,
      "creater_user":"房观察",
      "revert_isread":1
    }
  ```
### 3. 添加评论  
  url: `/comments/add`  
  method: `POST`  
  request：
  ```javascript
  {
    "articleId": 1, // 文章id
    "content": "评论内容",
    "u_id": 1, // 用户id
    "u_name": "hekui" // 用户名称
  }
  ```

  response：  
  ```javascript
  // 返回当前评论的具体内容
  data: {
    "comment_at":"2017-10-26T08:07:01.000Z",
    "created_at":"2017-10-26T08:07:01.000Z",
    "id":15090052215493,
    "a_id":201709221924421,
    "content":"成都人居置业底价拿下一号宗地，成交单价583万元/亩，计算成交楼面价3498元/平米，获得青白江首宗人才公寓用地。而佳兆业拍下二号宗地，经过49轮厮杀，终落锤成交，成交单价定格在890万元/亩，计算楼面价4450元/平米，溢价率36.9%。",
    "u_id":1,
    "username":"test",
    "status":0
  }
  ```
### 4. 增加评论点赞数
  url: `/comments/incrementLike`  
  method: `POST`  
  request：
  ```javascript
  {
    "commentId":15089219829401 // 评论id
  }
  ```

  response：  
  ```javascript
  // 返回点赞后的数据
  data: {
    "like": 4
  }
  ```

### 5. 取消评论点赞数
  url: `/comments/decrementLike`  
  method: `POST`  
  request：
  ```javascript
  {
    "commentId":15089219829401 // 评论id
  }
  ```

  response：  
  ```javascript
  // 返回取消点赞后的数据
  data: {
    "like": 4
  }
  ```