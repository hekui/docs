# 用户中心 - 消息

- [1. 消息未读条数](#1-消息未读条数) 
- [2. 消息列表](#2-消息列表)

### 1. 消息未读条数
  url: `/messages/unreadCount`  
  method: `POST`  
  request：
  ```javascript
  {
    "u_id": 1, // 用户id
  }
  ```

  response：  
  ```javascript
  data: {
    total: 0 // 未读条数
  }
  ```
### 2. 消息列表
  url: `/messages/list`  
  method: `POST`  
  request：
  ```javascript
  {
    "page":3,
    "pageSize":1,
    "u_id": 1, // 用户id
  }
  ```

  response：  
  ```javascript
  data: {
    "total":1,
    "hasPrev":false,
    "hasNext":false,
    "list":[
      {
        "id":15089219829401,
        "a_id": 15089219829401,
        "content":"成都人居置业底价拿下一号宗地，成交单价583万元/亩，计算成交楼面价3498元/平米，获得青白江首宗人才公寓用地。而佳兆业拍下二号宗地，经过49轮厮杀，终落锤成交，成交单价定格在890万元/亩，计算楼面价4450元/平米，溢价率36.9%。",
        "u_id":1,
        "username":"test",
        "comment_at":"2017-10-25 16:59:42",
        "revert_id":1,
        "revert_content":"这条是有效的，谢谢你对房观察的关注。",
        "revert_at":"2017-10-25 17:58:36",
        "creater":1000,
        "creater_user":"房观察",
        "revert_isread":1
      }
    ]
}
  ```