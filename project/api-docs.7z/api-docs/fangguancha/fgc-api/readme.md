# fgc-api 文档


本地环境：`http://127.0.0.1:3005`   
测试环境：`http://api.test1.fangguancha.com`

## 接口列表

1. [文章评论接口](./comments.md)
2. [用户中心-消息](./messages.md)
3. [广告](./advert.md)

## 通用字段

通用请求字段：  
```javascript
{
  page: 1, //页码
  pageSize: 10// 每页条数
}
```

通用返回：
```javascript
{
  "code": 200, // 返回状态码：200成功
  "data": {}|[] // 返回数据：object 或者 array； 具体接口中 response 的内容即为 data 的内容。
}
```

通用分页返回： 
```javascript
{
  "code": 200,
  "data": {
    "total": 100, // 总数
    "hasPrev": true, // 有上一页
    "hasNext": false, //有下一页
    "list": [ // 数据列表
      {}
    ]
  }
}
```

