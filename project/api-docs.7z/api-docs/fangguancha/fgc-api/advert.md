# 广告

- [1. 图片广告](#1-图片广告) 
- [2. 文章详情大小广告](#2-文章详情大小广告)

### 1. 图片广告
  url: `/advert/image`  
  method: `POST`  
  request：
  ```javascript
  {
    positionCode: 500002004 // 广告位置代码
  }
  ```

  response：  
  ```javascript
  data: [
    {
      "id":201710111429316,
      "title":"文章下广告小",
      "activity_img":"/2017/10/11/50319e338336ea10751d09da740852c1.jpg", // 图片地址
      "relation_url":"https://m.fangguancha.com/download", // 链接地址
      "start_time":"2017-09-11 00:00:00", // 开始时间
      "end_time":"2018-10-18 00:00:00", // 结束时间
      "status":1, // 状态:0下架,1上架
      "created_at":"2017-10-11 14:29:31",
      "updated_at":"2017-10-11 14:29:53"
    }
  ]
  ```


### 2. 文章详情大小广告
  业务逻辑写在api中。  
  url: `/advert/articleBottomImage`  
  method: `POST`  
  request：
  ```javascript
  {
    // 业务逻辑写在api中，不传任何参数
  }
  ```

  response：  
  ```javascript
  data: {
    "id":201710111429316,
    "title":"文章下广告小",
    "activity_img":"/2017/10/11/50319e338336ea10751d09da740852c1.jpg",
    "relation_url":"https://m.fangguancha.com/download",
    "start_time":"2017-09-11 00:00:00",
    "end_time":"2018-10-18 00:00:00",
    "status":1,
    "created_at":"2017-10-11 14:29:31",
    "updated_at":"2017-10-11 14:29:53"
  }
  ```

