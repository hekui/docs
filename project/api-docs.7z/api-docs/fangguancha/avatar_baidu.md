# M站官网自定义事件统计
房观察M站事件打桩，按模块统计用户的点击行为，使用百度统计的自定义事件统计功能实现。  
百度trackEvent说明：[http://tongji.baidu.com/web/help/article?id=236&type=0](http://tongji.baidu.com/web/help/article?id=236&type=0)

## 事件参数：  

```javascript
_hmt.push(['_trackEvent', category, action, opt_label, opt_value]);
```

 - category：要监控的目标的类型名称，通常是同一组目标的名字，比如"视频"、"音乐"、"软件"、"游戏"等等。该项必填，不填、填"-"的事件会被抛弃。
 - action：用户跟目标交互的行为，如"播放"、"暂停"、"下载"等等。该项必填，不填、填"-"的事件会被抛弃。
 - opt_label：事件的一些额外信息，通常可以是歌曲的名称、软件的名称、链接的名称等等。该项选填，不填、填"-"代表此项为空。
 - opt_value：事件的一些数值信息，比如权重、时长、价格等等，在报表中可以看到其平均值等数据。该项可选。


## 官网定义：

语法：  

name|value
---|---
category|  FGCM-[page]-[num]  
action|    [action]  
opt_label| [pageName]-[moduleName]-[target]  
opt_value:| (无)


值枚举：  

name|value
---|---
FGCM|       固定前缀，表示房观察M站
page|       ArticleDetail(文章详情页),ReportDetail(报告详情页),SideBar(侧边浮动条)  
num|        (位置数字值，具体请查看下面文档)
action|     click(点击)  
moduleName| 推荐文章,文章分享,...（跟页面模块挂钩，具体请查看下面文档）  
target|     (事件具体触发目标元素。)（跟页面元素挂钩，具体请查看下面文档）  


## 实现：

1.  文章详情页

```javascript
_hmt.push(['_trackEvent', 'FGCM-ArticleDetail-1', 'click', '文章详情页-文章详情-收藏']); // 文章详情页-文章详情的收藏
_hmt.push(['_trackEvent', 'FGCM-ArticleDetail-10', 'click', '文章详情页-推荐文章-链接']); // 文章详情页-推荐文章模块的链接

// 预留
// _hmt.push(['_trackEvent', 'FGCM-ArticleDetail-20', 'click', '文章详情页-评论-写留言']); // 文章详情页-评论模块的写留言  

_hmt.push(['_trackEvent', 'FGCM-ArticleDetail-90', 'click', '文章详情页-顶部-分享']); // 文章详情页-顶部的分享
```

2. 报告详情页

```javascript
_hmt.push(['_trackEvent', 'FGCM-ReportDetail-1', 'click', '报告详情页-报告详情-购买报告']); // 收费报告的购买
_hmt.push(['_trackEvent', 'FGCM-ReportDetail-2', 'click', '报告详情页-报告详情-获取报告']); // 收费报告的获取报告PDF
_hmt.push(['_trackEvent', 'FGCM-ReportDetail-3', 'click', '报告详情页-报告详情-查看更多']); // 查看更多
_hmt.push(['_trackEvent', 'FGCM-ReportDetail-10', 'click', '报告详情页-相关阅读-链接']); // 相关阅读模块的链接
_hmt.push(['_trackEvent', 'FGCM-ReportDetail-90', 'click', '报告详情页-顶部-分享']); // 报告详情页-顶部的分享
```

3. 侧边浮动条 

```javascript
_hmt.push(['_trackEvent', 'FGCM-SideBar-1', 'click', '侧边浮动条-返回顶部']); // 返回顶部
_hmt.push(['_trackEvent', 'FGCM-SideBar-2', 'click', '侧边浮动条-刷新当前页面']); // 刷新当前页面
_hmt.push(['_trackEvent', 'FGCM-SideBar-3', 'click', '侧边浮动条-回到首页']); // 回到首页
```