# 美食小程序
包含美食小程序：服务端、小程序源码。  
服务端源码：`/server/`  
小程序源码：`/client/`  

## 服务启动
```javascript
npm run dev // 开发模式
npm run start // 生产模式
```


## 服务端code清单
```javascript
0   // 成功，非0即失败

10  // 传入数据不正确

40  // 微信数据解密错误，sessionKey is undefined
41  // 微信数据解密错误，appid/sessionKey is invalid
42  // 用户未登录
44  // 数据未找到

50  // 请求java接口异常，msg有错误描述，服务端日志可查看详细错误。
55  // 数据库操作异常
```