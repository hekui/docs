const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

const setCookies = (res) => {
  console.log('res.header["Set-Cookie"]', res.header["Set-Cookie"])
  if (res.header["Set-Cookie"]) {
    // let oldCookies = wx.getStorageSync("cookie")
    // let newCookies = Object.assign({}, oldCookies, formatCookiesToObject(formatCookies(res.header["Set-Cookie"])))
    // wx.setStorageSync("cookie", formatCookiesToString(newCookies))
    wx.setStorageSync("cookie", formatCookies(res.header["Set-Cookie"]))
  }
}

const getCookies = () => {
  return wx.getStorageSync("cookie")
}

const formatCookies = (str) => {
  let result = ''
  str.split('httponly,').forEach(item => {
    result += item.split(';')[0] + ';'
  })
  return result
}

const formatCookiesToObject = (data) => {
  let result = {}
  if (data) {
    data.split(';').forEach(item => {
      let itemArray = item.split('=')
      if (itemArray[0]) {
        result[itemArray[0]] = itemArray[1]
      }
    })
  }
  console.log('formatCookiesToObject result:', result)
  return result
}

const formatCookiesToString = (data) => {
  let result = ''
  for (let key in data) {
    // result += key + '=' + data[key] + ';'
    result += `${key}=${data[key]};`
  }
  return result
}


const login = (options = {}) => {
  if(options.app){
    if (options.app.globalData.userInfo && options.app.globalData.userInfo.userId){
      options.success && options.success()
      return 
    }
  }

}


module.exports = {
  formatTime,
  setCookies,
  getCookies,
}
