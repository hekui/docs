const utils = require('./util')
// let hostname = 'http://localhost:8888'
let hostname = 'http://192.168.10.192:8888'
// let hostname = 'https://mp.fangguancha.com'

/**
 * 封装wx.request，增加cookie处理
 * 参数同wx.request一致。但是method默认值修改为POST。
 * success返回接口对应数据。
 * @param {*} * 
 */
const request = ({
  url,
  data,
  header,
  method = 'POST',
  dataType,
  responseType,
  success = () => { },
  fail = () => { },
  complete = () => { },
  app,
}) => {
  const city = wx.getStorageSync('CITY')
  const cityId = city ? city.id : '51010000' // 51010000 成都id
  //发起网络请求
  return wx.request({
    url: hostname + '/api' + url,
    data,
    header: Object.assign({}, header, {
      'ticketid': wx.getStorageSync('ticketId'),
      'cityid': cityId,
      'cookie': utils.getCookies() //读取cookie
    }),
    method,
    dataType,
    responseType,
    success: function (res) {
      utils.setCookies(res) // 设置cookie
      // 对返回结果处理
      if (res.statusCode === 200 && res.data && res.data.code === 0) {
        success(res.data)
      } else {
        if (res.data && res.data.code === 1014) {
          wx.removeStorageSync('ticketId')
          if (app) app.globalData.userInfo = null
        }
        fail(res.data)
      }
    },
    fail,
    complete,
  })
}

/**
 * 网络检查，网络恢复加载数据。
 * @param {*} options 
 */
const preRequest = (options) => {
  wx.getNetworkType({
    success: function (res) {
      // 返回网络类型, 有效值：
      // wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
      var networkType = res.networkType
      if (networkType === 'none') {
        wx.showToast({
          icon: 'none',
          title: '网络不好，请稍后重试'
        })
        wx.onNetworkStatusChange(function (res) {
          if (res.isConnected) {
            return request(options)
          }
        })
      } else {
        return request(options)
      }
    }
  })
}

/**
 * 获取用户信息接口
 * @param {Object} data 通过wx.getUserInfo拿到的数据。 
 * @return {Promise}
*/
const getUserInfo = (data) => {
  return new Promise((resolve, reject) => {
    request({
      url: '/account/getUserInfo',
      method: 'POST',
      data: data,
      success: function (res) {
        if (res.code === 0) {
          // 如果是登录返回则有ticketId,如果是获取用户信息是没有ticketId
          if (res.data.ticketId) {
            wx.setStorageSync('ticketId', res.data.ticketId)
          }
          resolve(res)
        } else {
          reject(res)
        }
      },
      fail: res => {
        reject(res)
      }
    })
  })
}

module.exports = {
  request: preRequest,
  getUserInfo,
}