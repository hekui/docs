//app.js
const api = require('./utils/api.js')
App({
  onLaunch: function () {
    let app = this
    // 展示本地存储能力
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)
  },
  userInfoReadyCallback: function(){

  },
  getUserInfo: function (userSourceData, options){
    // getUserInfo
    api.getUserInfo(userSourceData).then(res => {
      console.log('success res in getUserInfo', res, options)
      options.success && options.success(res.data)
    }, res => {
      // console.log('fail res in getUserInfo', res)
      wx.showToast({
        title: '登录失败', icon: 'none'
      })
    })
  },
  login: function(options){
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 sessionKey
        console.log('wx.login res:', res);
        api.request({
          app: this,
          url: '/wechat/getSessionKey',
          data: {
            code: res.code
          },
          success: res => {
            // console.log('sessionKey 获取成功！res.data', res.data)
            // getUserInfo    
            wx.getUserInfo({
              success: (userSourceData) => {
                console.log('wx.getUserInfo res', userSourceData)
                this.getUserInfo(userSourceData, options)
              },
              fail: (userSourceData) => {
                console.log('wx.getUserInfo fail:', userSourceData)
                options.fail && options.fail(userSourceData)
              }
            })
          }
        })
      }
    })
  },
  globalData: {
    userInfo: null
  }
})