// pages/detail/detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detail: {
      price: '8.80',
      publicPrice: '10.00',
      taste: [{
        name: '麻辣-微辣',
        id: 1
      }, {
        name: '麻辣-中辣',
        id: 2
      }, {
        name: '麻辣-特辣',
        id: 3
      }, {
        name: '麻辣-变态辣',
        id: 4
      }, {
        name: '五香',
        id: 5
      }],
      bannerList: [{ "id": 201804231545281, "title": "重庆生机", "activity_img": "https://m.360buyimg.com/n12/s750x750_jfs/t8128/147/1324925324/452840/471b4ae2/59b77fd5Na0bff956.jpg!q70.jpg", "relation_url": "" },
        { "id": 201804131529501, "title": "房观察西安上线", "activity_img": "https://m.360buyimg.com/n12/s750x750_jfs/t7240/156/2968698405/416527/9c2a884b/59b77fe4N36916fe0.jpg!q70.jpg", "relation_url": "" },
        { "id": 201804131546461, "title": "房观察重庆上线", "activity_img": "https://m.360buyimg.com/n12/jfs/t14554/106/456643038/412500/8f136b18/5a2dfa26Nf7f5d2dc.jpg!q70.jpg", "relation_url": "" }],
      content: [
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/01/24/FgvtEJ0PnAB0wSoRfQ2nkQBpe-54.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/02/28/FgVbCSnGIBuviNnTxllE4UqYeD3E.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/01/24/Fg3hkKy8Ng9GL7zexYu9olwXgAI2.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/01/24/FsubiCiReiNqrFWBDzdd7JRgLZW1.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/01/24/Fv9mUbdNVeMnIkMJyXS0TY6hwx1b.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/01/24/FosVwtYa-RqpvMbqXq-lrijZ0Hrh.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/02/28/FovklyuizeM1LJipTGDKPc6BgqK9.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2017/01/24/FrrDgq1Pr9m7ZtaZ0ajq4lDpL8Su.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2016/07/13/Fmu80WcMY-Hx9zrXKmXmBkX2j-X6.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2016/06/22/Fv1x_OhZwuoWPt4Z5SdesVysPYEy.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2016/08/24/FuvV5gaYDYqGt7FDiSdfdSFzse0u.jpg!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2016/05/04/Fiqj2h-h98Xzfu9-LMBbT3RkvTeS.gif!730x0.jpg"
        },
        {
          "type": "image",
          "url": "https://img.yzcdn.cn/upload_files/2016/08/24/FnDYR_07QrNbI_aCoefF2FLFUTAr.jpg!730x0.jpg"
        },
        {
          "type": "text",
          "content": "文字信息"
        }
      ],
    },
    typeOptions: {
      1: 59,
      2: 69,
      3: 79
    },
    typeNameOptions: {
      1: '小果',
      2: '中果',
      3: '大果'
    },  
    buy: {
      typeValue: 3,
      count: 1,
      taste: '',
      totalPrice: 79
    }
  },

  chooseTaste: function (event){
    this.setData({
      'buy.taste': event.target.dataset.type 
    })
  },
  changeType: function (event){
    this.setData({
      'buy.typeValue': event.target.dataset.type
    })
    this.calcPrice()
  },
  counter: function(event){
    let count = this.data.buy.count
    if(event.target.dataset.type === '+'){
      count += 1
    }else{
      if (count>1){
        count -= 1
      }
    }
    this.setData({
      'buy.count': count
    })
    this.calcPrice()
  },
  calcPrice(){
    this.setData({
      'buy.totalPrice': this.data.buy.count * this.data.typeOptions[this.data.buy.typeValue]
    })
  },

  goUserCenter: function(){
    wx.switchTab({
      url: '/pages/user/user'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})