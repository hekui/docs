// pages/user/user.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },

  getUserInfo: function () {
    // 查看是否授权
    wx.getSetting({
      success: function (res) {
        console.log('getSetting res', res)
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function (res) {
              console.log(res.userInfo)
            }
          })
        }
      }
    })
  },

  onGotUserInfo: function (e) {
    console.log('onGotUserInfo e:', e)
    let userInfo = getApp().globalData.userInfo
    if (userInfo) { // 判断全局是否有数据（因为用户数据获取是异步的，所以可能导致数据不同步），若有，直接赋值。
      this.setData({
        userInfo: userInfo
      })
    } else {
      if (e.detail.userInfo) { // 已授权/同意授权，查询用户信息。
        app.getUserInfo(e.detail, {
          success: userInfo => {
            this.setData({
              userInfo,
            })
          }
        })
      } else {
        wx.showToast({
          title: '授权失败',
          icon: 'none'
        })
      }
    }
  },
  goUrl: function(e){
    console.log(e)
    if(this.data.userInfo){
      wx.navigateTo({
        url: e.currentTarget.dataset.url
      })
    }else{
      wx.showToast({
        title: '请登录后操作', icon: 'none'
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.login({
      success: (userInfo) => {
        this.setData({
          userInfo,
        })
      },
      fail: res => {
        console.log('fail in user at app.login', res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})