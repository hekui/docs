// pages/userAddrEdit/userAddrEdit.js
const api = require('./../../utils/api.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: '',
    region: [],
    form: {
      name: '',
      phone: '',
      address: ''
    }
  },
  inputValue: function(e){
    let name = e.currentTarget.dataset.name
    this.setData({
      ['form.'+ name]: e.detail.value
    })
  },
  
  bindRegionChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value,
      'form.province': e.detail.value[0],
      'form.city': e.detail.value[1],
      'form.country': e.detail.value[2]
    })
  },
  submit: function(){
    let form = this.data.form
    console.log(form)
    if(form.name === ''){
      wx.showToast({
        title: '请填写联系人', icon: 'none'
      })
      return
    }
    if (form.phone === '') {
      wx.showToast({
        title: '请填写手机号', icon: 'none'
      })
      return
    }
    if (this.data.region.length === 0) {
      wx.showToast({
        title: '请选择省市区', icon: 'none'
      })
      return
    }
    if (form.address === '') {
      wx.showToast({
        title: '请填写详细地址', icon: 'none'
      })
      return
    }
    this.postData()
  },

  fetchData: function(){
    api.request({
      app: this,
      url: '/user/addrDetail',
      data: {
        id: this.data.id
      },
      success: res => {
        // console.log('res.data', res.data)
        this.setData({
          form: res.data,
          region: [res.data.province, res.data.city, res.data.country]
        })
      }
    })
  },

  postData: function(){
    api.request({
      app: this,
      url: '/user/addrEdit',
      data: Object.assign({}, this.data.form, {
        id: this.data.id
      }),
      success: res => {
        wx.navigateBack() 
        wx.showToast({
          title: `${this.data.id ? '编辑' : '添加'}成功`,
        })
      },
      fail: res => {
        wx.showToast({
          title: `${res.msg || '添加失败'}`, icon: 'none'
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options.id){
      this.setData({
        id: options.id
      })
      this.fetchData()
      wx.setNavigationBarTitle({
        title: '编辑收货地址'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})