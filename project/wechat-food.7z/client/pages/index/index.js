//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    bannerList: [{ "id": 201804231545281, "title": "重庆生机", "activity_img": "https://img1.fangguancha.com/2018/04/23/68ee3b5f1a9be6e5b5e1b5e71334f741.jpg", "relation_url": "" }, 
      { "id": 201804131529501, "title": "房观察西安上线", "activity_img": "https://img1.fangguancha.com/2018/04/13/3bb6d931540b06818af0f56d36c24468.jpg", "relation_url": "" }, 
    { "id": 201804131546461, "title": "房观察重庆上线", "activity_img": "https://img1.fangguancha.com/2018/04/13/8dd8fdef83dce11b77de9d192c75a79e.jpg", "relation_url": "" }, 
    { "id": 201712071035151, "title": "锦江区12块土地", "activity_img": "https://img1.fangguancha.com/2017/12/07/e6e0a0f5a7f46bc40f397dbf47fc5a7b.jpg", "relation_url": "https://m.fangguancha.com/industryDetails/201711291511411" }, 
    { "id": 201712071037181, "title": "成华区7地", "activity_img": "https://img1.fangguancha.com/2017/12/07/2fb0e3b0831f34a516b43f48634b7042.jpg", "relation_url": "https://m.fangguancha.com/industryDetails/201712061322231" }]
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
