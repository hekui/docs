// pages/userAddr/userAddr.js
const api = require('./../../utils/api.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    addrList: [],
    checked: false
  },

  radioChange: function (e){
    // console.log(e)
    let id = e.detail.value
    this.setDefault(id)
    // 更新默认地址
  },

  delAddr: function(e){
    wx.showModal({
      title: '请确认',
      content: '确认要删除该地址吗？',
      success: res => {
        if(res.confirm){
          api.request({
            app: this,
            url: '/user/addrDel',
            data: {
              id: e.currentTarget.dataset.id
            },
            success: res => {
              wx.showToast({
                title: `删除成功`,
              })
              this.fetchList()
            },
            fail: res => {
              wx.showToast({
                title: `${res.msg || '删除失败'}`,
                icons: 'none'
              })
            }
          })
        }
      }
    })
  },
  
  setDefault: function(id){
    api.request({
      app: this,
      url: '/user/addrSetDefault',
      data: {
        id
      },
      fail: res => {
        wx.showToast({
          title: '设置失败',
          icons: 'none'
        })
        this.fetchList()
      }
    })
  },

  fetchList: function(){
    api.request({
      app: this,
      url: '/user/addrList',
      success: res => {
        this.setData({
          addrList: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.fetchList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.fetchList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})