const Koa = require('koa')
const serve = require('koa-static')
const Router = require('koa-router')
const session = require('koa-session')
const koaBody = require('koa-body');
const log = require('./log')('http')
const serverRouter = require('./router')
const {loginList} = require('./config')

const app = new Koa()
const router = new Router()
const port = 8888
const maxage = 30 * 24 * 60 * 60 * 1000 // 30天

app.keys = ['some secret hurr'];
const sessionOptions = {
  key: 'SSID', /** (string) cookie key (default is koa:sess) */
  /** (number || 'session') maxAge in ms (default is 1 days) */
  /** 'session' will result in a cookie that expires when session/browser is closed */
  /** Warning: If a session cookie is stolen, this cookie will never expire */
  maxAge: maxage,
  overwrite: true, /** (boolean) can overwrite or not (default true) */
  // httpOnly: true, /** (boolean) httpOnly or not (default true) */
  // signed: true, /** (boolean) signed or not (default true) */
  rolling: false, /** (boolean) Force a session identifier cookie to be set on every response. The expiration is reset to the original maxAge, resetting the expiration countdown. (default is false) */
  renew: false, /** (boolean) renew session when session is nearly expired, so we can always keep user logged in. (default is false)*/
};

app.use(session(sessionOptions, app))

app.use(koaBody())

// app.use(log4js.connectLogger(log4js.getLogger("http"), { level: 'auto' }))
// app.use(log4js.koaLogger(log4js.getLogger("http"), { level: 'auto' }))

app.use(async (ctx, next) => {
  
  // console.log(serverRouter)
  const start = new Date()
  log.trace(`>>>request>>> "${ctx.request.method} ${ctx.request.url}" - "${ctx.request.header['user-agent']}" - session: ${JSON.stringify(ctx.session)}`)
  // 登录检查
  let url = ctx.request.url
  if(loginList.includes(url.replace('/api', ''))){
    log.trace('in check login')
    if(!ctx.session.userId){
      return ctx.body = {
        code: 42,
        msg: '您未登录或登录已失效'
      }     
    }
  }
  await next()
  const ms = new Date() - start
  log.trace(`<<<response<<< "${ctx.request.method} ${ctx.request.url}" ${ctx.status} ${ms}ms "${JSON.stringify(ctx.body)}"`)
})

app.use(serve(__dirname+ './../public/', {
  maxage: maxage
}));

router.use('/api', serverRouter)
app.use(router.routes())

app.on('error', (err, ctx) => {
  log.error('server error', err, ctx)
})

process.on('unhandledRejection', (message, stack) => {
  log.error("未捕捉的Promise错误：", message, stack);
  // res.status(500).send('Internal server error.')
});

app.listen(port, ()=>{
  console.log(`server listening on port http://localhost:${port}/`)
})