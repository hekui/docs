const catList = [{
  id: 1,
  catName: '房企新媒体',
  children: [{
    id: 100,
    catName: '房企影响力排行榜',
  }, {
    id: 101,
    catName: '楼盘影响力排行榜',
  }, {
    id: 102,
    catName: '最佳运营排行榜',
  }, {
    id: 103,
    catName: '运营忽视排行榜',
  }]
}, {
  id: 2,
  catName: '房产自媒体',
  children: [{
    id: 200,
    catName: '新媒体风云榜',
  }, {
    id: 201,
    catName: '推荐阅读榜'
  }, {
    id: 202,
    catName: '内容有待提升榜'
  }, {
    id: 203,
    catName: '内容转载榜'
  }]
}, {
  id: 3,
  catName: '房产热词',
  children: [{
    id: 300,
    catName: '楼盘热词排行榜',
  }, {
    id: 301,
    catName: '板块热词排行榜'
  }, {
    id: 302,
    catName: '区域热词排行榜'
  }, {
    id: 303,
    catName: '政策热词排行榜'
  }, {
    id: 304,
    catName: '争议楼盘排行榜'
  }]
}]

const catDict = {
  100: {
    id: 100,
    catName: '房企影响力排行榜',
  },
  101: {
    id: 101,
    catName: '楼盘影响力排行榜',
  },
  102: {
    id: 102,
    catName: '最佳运营排行榜',
  },
  103: {
    id: 103,
    catName: '运营忽视排行榜',
  },
  200: {
    id: 200,
    catName: '新媒体风云榜',
  },
  201: {
    id: 201,
    catName: '推荐阅读榜'
  },
  202: {
    id: 202,
    catName: '内容有待提升榜'
  },
  300: {
    id: 300,
    catName: '楼盘热词排行榜',
  },
  301: {
    id: 301,
    catName: '板块热词排行榜'
  },
  302: {
    id: 302,
    catName: '区域热词排行榜'
  },
  303: {
    id: 303,
    catName: '政策热词排行榜'
  },
  304: {
    id: 304,
    catName: '争议楼盘排行榜'
  }
}

module.exports = {
  catList,
  catDict
}