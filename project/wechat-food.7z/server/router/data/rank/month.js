const monthList = [{
  id: 1,
  name: '2018年',
  children: [{
    id: 101,
    name: '1-6月'
  }, {
    id: 102,
    name: '7月'
  }, {
    id: 103,
    name: '8月'
  }, {
    id: 104,
    name: '9月'
  }]
}]

const monthDict = {
  101: '0106',
  102: '07',
  103: '08',
  104: '09'
}

module.exports = {
  monthList,
  monthDict
}