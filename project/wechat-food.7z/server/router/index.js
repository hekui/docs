const Router = require('koa-router')
const router = new Router()
// const api = require('./../api')

const wechat = require('./modules/wechat')
const account = require('./modules/account')
const user = require('./modules/user')

// 微信
router.use('/wechat', wechat)

// account
router.use('/account', account)

// 绑单
router.use('/user', user)

// 所有未拦截接口
router.all('*', (ctx, next) => {
  console.log('hello api *', ctx.request.path)
  ctx.request.url = ctx.request.url.replace('/api', '')
  return api.fetchJava(ctx, ctx.request.body).then(res => {
    if(res.code === 1014){
      ctx.session.userInfo = null
    }
    ctx.body = res
  }, res => {
    ctx.body = res
  })
})

module.exports = router.routes()