const WXBizDataCrypt = require('./../../lib/wxaes/WXBizDataCrypt')
const log = require('./../../log')('accountService')
const config = require('./../../config')
const api = require('./../../api')

function decryptUserInfo(ctx){
  log.info('ctx.session', ctx.session)
  let result = {}
  let { encryptedData, iv } = ctx.request.body
  if(ctx.session.session_key){
    let sessionKey = ctx.session.session_key
    let wxbdc = new WXBizDataCrypt(config.appId, sessionKey)
    try {
      let data = wxbdc.decryptData(encryptedData, iv)
      log.info('解密用户数据成功:', JSON.stringify(data))
      result = {code: 0, data: data}
    } catch (error) {
      log.info('解密用户数据失败:')
      log.error('Illegal Buffer Error', error)
      result = {
        code: 41,
        msg: '解密用户数据失败',
      }
    }
  } else {
    log.error('err, sessionKey is undefined')
    result = {
      code: 40, msg: '解密用户数据失败(sessionKey is undefined)'
    }
  }
  return result
}

function fetchLogin(ctx, decryptedUserInfo){
  ctx.request.url = '/login'
  return api.fetchPassport(ctx, {
    headImg: decryptedUserInfo.data.avatarUrl,
    nickname: decryptedUserInfo.data.nickName,
    openid: decryptedUserInfo.data.openId,
    //unionId在公共参数中传递
    userInfo: decryptedUserInfo.data,
  })
}

function login(ctx, decryptedUserInfo){
  ctx.request.url = '/login'
  return api.fetchPassport(ctx, {
    headImg: decryptedUserInfo.data.avatarUrl,
    nickname: decryptedUserInfo.data.nickName,
    openid: decryptedUserInfo.data.openId,
    //unionId在公共参数中传递
    userInfo: decryptedUserInfo.data,
  }).then(res => {
    console.log('调用JAVA登录成功', res)
    ctx.session.ticketId = res.data.ticketId
    let userInfoSource = JSON.parse(res.data.userInfo)
    console.log('userInfoSource', userInfoSource)
    let userInfo = {
      ticketId: res.data.ticketId,
      headImg: userInfoSource.avatarUrl,
      nickname: userInfoSource.nickName
    }
    ctx.session.userInfo = userInfo
    console.log('userInfo', userInfo)
    // 组装数据
    ctx.body = {
      code: 0,
      data: userInfo
    }
  }, res => {
    log.error('调用JAVA登录失败', res)
    ctx.body = {
      code: 50,
      msg: '登录失败',
    }
  })
}

function fetchUserInfo(ctx){
  return api.fetchJava(ctx, {}).then(res => {
    console.log('getUserInfo success res', res)
    res.data.ticketId = ctx.session.ticketId
    delete res.data.unionid
    delete res.data.openid

    ctx.body = res
  }, res => {
    console.log('getUserInfo fail res', res)
    if(res.code === 1014){ // session过期，调登录
      ctx.session.ticketId = ''
      // 调用解密方法，解密数据
      let decryptedUserInfo = decryptUserInfo(ctx)
      if(decryptedUserInfo.code === 0){ // 解密成功
        // 获取用户信息
        return login(ctx, decryptedUserInfo)
      }else{ // 解密失败，返回解密失败信息
        ctx.body = decryptedUserInfo
      }
    }else{
      ctx.body = res
    }
  })
}


module.exports = {
  decryptUserInfo,
  fetchUserInfo,
  login,
}