const Router = require('koa-router')
const router = new Router()
const { query } = require('../conn')
const log = require('../../log')('account')
// const api = require('./../api')
const accountService = require('../service/account')

// getUserInfo
router.use('/getUserInfo', async (ctx, next) => {
  // if(ctx.session.userInfo){ // 有用户信息
  //   ctx.body = {
  //     code: 0,
  //     data: ctx.session.userInfo
  //   }
  // }else{
  //   ctx.request.url = '/user/userdata'
  //   if(ctx.session.ticketId){
  //     console.log('')
  //     // 获取用户信息
  //     return accountService.fetchUserInfo(ctx)
  //   }else{
  //     // 调用解密方法，解密数据
  //     let decryptedUserInfo = accountService.decryptUserInfo(ctx)
  //     if(decryptedUserInfo.code === 0){ // 解密成功
  //       // 登录
  //       ctx.request.url = '/login'
  //       return accountService.login(ctx, decryptedUserInfo)
  //     }else{ // 解密失败，返回解密失败信息
  //       ctx.body = decryptedUserInfo
  //     }
  //   }
  // }

  
  if(ctx.session.userId){
    let result = {
      code: 0,
      msg: 'ok',
      data: ctx.session.userInfo
    }
    log.trace('session中有userId - response:', JSON.stringify(result))
    ctx.body = result
  }else{
    // 调用解密方法，解密数据
    let decryptedUserInfo = accountService.decryptUserInfo(ctx)
    if(decryptedUserInfo.code === 0){ // 解密成功 操作数据库
      let sql = 'select userId,nickName,avatarUrl from user where unionId = ?'
      let dataList = await query(sql, decryptedUserInfo.data.unionId)
      if(dataList.length === 0){ //新用户
        let sqlInsert = 'insert into user (unionId, nickName, avatarUrl, openId, userdata) values (?, ?, ?, ?, ?)'
        let insertList = await query(sqlInsert, [decryptedUserInfo.data.unionId, decryptedUserInfo.data.nickName, decryptedUserInfo.data.avatarUrl, decryptedUserInfo.data.openId, JSON.stringify(decryptedUserInfo.data)])
        if(insertList.insertId){ // 新用户插入成功
          dataList = await query(sql, decryptedUserInfo.data.unionId)
        }
      }
      if(dataList.length === 0){
        ctx.body = {
          code: 44,
          msg: '用户未找到',
          data: {}
        }
      }else{
        let userInfo = dataList[0]
        ctx.session.userId = userInfo.userId
        ctx.session.userInfo = userInfo
        let result = {
          code: 0,
          msg: 'ok',
          data: userInfo
        }
        log.trace('select success! - response:', JSON.stringify(result))
        ctx.body = result
      }
    }else{ // 解密失败，返回解密失败信息
      ctx.body = decryptedUserInfo
    }
  }
})

module.exports = router.routes()