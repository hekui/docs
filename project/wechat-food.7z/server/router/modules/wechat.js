const Router = require('koa-router')
const router = new Router()
const axios = require('axios')
// const WXBizDataCrypt = require('./../../lib/wxaes/WXBizDataCrypt')
const config = require('./../../config')
const log = require('./../../log')('wechat')
// const api = require('./../api')
/**
 * getSessionKey接口主要功能：前端wx.login获取code，通过code去微信获取sessionKey
 */
router.all('/getSessionKey', (ctx, next) => {
  // log.info('ctx.req', ctx.req)
  // console.log('hello api /login ctx.request.headers', ctx.request)
  // console.log('ctx.session.user', ctx.session.user)
  const code = ctx.request.body.code
  const url = `https://api.weixin.qq.com/sns/jscode2session?appid=${config.appId}&secret=${config.appSecret}&js_code=${code}&grant_type=authorization_code`
  console.log('url', url)
  return axios({
    method: 'get',
    url,
  }).then(result => {
    log.trace(`${url} - response data: - ${JSON.stringify(result.data)}`)
    ctx.session.session_key = result.data.session_key
    
    ctx.body = {
      code: 0,
      msg: 'ok',
      data: result.data
    }
  }, result => {
    log.error(`${url} - response data: - ${JSON.stringify(result.data)}`)
    ctx.body = {
      code: 1,
      msg: 'error',
      data: result.data
    }
  })
})
// 已弃用
/**
 * getUserInfo，根据上一接口拿取到的sessionKey解密前端通过wx.getUserInfo获取到的encryptedData(包含用户敏感数据，如：openId/unionId)
 */
// router.all('/getUserInfo', (ctx, next) => {
//   log.info('ctx.session', ctx.session)
//   let { encryptedData, iv } = ctx.request.body
//   if(ctx.session.user && ctx.session.user.session_key){
//     let sessionKey = ctx.session.user.session_key
//     let wxbdc = new WXBizDataCrypt(config.appId, sessionKey)
//     let data 
//     try {
//       data = wxbdc.decryptData(encryptedData, iv)
//       log.info('解密用户数据成功:', JSON.stringify(data))
      
//       ctx.session.unionid = data.unionId
//       ctx.session.openid = data.openId

//       // 开始登录
//       ctx.request.url = '/login'
//       return api.fetchPassport(ctx, {
//         headImg: data.avatarUrl,
//         nickname: data.nickName,
//         openid: data.openId,
//         //unionId在公共参数中传递
//         userInfo: data,
//       }).then(res => {
//         console.log('登录res', res)
//         ctx.session.ticketId = res.data.ticketId
//         return ctx.body = res
//       }, res => {
//         log.error('登录失败', res)
//         return ctx.body = {
//           code: 50,
//           msg: '登录失败',
//         }
//       })
//     } catch (error) {
//       log.info('解密用户数据失败:')
//       log.error('Illegal Buffer Error', error)
//       ctx.body = {
//         code: 1,
//         msg: '解密用户数据失败',
//       }
//     }
//   } else {
//     log.error('err, sessionKey is undefined')
//     ctx.body = {code: 1, msg: 'sessionKey is undefined'}
//   }
// })

module.exports = router.routes()