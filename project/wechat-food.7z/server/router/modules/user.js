const Router = require('koa-router')
const router = new Router()
const {query} = require('./../conn')
/**
 * list
 */
router.all('/addrList', async(ctx, next) => {
  let sql = 'select * from userAddr where isDel = 0 and userId = ? order by id desc'
  let data = await query(sql, ctx.session.userId)
  ctx.body = {
    code: 0,
    data: data
  }
})

/**
 * detail
 */
router.all('/addrDetail', async(ctx, next) => {
  let id = ctx.request.body.id
  if(id){
    let sql = 'select * from userAddr where isDel = 0 and id = ?'
    let data = await query(sql, id)
    ctx.body = {
      code: 0,
      data: data[0]
    }
  }else{
    ctx.body = {
      code: 10,
      msg: 'id不能为空'
    }
  }
})

/**
 * delete
 */
router.all('/addrDel', async(ctx, next) => {
  let id = ctx.request.body.id
  if(id){
    let sql = "update userAddr set isDel = 1 where isDel = 0 and id = ?"
    let data = await query(sql, id)
    ctx.body = {
      code: 0,
      data: data[0]
    }
  }else{
    ctx.body = {
      code: 10,
      msg: 'id不能为空'
    }
  }
})

/**
 * setDefault, 设置默认
 */
router.all('/addrSetDefault', async(ctx, next) => {
  let id = ctx.request.body.id
  if(id){
    let sql = 'update userAddr set isDefault = 0 where isDel = 0 and userId = ?'
    await query(sql, ctx.session.userId)
    sql = "update userAddr set isDefault = 1 where id = ?"
    await query(sql, id)
    // console.log(data)
    ctx.body = {
      code: 0,
      msg: 'ok'
    }
  }else{
    ctx.body = {
      code: 10,
      msg: 'id不能为空'
    }
  }
})

/**
 * edit/add
 */
router.all('/addrEdit', async(ctx, next) => {
  console.log('in addrEdit', ctx.request.body)
  let params = ctx.request.body
  // let sql = 'select * from userAddr where id = ?'
  // let result

  if(params.id){ // 编辑
    let sqlUpdate = 'update userAddr set userId = ?, name = ?, phone = ?, province = ?, city = ?, country = ?, address = ? where isDel = 0 and id = ?'
    let data = await query(sqlUpdate, [ctx.session.userId, params.name, params.phone, params.province, params.city, params.country, params.address, params.id])
    // console.log('sqlUpdate data:', data)
  }else{ // 新增
    let sqlInsert = 'insert into userAddr (userId, name, phone, province, city, country, address) values (?, ?, ?, ?, ?, ?, ?)'
    let data = await query(sqlInsert, [ctx.session.userId, params.name, params.phone, params.province, params.city, params.country, params.address])
    // console.log('sqlInsert data:', data)
    if(data.insertId){
      // result = await query(sql, [data.insertId])

    }else{
      return ctx.body = {
        code: 55,
        msg: '数据库操作异常'
      }
    }
  }
  // let sql = 'select * from userAddr where userId = ?'
  // let dataList = await query(sql, ctx.session.userId)
  ctx.body = {
    code: 0,
    msg: 'ok',
    // data: result
  }
})

module.exports = router.routes()