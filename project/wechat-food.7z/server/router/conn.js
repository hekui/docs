const mysql      = require('mysql')
const config     = require('./../config');
const log = require('./../log')('sql')

const pool = mysql.createPool(config.database);

let query = function( sql, values ) {
  return new Promise(( resolve, reject ) => {
    pool.getConnection(function(err, connection) {
      if (err) {
        reject( err )
      } else {
        let sqlf = mysql.format(sql, values)
        log.trace('query sql:', sqlf)
        connection.query(sqlf, (err, rows) => {
          if ( err ) {
            reject( err )
          } else {
            resolve( rows )
          }
          connection.release()
        })
      }
    })
  })
  .catch((error) => {
    log.fatal('Promise error', error);
    return {}
  });
}

module.exports = { query }