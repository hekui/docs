const config = {
  appId: 'wxd90415eaffdd5638',
  appSecret: '9079160feb83dc1bf67c5a16cf175bc8',
  database: {
    host: '127.0.0.1',  // 数据库地址
    // port: '3306',
    user: 'root', // 数据库用户
    password: '123456', // 数据库密码
    database: 'food' // 选中数据库
  },
  loginList: [ // 需要登录的接口名单
    '/user/addrList', // 用户收货地址列表
    '',
  ]
}

module.exports = config