export const port = process.env.PORT || 3005;
// test1
export const dbConfig = {
    host: process.env.dbHost || '10.254.33.50', // 192.168.10.239
    port: process.env.dbPort || 3306,
    database: process.env.dbDatabase || 'fgc',
    username: process.env.dbUsername || 'root',
    password: process.env.dbPassword || 'zGYkc2@9Us&rPid5'
}
// dev
// export const dbConfig = {
//     host: process.env.dbHost || '192.168.10.239', // 
//     port: process.env.dbPort || 3306,
//     database: process.env.dbDatabase || 'fgc',
//     username: process.env.dbUsername || 'mylive',
//     password: process.env.dbPassword || 'devsgo'
// }

export const redisConfig = {
    host: process.env.redisHost || '192.168.10.239', // 192.168.10.238
    port: process.env.redisPort || 6379, // 11001
    db: process.env.redisDB == null ? 2 : process.env.redisDB
}

// ali oss config
export const OSSConfig = {
  region: process.env.aliOssRegion || 'oss-cn-beijing',
  accessKeyId: process.env.aliOssAccessKeyId || 'LTAITrE7L8rNTN8k',
  accessKeySecret: process.env.aliOssAccessKeySecret || 'LYsICBPmcecaDsogD38R3K2osy0iKF',
  bucket: process.env.aliOssBucket || 'fangguancha-img'
}

export const fgcImgHost = process.env.fgcImgHost || 'https://img1.fangguancha.com';//图片服务器地址
export const adminHost = process.env.adminHost || 'http://admin.test1.fangguancha.com'; // admin后台   贾磊：http://192.168.10.79