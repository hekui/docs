import HousesDetails from './model';
import Dict from '../sys-dict/model';

HousesDetails.belongsTo(Dict, {foreignKey: 'decorate_type'})

export default HousesDetails;