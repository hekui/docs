import DataTypes from 'sequelize';
import sequelize from '../instance';

const HousesDetails = sequelize.define('houses_details', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    decorate_type: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    decorate_standard: {
      type: DataTypes.STRING(40),
      allowNull: true
    },
    opening_title: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    opening_times: {
      type: DataTypes.DATE,
      allowNull: true
    },
    opening_timed: {
      type: DataTypes.STRING(20),
      allowNull: true
    },
    opening_info: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    sub_time: {
      type: DataTypes.DATE,
      allowNull: true
    },
    sub_info: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    ratio_plot: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    ratio_afforest: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    h_type: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    elevator: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    ratio_obtain: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    give_area: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    quality: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    unfavorable_factors: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    plan_project: {
      type: DataTypes.STRING(500),
      allowNull: true
    },
    assort: {
      type: DataTypes.STRING(500),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'houses_details'
  });

  export default HousesDetails;