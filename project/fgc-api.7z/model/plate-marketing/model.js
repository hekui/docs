import DataTypes from 'sequelize';
import sequelize from '../instance';

const PlateMarketing = sequelize.define('plate_marketing', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(60),
      allowNull: true
    },
    sponsor: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    marketing_mode: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    sustain_time: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    influence_range: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    on_channel: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    marketing_innovation: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    case_vote: {
      type: DataTypes.STRING(25),
      allowNull: true
    },
    marketing_expense: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    media_attention_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    now_month_sale: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    rel_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    rel_link: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    dynamic_content: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    check_date: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_comment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    checker: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_offline: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    pubdate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    activity_picture1: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    activity_picture2: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    activity_picture3: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    check_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    }
  }, {
    tableName: 'plate_marketing'
  });

  export default PlateMarketing;