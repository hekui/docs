import PlateMarketing from './model';

export default PlateMarketing;