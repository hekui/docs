import DataTypes from 'sequelize';
import sequelize from '../instance';
const PlateLandForeshow = sequelize.define("PlateLandForeshow",{
    id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true
    },
    plate: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    land_parcel_no: {
        type: DataTypes.STRING(20),
        allowNull: true
    },
    address: {
        type: DataTypes.STRING(55),
        allowNull: true
    },
    region: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    district: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    site_area: {
        type: "DOUBLE(11,2)",
        allowNull: true
    },
    use_property: {
        type: DataTypes.STRING(22),
        allowNull: true
    },
    plot_ratio: {
        type: "DOUBLE(11,2)",
        allowNull: true
    },
    type: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    price: {
        type: "DOUBLE(11,2)",
        allowNull: true
    },
    unit: {
        type: DataTypes.STRING(20),
        allowNull: true
    },
    total_price: {
        type: DataTypes.STRING(10),
        allowNull: true
    },
    rel_date: {
        type: DataTypes.DATE,
        allowNull: true
    },
    rel_link: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    dynamic_content: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    sort_order: {
        type: DataTypes.INTEGER(11),
        allowNull: true
    },
    creater: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    modifier: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: '0000-00-00 00:00:00'
    },
    status: {
        type: DataTypes.INTEGER(4),
        allowNull: true,
        defaultValue: '1'
    },
    check_status: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    check_date: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    check_comment: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    checker: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    is_offline: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    pubdate: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: '0000-00-00 00:00:00'
    }
}, {
    tableName: 'plate_land_foreshow'
});
export default PlateLandForeshow;
