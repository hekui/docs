import PlateLandForeshow from "./model";
import Dict from '../sys-dict/model';
import PlateLandTran from '../plate-land-tran/model';

PlateLandForeshow.belongsTo(Dict,{foreignKey:"region",as:"regionDict"});
PlateLandForeshow.belongsTo(Dict,{foreignKey:"district",as:"districtDict"});
PlateLandForeshow.belongsTo(PlateLandTran, {foreignKey: 'land_parcel_no', targetKey: 'land_parcel_no'})
export default PlateLandForeshow;