import HousesMarket from './model';

export default HousesMarket;