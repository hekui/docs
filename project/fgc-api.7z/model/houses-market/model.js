import DataTypes from 'sequelize';
import sequelize from '../instance';

const HousesMarket = sequelize.define('houses_market', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    region_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    region_name: {
      type: DataTypes.STRING(40),
      allowNull: true
    },
    market_date: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    sale_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    marke_price: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_off: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    online_date: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'houses_market'
  });

  export default HousesMarket;