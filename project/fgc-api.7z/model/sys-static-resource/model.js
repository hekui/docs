import DataTypes from 'sequelize';
import sequelize from '../instance';

const Resource = sequelize.define('sys_static_resource', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city_code: {
      type: DataTypes.STRING(30),
      allowNull: true
    },
    code: {
      type: DataTypes.STRING(30),
      allowNull: false
    },
    name: {
      type: DataTypes.STRING(60),
      allowNull: false
    },
    type: {
      type: DataTypes.INTEGER(4),
      allowNull: false
    },
    parent_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    level: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    sort_order: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '0'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    content: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'sys_static_resource'
  });

  export default Resource;