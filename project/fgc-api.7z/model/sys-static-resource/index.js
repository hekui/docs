import Resource from './model';

export default Resource;