export default {
    /**
     * 查询全部返回plain数据
     * @param {*} options 
     */
    findPlainAll(options) {
        return this.findAll(options).then(data => {
            return data.map(item => {
                return item.get({plain: true});
            })
        });
    },
    
    /**
     * 分页查询
     * @param {number} page 
     * @param {number} pageSize 
     * @param {*} options 
     */
    pagingQuery(page = 1, pageSize = 20, options) {
        if (page && typeof page == 'string') {
            page = parseInt(page);
        } 
        if (pageSize && typeof pageSize == 'string') {
            pageSize = parseInt(pageSize);
        }
        return this.findAndCountAll(Object.assign({     
            offset: (page - 1) * pageSize,
            limit: pageSize
        }, options)).then(result => {
            return {
                total: result.count,
                hasPrev: page > 1,
                hasNext: page * pageSize < result.count,
                list: result.rows
            }
        })
    },

    /**
     * 检查数据是否符合要求
     * @param {object} model 
     * @param {Array} fields 
     */
    checkModel(model, fields) {
        return new Promise((resolve, reject) => {            
            if (!model || !fields) {
                reject({message: '参数不能为空'});
            }
            let key = '';

            for (let i = 0, len = fields.length; i < len; i++) {
                key = fields[i];
                if (!model[key]) {
                    reject({message: `${key}不能为空`});
                }
            }
            resolve();
        });
    }  

}