import DataTypes from 'sequelize';
import sequelize from '../instance';

const ContentAdvert = sequelize.define('content_advert', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(30),
      allowNull: false
    },
    activity_img: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    activity_position: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    sort_order: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '0'
    },
    start_time: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    end_time: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    relation_url: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'content_advert'
  });

export default ContentAdvert;