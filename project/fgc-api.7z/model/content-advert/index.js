import ContentAdvert from './model';
import ContentPosition from '../content-position/model';

ContentAdvert.belongsTo(ContentPosition, {foreignKey: 'activity_position'});

export default ContentAdvert;