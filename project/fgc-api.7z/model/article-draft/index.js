import ArticleDraft from "./model";
import Dict from '../sys-dict/model';

export default ArticleDraft;
