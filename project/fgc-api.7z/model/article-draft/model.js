import DataTypes from 'sequelize';
import sequelize from '../instance';
const ArticleDraft = sequelize.define('article_draft', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    img_path: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    wx_openid: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    generate_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'article_draft'
  });
  
export default ArticleDraft;