import EvaluationResult from './model';

export default EvaluationResult;