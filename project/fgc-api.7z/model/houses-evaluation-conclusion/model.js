import DataTypes from 'sequelize';
import sequelize from '../instance';

const EvaluationResult = sequelize.define('houses_evaluation_conclusion', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    score: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_company: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_product: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_property: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_reputation: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    summary: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'houses_evaluation_conclusion'
  });

  export default EvaluationResult;