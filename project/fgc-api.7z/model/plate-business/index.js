import PlateBusiness from './model';
import Dict from '../sys-dict/model';
import BusinessDynamic from '../plate-business-dynamic/model';

PlateBusiness.belongsTo(Dict, {foreignKey: 'type'});
PlateBusiness.hasMany(BusinessDynamic, {foreignKey: 'plate_business_id', as: 'dynamics'});

export default PlateBusiness; 