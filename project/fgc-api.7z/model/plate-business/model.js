import DataTypes from 'sequelize';
import sequelize from '../instance';

const PlateBusiness = sequelize.define('plate_business', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    plate: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    name: {
      type: DataTypes.STRING(25),
      allowNull: true
    },
    type: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    sort_order: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    opening_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    vacancy_rate: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    price: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    rent: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    developers: {
      type: DataTypes.STRING(52),
      allowNull: true
    },
    section: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    oneself_ratio: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    property_company: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    given_area: {
      type: DataTypes.INTEGER(9),
      allowNull: true
    },
    environment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    traffic: {
      type: DataTypes.STRING(52),
      allowNull: true
    },
    project_plan: {
      type: DataTypes.STRING(52),
      allowNull: true
    },
    peripheral: {
      type: DataTypes.STRING(102),
      allowNull: true
    },
    list_cover: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    detail_cover: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    check_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_date: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_comment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    checker: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_offline: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    pubdate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    developers_company_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    property_company_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    opening_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    investment: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    p_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    business_volume: {
      type: DataTypes.STRING(20),
      allowNull: true
    },
    business_company: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    business_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
    tableName: 'plate_business'
  });

  export default PlateBusiness;