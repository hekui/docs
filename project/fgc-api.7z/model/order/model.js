import DataTypes from 'sequelize';
import sequelize from '../instance';

const Order = sequelize.define('order', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    plate_id: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    plate: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    u_id: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    money: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    desc: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '0'
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: DataTypes.NOW()
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    type: {
      type: DataTypes.INTEGER(4).UNSIGNED,
      allowNull: true,
      defaultValue: '1'
    }
  }, {
    tableName: 'order'
  });

  export default Order;