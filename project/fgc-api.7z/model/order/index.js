import Order from './model';

export default Order;