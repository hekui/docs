import BBSPost from './model';
import BBSPostBack from '../bbs-post-back/model';
BBSPost.hasMany(BBSPostBack, {foreignKey: 'post_id'});
BBSPostBack.belongsTo(BBSPost,{foreignKey:"post_id"});
BBSPostBack.belongsTo(BBSPost,{foreignKey:"post_id",as:"bbs"});
export default BBSPost;