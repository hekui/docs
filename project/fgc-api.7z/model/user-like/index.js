import UserLike from './model';

export default UserLike;