import HousesComment from './model';

export default HousesComment;