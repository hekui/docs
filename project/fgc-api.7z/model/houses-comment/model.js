import DataTypes from 'sequelize';
import sequelize from '../instance';

const HousesComment = sequelize.define('houses_comment', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    h_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    content: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    com_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    pdu_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    pty_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    mou_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    comment_at: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: DataTypes.NOW()
    },
    u_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    u_name: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    u_avator: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: DataTypes.NOW()
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    }
  }, {
    tableName: 'houses_comment'
  });

  export default HousesComment;