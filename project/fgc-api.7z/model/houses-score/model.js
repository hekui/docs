import DataTypes from 'sequelize';
import sequelize from '../instance';

const HousesScore = sequelize.define('houses_score', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    com_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    com_show: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    pdu_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    pdu_show: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    pty_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    pty_show: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    mou_score: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    mou_show: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'houses_score'
  });

  export default HousesScore;