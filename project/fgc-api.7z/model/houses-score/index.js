import HousesScore from './model';

export default HousesScore;