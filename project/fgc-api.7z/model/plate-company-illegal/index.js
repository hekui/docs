import CompanyIllegal from './model';
import PlateCompany from '../plate-company/model';

CompanyIllegal.belongsTo(PlateCompany, {foreignKey: 'property_id'});

export default CompanyIllegal;