import DataTypes from 'sequelize';
import sequelize from '../instance';

const CompanyIllegal = sequelize.define('plate_company_illegal', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    property_name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    property_id: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    relation_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    illegal_type: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    relation_url: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    content: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_date: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_comment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    checker: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_offline: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    pubdate: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'plate_company_illegal'
  });

  export default CompanyIllegal;