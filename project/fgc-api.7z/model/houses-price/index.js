import HousesPrice from './model';

export default HousesPrice;