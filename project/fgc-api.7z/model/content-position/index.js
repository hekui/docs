import ADPosition from './model';

export default ADPosition;