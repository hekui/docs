import ArticleGift from './model';

export default ArticleGift;