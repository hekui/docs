import DataTypes from 'sequelize';
import sequelize from '../instance';

const ArticleGift = sequelize.define('article_gift', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    a_id: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    title: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    author: {
      type: DataTypes.STRING(40),
      allowNull: true
    },
    release_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    times: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    money: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      defaultValue: '0'
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: DataTypes.NOW()
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: DataTypes.NOW()
    }
  }, {
    tableName: 'article_gift'
  });

export default ArticleGift;