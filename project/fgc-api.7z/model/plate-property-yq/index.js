import PropertyYq from './model';

export default PropertyYq;