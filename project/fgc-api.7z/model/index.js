import PlateCompany from './plate-company';
import CompanyDynamic from './plate-company-dynamic';
import CompanyIllegal from './plate-company-illegal';

import CompanyBasic from './company-basic';

import PlateLandForeshow from "./plate-land-foreshow";
import PlateLandTran from "./plate-land-tran";

import Dict from './sys-dict';
import Resource from './sys-static-resource';

import PlateBusiness from './plate-business';
import BusinessDynamic from './plate-business-dynamic';

import PlateEstater from './plate-estater';
import EstaterDynamic from './plate-estater-dynamic';

import PlateDistrict from './plate-district';
import DistrictDynamic from './plate-district-dynamic';

import PlateMarketing from './plate-marketing';

import PlatePolicy from './plate-policy';

import BBSPost from './bbs-post';
import BBSPostBack from './bbs-post-back';

import UInfo from "./u-info";
import UAccount from "./u-account";

import UserFollow from './user-follow';
import UComment from "./u-comment";
import UCollection from "./u-collection";

import UserLike from './user-like';

import Article from "./article";
import ArticleGift from './article-gift';
import ArticleDraft from './article-draft';
import Comment from './comment'
import CommentRevert from './comment-revert'

import HousesBasic from './houses-basic';
import HousesDetails from './houses-details';
import EvaluationResult from './houses-evaluation-conclusion';
import HousesEvaluating from './houses-evaluating';
import HousesRights from './houses-rights';
import HousesScore from './houses-score';
import HOusesPrice from './houses-price';
import HousesMarket from './houses-market';
import HousesComment from './houses-comment';

import PlateProperty from './plate-property';
import PropertyYq from './plate-property-yq';

import BbsRead from "./bbs-read";

import ContentAdvert from './content-advert';
import ContentPosition from './content-position';

import Order from './order';

import ContentReport from './content-report';
import ReportElement from './content-report-element';

import Analysts from './analysts';

import BackendAccount from './backend-account';

import URule from './u-rule';

import UReportEmail from './u-report-email'

export {
    PlateCompany,
    CompanyDynamic,
    CompanyBasic,
    PlateLandForeshow,
    PlateLandTran,
    Dict,
    PlateBusiness,
    BusinessDynamic,
    PlateEstater,
    EstaterDynamic,
    PlateDistrict,
    DistrictDynamic,
    PlateMarketing,
    PlatePolicy,
    BBSPost,
    BBSPostBack,
    UserFollow,
    UserLike,
    UInfo,
    UAccount,
    UComment,
    UCollection,
    Article,
    ArticleGift,
    Comment,
    CommentRevert,
    HousesBasic,
    HousesDetails,
    EvaluationResult,
    BbsRead,
    HousesEvaluating,
    PropertyYq,
    CompanyIllegal,
    HousesRights,
    HousesScore,
    HOusesPrice,
    HousesMarket,
    HousesComment,
    ContentAdvert,
    ContentPosition,
    Order,
    Resource,
    PlateProperty,
    ContentReport,
    ReportElement,
    Analysts,
    ArticleDraft,
    BackendAccount,
    URule,
    UReportEmail,
}
