import PlateLandTran from "./model";
import Dict from '../sys-dict/model';
PlateLandTran.belongsTo(Dict,{foreignKey:"region",as:"regionDict"});
PlateLandTran.belongsTo(Dict,{foreignKey:"district",as:"districtDict"});
export default PlateLandTran;
