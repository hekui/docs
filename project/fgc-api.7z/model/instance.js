import Sequelize from 'sequelize';
import { dbConfig } from '../config/sys.config';
import baseMethods from './base-methods';

const sequelize = new Sequelize(dbConfig.database, dbConfig.username, dbConfig.password, {
    host: dbConfig.host,
    port: dbConfig.port,
    dialect: 'mysql',

    pool: {
        max: 5,
        min: 0, 
        idle: 10000
    },

    define: {
        freezeTableName: true,
        timestamps: false,  
        classMethods: baseMethods
    },

    timezone: '0',

    logging: process.argv.indexOf('--production') > -1 ? false : console.log
    //logging:false
});

sequelize.authenticate().then(err => {
    console.log('Connection has been established successfully.')
}).catch(err => {
    console.log('Unable to connect to the database:', err);
});

//导出model sequelize-auto -o d:/data/fgc -h 192.168.10.239 -p 3306 -d fgc -u mylive -x devsgo  -e mysql

export default sequelize;
