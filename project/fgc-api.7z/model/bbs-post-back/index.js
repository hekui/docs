import Sequelize from 'sequelize';
import BBSPostBack from './model';
import UserLike from '../user-like/model';

BBSPostBack.hasMany(BBSPostBack, {
    foreignKey: 'to_id', 
    as: 'reply'
});
BBSPostBack.belongsTo(BBSPostBack, {
    foreignKey: 'to_id',
    as: 'comment'
});

BBSPostBack.hasOne(UserLike, {foreignKey: 'plate_id'})

export default BBSPostBack;