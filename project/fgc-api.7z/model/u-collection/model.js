import DataTypes from 'sequelize';
import sequelize from '../instance'
const UCollection = sequelize.define("user_collection",{
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  plate_id: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  plate: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  u_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  u_name: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW()
  }
}, {
  tableName: 'user_collection'
});
export  default UCollection;
