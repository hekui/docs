import UCollection from "./model";
import Article from "../article"
Article.hasMany(UCollection,{foreignKey:"plate_id"});
UCollection.belongsTo(Article,{foreignKey:"plate_id"});
export default UCollection
