import DataTypes from 'sequelize';
import sequelize from '../instance';
const BbsRead = sequelize.define('bbs_read',{
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  u_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  is_read: {
    type: DataTypes.INTEGER(4),
    allowNull: true,
    defaultValue: '0'
  },
  creater: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  modifier: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW()
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'bbs_read'
});
export default BbsRead;