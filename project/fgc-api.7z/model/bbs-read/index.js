import BbsRead from "./model";
export default BbsRead;
