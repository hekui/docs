import HousesBasic from './model';
import EvaluationResult from '../houses-evaluation-conclusion/model';
import Dict from '../sys-dict/model';
import HouseDetails from '../houses-details/model';
import HOusesPrice from '../houses-price/model';

HousesBasic.hasOne(EvaluationResult, {as: 'result', foreignKey: 'h_id'});
HousesBasic.belongsTo(Dict, {foreignKey: 'region'});
HousesBasic.belongsTo(Dict, {as: 'secondRegion', foreignKey: 'orientation'});

HousesBasic.hasOne(HouseDetails, {as: 'detail', foreignKey: 'h_id'});
HousesBasic.hasMany(HOusesPrice, {foreignKey: 'h_id'});

export default HousesBasic;