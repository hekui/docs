import DataTypes from 'sequelize';
import sequelize from '../instance';

const HousesBasic = sequelize.define('houses_basic', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    name: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    developer: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    developer_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    list_cover: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    region: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    orientation: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    sort_order: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    address: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    is_opening: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    is_off: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    online_date: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'houses_basic'
  });

  export default HousesBasic;