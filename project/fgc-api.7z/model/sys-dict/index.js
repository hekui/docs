import Dict from './model';

Dict.hasMany(Dict, {foreignKey: 'parent_id', as: 'children'});
Dict.belongsTo(Dict, {foreignKey: 'parent_id', as: 'parent'});
export default Dict;