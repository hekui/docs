import ContentReport from './model';
import Dict from '../sys-dict/model';
import ReportElement from '../content-report-element/model';
import Order from '../order/model';

ContentReport.belongsTo(Dict, {foreignKey: 'column'});
ContentReport.hasMany(ReportElement, {foreignKey: 'r_id', as: 'details'});
ContentReport.hasMany(Order, {foreignKey: 'plate_id'})

export default ContentReport;