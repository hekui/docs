import DataTypes from 'sequelize';
import sequelize from '../instance';

const ContentReport = sequelize.define('content_report', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city_code: {
      type: DataTypes.STRING(30),
      allowNull: true
    },
    title: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    description: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    keywords: {
      type: DataTypes.STRING(500),
      allowNull: true
    },
    list_cover: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    column: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    money: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    statement_code: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    pv_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },    
    pv_num_basic: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    pay_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    like_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    collection_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0'
    },
    analysiser: {
      type: DataTypes.STRING(250),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    online_date: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'content_report'
  });

export default ContentReport;