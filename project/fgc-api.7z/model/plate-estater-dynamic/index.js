import EstaterDynamic from './model';
import PlateEstater from '../plate-estater/model';

EstaterDynamic.belongsTo(PlateEstater, {foreignKey: 'plate_company_id'})

export default EstaterDynamic;