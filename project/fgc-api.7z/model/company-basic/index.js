import CompanyBasic from './model';

export default CompanyBasic;