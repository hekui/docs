import Article from "./model";
import Dict from '../sys-dict/model';

Article.belongsTo(Dict, {as: 'type', foreignKey: 'column_id'});
Article.belongsTo(Dict, {as: 'tagTable', foreignKey: 'tags_id'});
Article.belongsTo(Dict, {as: 'src', foreignKey: 'source_id'});
Article.belongsTo(Dict, {as: 'support', foreignKey: 'support_code'});
export default Article;
