import DataTypes from 'sequelize';
import sequelize from '../instance';
const Article = sequelize.define("article", {
    id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING(100),
        allowNull: true,
        validate: {
            len: {
                args: [1, 50],
                msg: '标题不能超过50个字符'
            }
        }
    },
    city_code: {
        type: DataTypes.STRING(30),
        allowNull: true
    },
    description: {
        type: DataTypes.STRING(250),
        allowNull: true,
        validate: {
            len: {
                args: [1, 200],
                msg: '摘要不能超过200个字符'
            }
        }
    },
    keywords: {
        type: DataTypes.STRING(250),
        allowNull: true,
        validate: {
            itemLen: function (str) {
                if (str) {
                    let arr = str.split(',');
                    if (arr.some(v => v.length > 6)) {
                        throw new Error('每个关键词不能超过6个字符')
                    }
                }
            }
        }
    },
    list_cover: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    author: {
        type: DataTypes.STRING(10),
        allowNull: true,
        validate: {
            len: {
                args: [1, 10],
                msg: '作者不能超过10个字符'
            }
        }
    },
    editor: {
        type: DataTypes.STRING(10),
        allowNull: true,
        validate: {
            len: {
                args: [0, 10],
                msg: '编辑不能超过10个字符'
            }
        }
    },
    support_code: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    support_url: {
        type: DataTypes.STRING(250),
        allowNull: true
    },
    statement_code: {
        type: DataTypes.STRING(250),
        allowNull: true
    },
    pv_num: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: '0'
    },
    pv_num_basic: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: '0'
    },
    comment_num: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: '0'
    },
    like_num: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: '0'
    },
    collection_num: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: '0'
    },
    content: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    creater: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    modifier: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW()
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW()
    },
    check_status: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    check_date: {
        type: DataTypes.DATE,
        allowNull: true
    },
    check_comment_type: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    check_comment: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    checker: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    status: {
        type: DataTypes.INTEGER(4),
        allowNull: true
    },
    city: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    column_id: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    column: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    tags_id: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    tags: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    source_id: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    source: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    is_offline: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    pubdate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    is_hot: {
        type: DataTypes.INTEGER(4),
        allowNull: true,
        defaultValue: '0'
    },
    prerelease_time: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    qr_code: {
        type: DataTypes.INTEGER(4),
        allowNull: true,
        defaultValue: 1
    },
    is_restore: {
        type: DataTypes.INTEGER(4),
        allowNull: true,
        defaultValue: 1
    },
    relation_house: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    relation_id: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    is_top: {
        type: DataTypes.INTEGER(4),
        allowNull: true,
        defaultValue: '0'
    },
}, {
    tableName: 'article'
});
export default Article;
