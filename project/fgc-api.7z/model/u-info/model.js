import DataTypes from 'sequelize';
import sequelize from '../instance';
const UInfo =  sequelize.define("x_info",{
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  city_code: {
      type: DataTypes.STRING(30),
      allowNull: true
  },
  nick_name: {
    type: DataTypes.STRING(40),
    allowNull: true
  },
  name: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  thumb: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  sex: {
    type: DataTypes.INTEGER(1),
    allowNull: true
  },
  email: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  tel: {
    type: DataTypes.STRING(15),
    allowNull: true
  },
  qq: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  insert_time: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW()
  },
  update_time: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW()
  }
},{ 
  tableName: 'x_info'
});
export default UInfo;
 