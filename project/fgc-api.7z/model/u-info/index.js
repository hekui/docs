import UInfo from "./model";
import UAccount from "../u-account";
UInfo.hasOne(UAccount,{foreignKey:"id"});

export default  UInfo;