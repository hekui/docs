import DataTypes from 'sequelize';
import sequelize from '../instance';

const HousesEvaluating = sequelize.define('houses_evaluating', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    h_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    ratio_liabilities: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_liabilities: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_liabilities: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    buildinglands: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_buildinglands: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_buildinglands: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_areascore: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    lfdesign_code: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    lfdesign_des: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    score_lfdesign: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_lfdesign: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    layoutdesign_code: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    layoutdesign_des: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    score_layoutdesign: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_layoutdesign: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    sales_area: {
      type: DataTypes.STRING(20),
      allowNull: true
    },
    sales_num: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    sales_order: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_sales: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_sales: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    property_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    property_name: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    property_qualified: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    score_property: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_property: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    propertyyq_num: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    score_propertyyq: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_propertyyq: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    illegal_num: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_illegal: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_illegal: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    rights_num: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    score_rights: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    share_rights: {
      type: DataTypes.STRING(10),
      allowNull: true
    },
    data_sources: {
      type: DataTypes.STRING(500),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'houses_evaluating'
  });

  export default HousesEvaluating;