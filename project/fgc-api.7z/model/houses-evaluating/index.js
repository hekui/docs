import HousesEvaluating from './model';
import EvaluationResult from '../houses-evaluation-conclusion/model';
import Dict from '../sys-dict/model';
import PropertyYq from '../plate-property-yq/model';
import CompanyIllegal from '../plate-company-illegal/model';
import HousesRights from '../houses-rights/model';
import HousesBasic from '../houses-basic/model';
import PlateProperty from '../plate-property/model';

HousesEvaluating.belongsTo(EvaluationResult, {as: 'result', foreignKey: 'h_id', targetKey: 'h_id'});
HousesEvaluating.belongsTo(Dict, {foreignKey: 'property_qualified'});
HousesEvaluating.hasMany(PropertyYq, {as: 'yq', foreignKey: 'property_id', sourceKey: 'property_id'});
HousesEvaluating.hasMany(HousesRights, {as: 'rights', foreignKey: 'h_id', sourceKey: 'h_id'});
HousesEvaluating.belongsTo(HousesBasic, {foreignKey: 'h_id'});
HousesEvaluating.belongsTo(PlateProperty, {foreignKey: 'property_id'})

export default HousesEvaluating;