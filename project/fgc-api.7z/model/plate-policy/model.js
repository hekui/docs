import DataTypes from 'sequelize';
import sequelize from '../instance';

const PlatePolicy = sequelize.define('plate_policy', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(60),
      allowNull: true
    },
    depart: {
      type: DataTypes.STRING(12),
      allowNull: true
    },
    policy_purpose: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    influence_object: {
      type: DataTypes.STRING(32),
      allowNull: true
    },
    rel_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    rel_link: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    dynamic_content: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    check_date: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_comment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    checker: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_offline: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    pubdate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    }
  }, {
    tableName: 'plate_policy'
  });

  export default PlatePolicy;