import PlatePolicy from './model';

export default PlatePolicy;