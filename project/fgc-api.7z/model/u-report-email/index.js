import UReportEmail from "./model";
export default UReportEmail
