import DataTypes from 'sequelize';
import sequelize from '../instance'
const UReportEmail = sequelize.define("content_report_details",{
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  r_id: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  u_id: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  username: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  email: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  pay_at: {
    type: DataTypes.DATE,
    allowNull: true
  },
  email_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW()
  },
  report_name: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  send_at:  {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  tableName: 'content_report_details'
});
export  default UReportEmail;
