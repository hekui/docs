import UserFollow from './model';
import BBSPost from "../bbs-post";

BBSPost.hasMany(UserFollow,{foreignKey: 'plate_id'});
UserFollow.belongsTo(BBSPost,{foreignKey: 'plate_id'});
export default UserFollow;
