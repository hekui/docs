import PlateProperty from './model';
import Dict from '../sys-dict/model';

PlateProperty.belongsTo(Dict, {foreignKey: 'credentials'})

export default PlateProperty;