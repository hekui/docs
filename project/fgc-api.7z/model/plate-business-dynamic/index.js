import BusinessDynamic from './model';
import PlateBusiness from '../plate-business/model';

BusinessDynamic.belongsTo(PlateBusiness, {foreignKey: 'plate_business_id'});

export default BusinessDynamic;