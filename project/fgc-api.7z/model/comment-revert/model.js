import DataTypes from 'sequelize'
import sequelize from '../instance'

const CommentRevert = sequelize.define('article_revert', {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  c_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  u_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  username: {
    type: DataTypes.STRING(50)
  },
  creater: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  creater_user: {
    type: DataTypes.STRING(50)
  },
  revert_content: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  revert_at: {
    type: DataTypes.DATE,
    allowNull: true
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW()
  }
}, {
  tableName: 'article_revert'
})

export default CommentRevert