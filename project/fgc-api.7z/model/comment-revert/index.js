import CommentRevert from './model'
export default CommentRevert