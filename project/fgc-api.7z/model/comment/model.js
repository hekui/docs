import DataTypes from 'sequelize'
import sequelize from '../instance'

const Comment = sequelize.define('article_comment', {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  a_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  u_id: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  username: {
    type: DataTypes.STRING(50)
  },
  comment_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW()
  },
  status: {
    type: DataTypes.INTEGER(4),
    defaultValue: 1
  },
  like: {
    type: DataTypes.BIGINT,
    allowNull: false,
    defaultValue: 0
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW()
  }
}, {
  tableName: 'article_comment'
})

export default Comment