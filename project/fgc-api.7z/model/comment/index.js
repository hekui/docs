import Comment from  './model'
export default Comment