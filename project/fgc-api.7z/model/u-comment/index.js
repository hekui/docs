import UComment from "./model";
export default UComment;