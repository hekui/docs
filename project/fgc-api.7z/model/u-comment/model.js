import DataTypes from 'sequelize';
import sequelize from '../instance'
const UComment = sequelize.define("user_comment",{
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true
  },
  plate_id: {
    type: DataTypes.BIGINT,
    allowNull: false
  },
  plate: {
    type: DataTypes.STRING(20),
    allowNull: false
  },
  u_avator: {
    type: DataTypes.STRING(250),
    allowNull: true
  },
  u_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  u_name: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  uto_avator: {
    type: DataTypes.STRING(250),
    allowNull: true,
    defaultValue: '0'
  },
  uto_id: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  uto_name: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  content: {
    type: DataTypes.STRING(500),
    allowNull: true
  },
  back_num: {
    type: DataTypes.INTEGER(11),
    allowNull: true
  },
  hot_num: {
    type: DataTypes.INTEGER(11),
    allowNull: true
  },
  creater: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  modifier: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  status: {
    type: DataTypes.INTEGER(4),
    allowNull: true,
    defaultValue: '1'
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: '0000-00-00 00:00:00'
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: '0000-00-00 00:00:00'
  }
}, {
  tableName: 'user_comment'
});
export default UComment;
