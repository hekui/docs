import DataTypes from 'sequelize';
import sequelize from '../instance'
const UAccount = sequelize.define("x_account", {
    id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true
    },
    wx_openid: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    qq_openid: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    username: {
        type: DataTypes.STRING(40),
        allowNull: true
    },
    email: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    tel: {
        type: DataTypes.STRING(15),
        allowNull: true
    },
    password: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    insert_time: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW()
    },
    update_time: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW()
    },
    last_time: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW()
    },
    this_time: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW()
    },
    last_ip: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    this_ip: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    state: {
        type: DataTypes.INTEGER(1),
        allowNull: true,
        defaultValue: '0'
    },
    hash: {
        type: DataTypes.CHAR(6),
        allowNull: true
    },
    is_comment: {
        type: DataTypes.INTEGER(6),
        allowNull: true,
        defaultValue: '0'
    },
    last_port: {
        type: DataTypes.STRING(20),
        allowNull: true
    }
}, {
        tableName: 'x_account'
    });
export default UAccount;