import UAccount from "./model";

export default UAccount;