import URule from './model';

export default URule;