import DataTypes from 'sequelize';
import sequelize from '../instance';

const URule =  sequelize.define('u_rule', {
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    item_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    item_name: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    nick_name: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    state: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      defaultValue: '0'
    },
    insert_time: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    tableName: 'u_rule'
  });
  
export default URule;
 