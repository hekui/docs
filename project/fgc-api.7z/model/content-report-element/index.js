import ReportElement from './model';

export default ReportElement;