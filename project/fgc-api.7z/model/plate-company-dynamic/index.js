import CompanyDynamic from './model';
import PlateCompany from '../plate-company/model';

CompanyDynamic.belongsTo(PlateCompany, {foreignKey: 'plate_company_id', targetKey: 'id'}); 

export default CompanyDynamic;