import PlateCompany from './model';
import CompanyDynamic from '../plate-company-dynamic/model';
import CompanyBasic from '../company-basic/model';
import Dict from '../sys-dict/model';

PlateCompany.belongsTo(Dict, {foreignKey: 'type'});  
PlateCompany.hasMany(CompanyDynamic, {foreignKey: 'plate_company_id', as:"dynamics"}) 
PlateCompany.belongsTo(CompanyBasic, {foreignKey: 'company_id'});

export default PlateCompany;

