import DistrictDynamic from './model';
import PlateDistrict from '../plate-district/model';

DistrictDynamic.belongsTo(PlateDistrict, {foreignKey: 'plate_district_id'});

export default DistrictDynamic;