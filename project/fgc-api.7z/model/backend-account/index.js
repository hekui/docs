import BackendAccount from './model';
import URule from '../u-rule/model';

BackendAccount.hasOne(URule, {foreignKey: 'user_id'});

export default BackendAccount;