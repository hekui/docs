import DataTypes from 'sequelize';
import sequelize from '../instance';

const PlateDistrict = sequelize.define('plate_district', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    plate: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    name: {
      type: DataTypes.STRING(25),
      allowNull: true
    },
    region: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    district: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    picture: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    scope_range: {
      type: DataTypes.STRING(52),
      allowNull: true
    },
    price: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    resource_advantage: {
      type: DataTypes.STRING(24),
      allowNull: true
    },
    support_plan: {
      type: DataTypes.STRING(52),
      allowNull: true
    },
    developers: {
      type: DataTypes.STRING(52),
      allowNull: true
    },
    project_price_increase: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    land_price_increase: {
      type: DataTypes.STRING(22),
      allowNull: true
    },
    sort_order: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    check_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_date: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_comment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    checker: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_offline: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    pubdate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    score: {
      type: DataTypes.STRING(5),
      allowNull: true
    }
  }, {
    tableName: 'plate_district'
  });

  export default PlateDistrict;