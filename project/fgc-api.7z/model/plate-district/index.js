import PlateDistrict from './model';
import DistrictDynamic from '../plate-district-dynamic/model';

PlateDistrict.hasMany(DistrictDynamic, {foreignKey: 'plate_district_id', as: 'dynamics'});

export default PlateDistrict;