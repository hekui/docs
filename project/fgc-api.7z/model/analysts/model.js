import DataTypes from 'sequelize';
import sequelize from '../instance';

const Analysts = sequelize.define('analysts', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    city_code: {
      type: DataTypes.STRING(30),
      allowNull: true
    },    
    name: {
      type: DataTypes.STRING(20),
      allowNull: true
    },
    describe: {
      type: DataTypes.STRING(160),
      allowNull: true
    },
    head_img: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.TIME,
      allowNull: true,
      defaultValue: '0000-00-00 00:00:00'
    }
  }, {
    tableName: 'analysts'
  });

export default Analysts;