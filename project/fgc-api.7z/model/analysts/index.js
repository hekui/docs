import Analysts from './model';

export default Analysts;