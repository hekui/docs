import DataTypes from 'sequelize';
import sequelize from '../instance';

const PlateEstater = sequelize.define('plate_estater', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true
    },
    plate: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    name: {
      type: DataTypes.STRING(25),
      allowNull: true
    },
    region: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    district: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    avatar: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    company: {
      type: DataTypes.STRING(25),
      allowNull: true
    },
    job_position: {
      type: DataTypes.STRING(20),
      allowNull: true
    },
    introduce: {
      type: DataTypes.STRING(310),
      allowNull: true
    },
    sort_order: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    creater: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    modifier: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    status: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1'
    },
    check_status: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_date: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    check_comment_type: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    check_comment: {
      type: DataTypes.STRING(100),
      allowNull: true
    },
    checker: {
      type: DataTypes.BIGINT,
      allowNull: true
    },
    is_offline: {
      type: DataTypes.INTEGER(4),
      allowNull: true
    },
    pubdate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00'
    },
    company_id: {
      type: DataTypes.BIGINT,
      allowNull: true
    }
  }, {
    tableName: 'plate_estater'
  });

  export default PlateEstater;