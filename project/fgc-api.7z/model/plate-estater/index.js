import PlateEstater from './model';
import EstaterDynamic from '../plate-estater-dynamic/model';
import CompanyBasic from '../company-basic/model';

PlateEstater.hasMany(EstaterDynamic, {foreignKey: 'plate_company_id', as: 'dynamics'});
PlateEstater.belongsTo(CompanyBasic, {foreignKey: 'company_id'});

export default PlateEstater;