import HousesRights from './model';

export default HousesRights;