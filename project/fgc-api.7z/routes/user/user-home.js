import express from 'express';
import {UserService, UserAvatar} from '../../service';
import helper from '../helper';
import logger from '../../logger'
const router = express.Router();
/**
 * 新增用户
 * @param wx_openid
 * @param thumb
 * @param nick_name 昵称
 * @returns {Promise.<TResult>}
 */
router.post("/getUser",(req,res) =>{
    logger({
        api: '/getUser',
        desc: JSON.stringify(req.body)
    })
    console.log(req.body)
    if(!req.body.wx_openid ){
        helper.comError(res,{message:"wx_openid can't be empty"});
    }else {
        UserService.existsUser(req.body)
            .then(_result =>{
                if(!_result){
                    return UserService.addUser(req.body)
                        .then(_data =>{
                            UserService.UserInfor(req.body).then(_data =>{
                                // 下载用户头像
                                UserAvatar({
                                    u_id: _data.id,
                                    thumb: req.body.thumb
                                })
                            })
                            helper.comSuccess(res,_data, "用户插入成功")
                        })
                }else {
                    return UserService.UserInfor(req.body)
                        .then(_data =>{
                            if (_data) {
                                _data = _data.get({plain: true});
                                UserService.updateAccountTime(req.body.city_code, _data.id, _data.this_time);
                                UserService.updateUserInfo(req.body.city_code, _data.id, req.body.nick_name);
                                // 下载用户头像
                                UserAvatar({
                                    u_id: _data.id,
                                    thumb: req.body.thumb
                                })
                            }
                            helper.comSuccess(res,_data);
                        })
                }
                
            }).catch(_err =>{
                helper.comError(res,_err);
            })
    }
});

/**
 * 获取关注,收藏，评论总数
 * @param u_id
 * @param thumb
 * @param nick_name 昵称
 * @returns {Promise.<TResult>}
 */
router.post("/getCount",(req,res) =>{
        if( !req.body.u_id){
            helper.comError(res,{message:"u_id can't be empty"});
        }
        else {
            req.body.id = req.body.u_id;
            return Promise.all([
                UserService.getFollowCount(req.body),
                UserService.getCollectionCount(req.body),
                UserService.getUCommentCount(req.body),
                UserService.hasNewMessage(req.body)
            ]).then(_result => {
                helper.comSuccess(res, {followCount: _result[0], collectionCount: _result[1], commentCount: _result[2],hasNew:_result[3]});
            }).catch(_err =>{
                helper.comError(res,_err);
            })
        }

    }
);
export default router;
