import express from 'express';
import helper from '../helper';
import { followService } from '../../service';

const router = express.Router();

/**
 * 查询用户是否关注过该板块(plate_id)
 */
router.post('/exists', (req, res) => {
    if (!req.body.plate_id) {
        helper.comError(res, {message: 'plate_id can not be empty.'})
    } else {        
        followService.exists(req.body)
            .then(isExists => {
                helper.comSuccess(res, isExists);
            }).catch(err => {
                helper.comError(res, err);
            });
    }
})

/**
 * 取消关注(plate_id, u_id)
 */
router.post('/delete', (req, res) => {
    if (!req.body.plate_id || !req.body.u_id) {
        helper.comError(res, {message: 'plate_id, u_id can not be empty.'})
    } else {
        followService.exists(req.body).then(isExists => {
            if (isExists) {                
                return followService.delete(req.body)
                    .then(_data => {
                        helper.comSuccess(res, null, '成功取消关注');
                    })
            } else {
                helper.comError(res, {message: '要删除的内容不存在'});
            }
        }).catch(err => {
            helper.comError(res, err);
        });
    }
});
/**
 * 关注列表 u_id 
 */
router.post("/followList",(req,res) =>{
    if(!req.body.u_id){
       helper.comError(res,{message:"u_id不能为空"});
   }else {
        req.body.id =req.body.u_id;
       followService.getList(req.body)
           .then(_data =>{
               helper.comSuccess(res,_data);
           })
           .catch(_err =>{
               helper.comError(res,_err)
           })
   }
});

export default router;