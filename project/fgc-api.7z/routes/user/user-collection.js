import express from 'express';
import helper from '../helper';
import { collectionService } from '../../service';
/**
 * 收藏列表 u_id
 */
const router = express.Router();
router.post("/collectionList",(req,res) =>{
   if(!req.body.u_id){
       helper.comError(res,{message:"u_id不能为空"});
   }else {
       req.body.id = req.body.u_id;
       collectionService.getList(req.body)
           .then(_data =>{
                _data.list.map(item => {
                    item.pv_num += item.pv_num_basic
                    delete item.pv_num_basic;
                    return item
                })
               helper.comSuccess(res,_data);
           })
           .catch(_err =>{
               helper.comError(res,_err);
           })
   }
});
export default router

