import express from 'express';
import helper from '../helper';
import { likeService } from '../../service';

const router = express.Router();

/**
 * 查询用户是否已点赞过该板块(plate_id)
 */
router.post('/exists', (req, res) => {
    if (!req.body.plate_id) {
        helper.comError(res, {message: 'plate_id can not be empty.'})
    } else {        
        likeService.exists(req.body)
            .then(isExists => {
                helper.comSuccess(res, isExists);
            }).catch(err => {
                helper.comError(res, err);
            });
    }
})

export default router;