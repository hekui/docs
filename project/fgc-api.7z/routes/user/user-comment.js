import express from 'express';
import helper from '../helper';
import { CommentService,UserService } from '../../service';
const router = express.Router();
/**
 * 评论回复列表
 * @param page
 * @param pageSize
 * @param id
 * @returns {*}
 */
router.post('/list',(req,res) =>{
    if(!req.body.u_id){
        helper.comError(res,{message:"用户u_id不能为空"});
    }else {
        req.body.id = req.body.u_id;
        UserService.hasNewMessage(req.body)
            .then(_result=>{
                if(_result){
                    return Promise.all([
                        UserService.readMessage(req.body),
                        CommentService.commentAndReply(req.body)
                    ]).then(_data =>{
                        helper.comSuccess(res,_data[1]);
                    }).catch(_err =>{
                        helper.comError(res,_err);
                    })
                }else {
                    CommentService.commentAndReply(req.body)
                        .then(_data =>{
                            helper.comSuccess(res,_data);
                        })
                        .catch(_err =>{
                            helper.comError(res,_err);
                        })
                }

            });
    }
});
export default router;