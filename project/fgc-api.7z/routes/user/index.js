import express from 'express';
import userFollow from './user-follow';
import userLike from './user-like';
import userHome from "./user-home";
import userCollection from "./user-collection";
import userComment from "./user-comment";

const router = express.Router();
router.use('/follow', userFollow);
router.use('/like', userLike);
router.use('/home', userHome);
router.use('/collection',userCollection);
router.use('/comment',userComment);

export default router;