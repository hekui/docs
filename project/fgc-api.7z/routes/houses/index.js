import express from 'express';
import { housesService, EvaluatingService, housesCommentService } from '../../service';
import helper from '../helper';

const router = express.Router(); 

/**
 * 获取区域列表
 */
router.post('/getRegions', (req, res) => {
    housesService.getRegions(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
});

/**
 * 获取预警情况列表
 */
router.post('/getWarnList', (req, res) => {
    helper.comSuccess(res, housesService.getWarns());
});

/**
 * 获取评测列表(分页)
 * 筛选参数(regionId:区域id； warnRnage: 预警分数范围； scoreOrder: 1升序，2降序)
 */
router.post('/getList', (req, res) => {
    housesService.getList(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
});

/**
 * 根据关键字搜索楼盘名字
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        housesService.search(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    } 
})


/**
 * 根据关键字搜索楼盘评测结果(分页)
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, {});
    } else {
        housesService.searchPaging(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

/**
 * 根据楼盘id搜索单个楼盘
 */
router.post('/searchSingle', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        housesService.searchHouseByID(req.body.id)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

/**
 * 根据楼盘id获取楼盘详情
 */
router.post('/detail', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        housesService.getHouseDetailById(req.body.id)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

/**
 * 获取楼盘评测报告
 */
router.post('/getEvaluation', (req, res) => {
    if (!(req.body.houseID && req.body.companyID && req.body.regionID)) {
        helper.comError(res, {message: 'houseID, companyID, regionID  can not be empty.'});
    } else {
        EvaluatingService.getAllEvaluation(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

/**
 * 获取维权信息报表
 * @param houseID
 * @returns {*}
 */
router.post('/getRightsList',(req,res) =>{
    if(!req.body.houseID){
        helper.comError(res,{message:"楼盘ID不能为空。"});
    }else {
        EvaluatingService.getRightsLists(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(_err =>{
                helper.comError(res,_err);
            })
    }
});

/**
 * 获取违法信息报表
 * @param companyID
 * @returns {*} illegal_type:1严重违法 2普通违法
 */
router.post('/getIllegalList',(req,res) =>{
    if(!req.body.companyID){
        helper.comError(res,{message:"公司ID不能为空。"});
    }else {
        EvaluatingService.getIllegalLists(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(_err =>{
                helper.comError(res,_err);
            })
    }
});
/**
 * 获取舆情信息报表
 * @param property_id
 * @returns {*}
 */
router.post('/getYqList',(req,res) =>{
    if(!req.body.property_id){
        helper.comError(res,{message:"物业ID不能为空。"});
    }else {
        EvaluatingService.getYqList(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(_err =>{
                helper.comError(res,_err);
            })
    }
});

/**
 * 获取楼盘和区域12个月的价格走势图
 */
router.post('/getPrices', (req, res) => {
    if(!req.body.h_id || !req.body.name){
        helper.comError(res, {message: 'h_id, name can not be empty.'});
    }else {
        housesService.getAllPrices(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(_err =>{
                helper.comError(res,_err);
            })
    }
});

/**
 * 添加楼盘评价(必填字段：'h_id', 'content', 'com_score', 'pdu_score', 'pty_score', 'mou_score', 'u_id', 'u_name', 'u_avator')
 */
router.post('/addComment', (req, res) => {
    housesCommentService.addComment(req.body)
        .then(_data =>{
            helper.comSuccess(res,null, '评价成功');
        })
        .catch(_err =>{
            helper.comError(res,_err);
        })
});

/**
 * 获取用户综合评价分数
 */
router.post('/getCommentScore', (req, res) => {
    if(!req.body.h_id){
        helper.comError(res, {message: 'h_id can not be empty.'});
    }else {
        housesCommentService.getCommentScore(req.body.h_id)
            .then(_data =>{
                helper.comSuccess(res,_data);
            }).catch(_err =>{
                helper.comError(res,_err);
            })
    }
});

/**
 * 获取楼盘评价列表（分页） 
 */
router.post('/getCommentList', (req, res) => {
    if(!req.body.h_id){
        helper.comError(res, {message: 'h_id can not be empty.'});
    }else {
        housesCommentService.getCommentList(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(_err =>{
                helper.comError(res,_err);
            })
    }
})


export default router;