import express from 'express'
import helper from './helper'
import {commentsService} from '../service' 
const router = express.Router()

// 留言列表
router.post('/list', (req, res) => {
  if (!req.body.articleId) {
    helper.comError(res, {message: 'articleId can not be empty.'});
  } else {
    commentsService.List(req.body)
      .then(data => {
        helper.comSuccess(res, data);
      }).catch(err => {
        helper.comError(res, err);
      })
  }
})

// 某条留言
router.post('/details', (req, res) => {
  if (!req.body.commentId) {
      helper.comError(res, {message: 'commentId can not be empty.'});
  } else {
    commentsService.Get(req.body)
      .then(data => {
        helper.comSuccess(res, data);
      }).catch(err => {
        helper.comError(res, err);
      })
  }
})

// 添加留言
router.post('/add', (req, res) => {
  if (!req.body.articleId || !req.body.u_id) {
      helper.comError(res, {message: 'articleId,u_id can not be empty.'});
  } else {
    commentsService.Post(req.body)
      .then(data => {
        helper.comSuccess(res, data);
      }).catch(err => {
        helper.comError(res, err);
      })
  }
})

// 增加留言点赞数
router.post('/incrementLike', (req, res) => {
    if (!req.body.commentId || !req.body.u_id) {
        helper.comError(res, {message: 'commentId,u_id can not be empty.'});
    } else {
      commentsService.incrementLike(req.body)
        .then(data => {
          helper.comSuccess(res, data);
        }).catch(err => {
          helper.comError(res, err);
        })
    }
})

// 取消留言点赞数
router.post('/decrementLike', (req, res) => {
    if (!req.body.commentId || !req.body.u_id) {
        helper.comError(res, {message: 'commentId,u_id can not be empty.'});
    } else {
      commentsService.decrementLike(req.body)
        .then(data => {
          helper.comSuccess(res, data);
        }).catch(err => {
          helper.comError(res, err);
        })
    }
})

export default router