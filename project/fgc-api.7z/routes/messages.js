import express from 'express'
import helper from './helper'
import {commentsService} from '../service' 
const router = express.Router()

// 未读消息条数
router.post('/unreadCount', (req, res) => {
  if (!req.body.u_id) {
    helper.comError(res, {message: 'u_id can not be empty.'});
  } else {
    commentsService.MessageUnreadCount(req.body)
      .then(data => {
        helper.comSuccess(res, data);
      }).catch(err => {
        helper.comError(res, err);
      })
  }
})

// 消息列表
router.post('/list', (req, res) => {
  if (!req.body.u_id) {
    helper.comError(res, {message: 'u_id can not be empty.'});
  } else {
    commentsService.MessageList(req.body)
      .then(data => {
        helper.comSuccess(res, data);
      }).catch(err => {
        helper.comError(res, err);
      })
  }
})

export default router