import express from 'express';
import { orderService } from '../../service';
import helper from '../helper';

const router = express.Router(); 

/**
 * 更新支付订单状态（1成功，2失败）
 * 参数(id: 订单id, status: 支付状态)
 */
router.post('/setStatus', (req, res) => {
    if (!req.body.id || !req.body.status || !req.body.money) {
        helper.comError(res, {message: 'id, status, money can not be empty.'});
    } else {
        orderService.updateStatus(req.body)
        .then(_data => {
            helper.comSuccess(res, null, '修改订单状态成功');
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

export default router;