import express from 'express'
import helper from './helper'
import {advertService} from '../service' 
const router = express.Router()

router.use('/image', (req, res) => {
  if (!req.body.positionCode) {
    helper.comError(res, {message: 'positionCode can not be empty.'});
  } else {
    commentsService.Image(req.body)
      .then(data => {
        helper.comSuccess(res, data);
      }).catch(err => {
        helper.comError(res, err);
      })
  }
})

router.use('/articleBottomImage', (req, res) => {
  advertService.ArticleBottomImage(req.body)
    .then(data => {
      helper.comSuccess(res, data);
    }).catch(err => {
      helper.comError(res, err);
    })
})

export default router