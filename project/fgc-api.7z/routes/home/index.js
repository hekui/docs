import express from 'express';
import { homeService, housesService, articleService, bbsService, reportService } from '../../service';
import helper from '../helper';

const router = express.Router(); 

/**
 * 获取首页banner
 */
router.post('/getBanner', (req, res) => {
    homeService.getBannerList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 获取8个购房指数楼盘
 */
router.post('/getHouseList', (req, res) => {
    housesService.getRandomList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 首页综合搜索
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        Promise.all([
            housesService.searchForHome(req.body),
            articleService.searchForHome(req.body),
            bbsService.searchForHome(req.body),
            reportService.searchForHome(req.body)
        ]).then(result => {
            let articles = result[1]
            articles.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic
                return item
            })
            let report = result[3]
            report.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic
                return item
            })
            helper.comSuccess(res, {
                houses: result[0],
                articles: articles,
                bbs: result[2],
                report: report
            });
        }).catch(err => {
            helper.comError(res, err);
        });
    }
})

export default router;