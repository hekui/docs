import express from 'express'
import helper from './helper'
import {SysService} from '../service' 
const router = express.Router()

// city list
router.post('/city', (req, res) => {
  SysService.List(req.body).then(data => {
    helper.comSuccess(res, data);
  }).catch(err => {
    helper.comError(res, err);
  })
})

export default router