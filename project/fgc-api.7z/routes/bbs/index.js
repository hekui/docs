import express from 'express';
import { bbsService, bbsBackService, followService, likeService, bbsReadService } from '../../service';
import helper from '../helper';

const router = express.Router(); 

/**
 * 获取话题列表(分页page, pageSize)
 */
router.post('/getList', (req, res) => {
    bbsService.getList(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
});

/**
 * 根据id获取话题
 */
router.post('/getPostById', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {
        bbsService.getPostByID(req.body.id, req.body.u_id)
            .then(_data => {
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            });
    }
});

/**
 * 根据postID获取话题评论信息（分页）
 */
router.post('/getComments', (req, res) => {
    if (!req.body.postID) {
        helper.comError(res, {message: 'postID can not be empty.'})
    } else {
        bbsBackService.getCommentsByID(req.body)
            .then(_data => {
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            });
    }
})

/**
 * 关注话题(必填字段：plate_id, u_id)
 */
router.post('/followTopic', (req, res) => {
    if (!req.body.plate_id || !req.body.u_id) {
        helper.comError(res, {message: 'plate_id, u_id can not be empty.'})
    } else {
        followService.exists(req.body)
            .then(isExist => {
                if (isExist) {
                    helper.comError(res, {message: '已关注过该内容'});
                } else {
                    return followService.add(req.body, 'BbsPost')
                        .then(_data => {
                            helper.comSuccess(res, null, '关注成功');
                        })
                }
            }).catch(err => {
                helper.comError(res, err);
            });
    }
});

/**
 * 给话题评论点赞(必填字段：plate_id, u_id)
 */
router.post('/likeComment', (req, res) => {
    if (!req.body.plate_id || !req.body.u_id) {
        helper.comError(res, {message: 'plate_id, u_id can not be empty.'})
    } else {
        likeService.exists(req.body)
            .then(isExist => {
                if (isExist) {
                    helper.comError(res, {message: '已点赞过'});
                } else {
                    return likeService.add(req.body, 'BbsPostBack')
                        .then(async _data => {
                            let count = await likeService.count(req.body.plate_id, 'BbsPostBack');
                            bbsBackService.setLikeNum(req.body.plate_id, count);
                            helper.comSuccess(res, null, '点赞成功');
                        })
                }
            }).catch(err => {
                helper.comError(res, err);
            });
    }
});

/**
 * 取消评论点赞(必填字段：plate_id, u_id)
 */
router.post('/unlikeComment', (req, res) => {
    if (!req.body.plate_id || !req.body.u_id) {
        helper.comError(res, {message: 'plate_id, u_id can not be empty.'})
    } else {
        likeService.exists(req.body)
            .then(isExist => {
                if (isExist) {
                    return likeService.delete(req.body)
                        .then(async () => {
                            let count = await likeService.count(req.body.plate_id, 'BbsPostBack');
                            bbsBackService.setLikeNum(req.body.plate_id, count);
                            helper.comSuccess(res, null, '成功取消点赞');
                        })
                } else {
                    helper.comError(res, {message: '要取消的内容不存在'});
                }
            }).catch(err => {
                helper.comError(res, err);
            });
    }
});

/**
 * 评论话题(必填字段:'post_id', 'content', 'u_id', 'u_name', 'u_avator', 'tou_id')
 */
router.post('/addComment', (req, res) => {
    bbsBackService.addComment(req.body)
        .then(async () => {
            let count = await bbsBackService.count(req.body.post_id);
            bbsService.setCommentNum(req.body.post_id, count);
            if (req.body.u_id != req.body.tou_id) {                
                bbsReadService.setReadStatus(req.body.tou_id, 0);
            }
            helper.comSuccess(res, null, '评论成功');
        }).catch(err => {
            helper.comError(res, err);
        });
})

/**
 * 发布话题
 */
router.post('/addTopic', (req, res) => {
    bbsService.addTopic(req.body)
        .then(() => {
            helper.comSuccess(res, null, '发布话题成功');
        }).catch(err => {
            helper.comError(res, err);
        });
})

/**
 * 根据关键字搜索话题标题列表
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        bbsService.search(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    } 
})

/**
 * 根据关键字搜索话题结果列表(分页)
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, {});
    } else {
        bbsService.searchPaging(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    } 
})

/**
 * 根据评论id获取该条评论信息
 */
router.post('/getComment', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        bbsBackService.getComment(req.body.id)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 根据评论id获取回复列表
 */
router.post('/getBackList', (req, res) => {
    if (!req.body.commentID) {
        helper.comError(res, {message: 'commentID can not be empty.'});
    } else {
        bbsBackService.getBackList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 回复评论(必填字段：'content', 'u_id', 'u_name', 'u_avator', 'to_id', 'tou_id')
 */
router.post('/addBack', (req, res) => {
    bbsBackService.addBack(req.body)
        .then(async id => {
            let count = await bbsBackService.countBack(req.body.to_id);
            bbsBackService.editCommentInfo(req.body.to_id, id, count);
            if (req.body.u_id != req.body.tou_id) { 
                bbsReadService.setReadStatus(req.body.tou_id, 0);
            }
            helper.comSuccess(res, null, '回复成功');
        }).catch(err => {
            helper.comError(res, err);
        })
})

export default router;