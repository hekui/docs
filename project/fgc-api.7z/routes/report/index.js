import express from 'express';
import { reportService, dictService, orderService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取行业报告类型
 */
router.post('/getType', (req, res) => {
    dictService.getDictByType(req.body.city_code, 110)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
})

/**
 * 根据筛选条件获取行业报告列表
 * @param typeID 报告类型ID
 * @param charge 1免费，2付费
 */
router.post('/getList', (req, res) => {
    reportService.getList(req.body)
        .then(_data => {
            _data.list.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic
                return item
            })
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
})

/**
 * 根据关键字搜索行业报告标题
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        reportService.search(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 根据关键字搜索行业报告结果列表（分页）
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        reportService.searchPaging(req.body)
        .then(_data => {
            _data.list.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic
                return item
            })
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 根据ID搜索单个行业报告
 */
router.post('/searchSingle', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        reportService.searchSingle(req.body.id)
        .then(_data => {
            _data.pv_num += _data.pv_num_basic
            delete _data.pv_num_basic
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 更新行业报告浏览量
 */
router.post('/setPvNum', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        reportService.updatePvNum(req.body.id)
        .then(() => {
            helper.comSuccess(res, null, '更新行业报告浏览量');
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 获取首页行业报告滚动列表
 */
router.post('/getScrollList', (req, res) => {
    reportService.getLimitList(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
})

/**
 * 根据报告ID获取行业报告详情(并更新浏览量)
 */
router.post('/getDetail', (req, res) => {
    if (!req.body.plate_id) {
        helper.comError(res, {message: 'plate_id can not be empty.'});
    } else {
        reportService.getDetailByID(req.body)
        .then(_data => {
            reportService.updatePvNum(req.body.plate_id);
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 创建支付订单（必填字段：'plate_id', 'u_id', 'money';可选字段：'desc'描述信息250个字符, 'type': 默认1表示打赏2购买）
 */
router.post('/addOrder', (req, res) => {
    // type:2 表示购买
    req.body.type = 2;

    orderService.addOrder(req.body, 'ContentReport')
        .then(_data => {
            helper.comSuccess(res, _data, '创建订单成功');
        }).catch(err => {
            helper.comError(res, err);
        })
})

/**
 * 获取用户支付过的行业报告列表（分页）
 */
router.post('/getPaidList', (req, res) => {
     if (!req.body.u_id) {
        helper.comError(res, {message: 'u_id can not be empty.'});
    } else {
        reportService.getPaidReports(req.body)
        .then(_data => {
            _data.list.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic
                return item
            })
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 修改行业报告订单状态
 */
router.post('/setOrderStatus', (req, res) => {
    if (!req.body.id || !req.body.status || !req.body.money) {
        helper.comError(res, {message: 'id, status, money can not be empty.'});
    } else {
        orderService.updateStatus(req.body)
        .then(_status => {
            if (_status == 1) {
                reportService.addPayNum(req.body.id);
            }
            helper.comSuccess(res, null, orderService.getOrderMsg(_status));
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

/**
 * 获取邮箱数
 */
router.post('/reportEmailCount', (req, res) => {
    if (!req.body.report_id || !req.body.u_id) {
        helper.comError(res, {message: 'report_id, u_id can not be empty.'});
    } else {
      reportService.getReportEmail(req.body)
      .then(data => {
          helper.comSuccess(res, data, '');
      }).catch(err => {
          helper.comError(res, err);
      })
    }
})

/**
 * 添加邮件获取报告
 */
router.post('/addEmail', (req, res) => {
    if (!req.body.report_id || !req.body.email || !req.body.u_id) {
        helper.comError(res, {message: 'report_id, email, u_id can not be empty.'});
    } else {
        reportService.addEmail(req.body)
        .then(_count => {
            helper.comSuccess(res, {
              count: _count,
              userInfo: req.body
            }, '');
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

export default router;
