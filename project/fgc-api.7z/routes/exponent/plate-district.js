import express from 'express';
import { districtService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取区域动态
 */
router.post('/getDynamic', (req, res) => {
    districtService.getDynamicList(req.body)
        .then(_data => {            
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 获取区域列表
 */
router.post('/getDistrictList', (req, res) => {
    districtService.getDistrictList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

export default router;