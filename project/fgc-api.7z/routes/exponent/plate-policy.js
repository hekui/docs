import express from 'express';
import { policyService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取政策列表(不传date返回全部)
 * @param {可选string('xxxx')} req.body.date
 */
router.post('/getList', (req, res) => {
    policyService.getList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

export default router;