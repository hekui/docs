import express from 'express';
import { dictService, businessService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取商业项目分类
 */
router.post('/getTypes', (req, res) => {
    dictService.getDictByType(101)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 获取商业项目动态
 */
router.post('/getDynamic', (req, res) => {
    if (!req.body.typeId) {
        helper.comError(res, {message: 'typeId can not be empty.'})
    } else {     
        businessService.getDynamicByType(req.body)
            .then(_data => {            
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
});

/**
 * 获取商业项目列表
 */
router.post('/getBusinessList', (req, res) => {
    if (!req.body.typeId) {
        helper.comError(res, {message: 'typeId can not be empty.'})
    } else {     
        businessService.getBusinessByType(req.body)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
});

/**
 * 获取公司详情
 */
router.post('/getBusinessDetails', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {     
        businessService.getDetailsById(req.body.id)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
})

/**
 * 根据关键字搜索商业项目名字
 * @param {String} req.body.keyword
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        businessService.search(req.body.keyword)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
});

/**
 * 根据关键字查询商业项目结果(分页)
 * @param {String} req.body.keyword
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, {});
    } else {
        businessService.searchPaging(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
});

/**
 * 根据商业项目id获取商业项目信息
 */
router.post('/info', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {
        businessService.getBusinessByID(req.body.id)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }  
});

export default router;