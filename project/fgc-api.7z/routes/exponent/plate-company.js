import express from 'express';
import { dictService, companyService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取公司分类
 */
router.post('/getTypes', (req, res) => {
    dictService.getDictByType(100)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 获取公司动态
 */
router.post('/getDynamic', (req, res) => {
    if (!req.body.typeId) {
        helper.comError(res, {message: 'typeId can not be empty.'})
    } else {     
        companyService.getDynamicByType(req.body)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
});

/**
 * 获取公司列表
 */
router.post('/getCompanyList', (req, res) => {
    if (!req.body.typeId) {
        helper.comError(res, {message: 'typeId can not be empty.'})
    } else {     
        companyService.getCompanyByType(req.body)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
});

/**
 * 根据关键字搜索公司名字列表(获取所有匹配的公司名称)
 * @param {String} req.body.keyword
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        companyService.searchCompany(req.body.keyword)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
});

/**
 * 根据关键字分页查询公司结果
 * @param {String} req.body.keyword
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, {});
    } else {
        companyService.searchCompanyPaging(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
});

/**
 * 根据公司ID获取公司信息
 */
router.post('/info', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        companyService.getCompanyByID(req.body.id)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    } 
})

/**
 * 获取公司详情
 */
router.post('/getCompanyDetails', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {     
        companyService.getDetailsById(req.body.id)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
})

export default router;