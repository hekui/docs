import express from 'express';
import plateCompany from './plate-company';
import plateLand from './plate-land';
import plateBusiness from './plate-business';
import plateEstater from './plate-estater';
import plateDistrict from './plate-district';
import plateMarketing from './plate-marketing';
import platePolicy from './plate-policy';

const router = express.Router();
router.use('/company', plateCompany);
router.use('/land', plateLand);
router.use('/business', plateBusiness);
router.use('/estater', plateEstater);
router.use('/district', plateDistrict);
router.use('/marketing', plateMarketing);
router.use('/policy', platePolicy);

export default router;