import express from 'express';
import { estaterService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取地产人动态
 */
router.post('/getDynamic', (req, res) => {
    estaterService.getDynamicList(req.body)
        .then(_data => {            
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 获取地产人列表
 */
router.post('/getEstaterList', (req, res) => {
    estaterService.getEstaterList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 获取地产人详情
 */
router.post('/getEstaterDetails', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {     
        estaterService.getDetailsById(req.body.id)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
})

/**
 * 根据关键字搜索地产人名字
 * @param {String} req.body.keyword
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        estaterService.search(req.body.keyword)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
});

/**
 * 根据关键字搜索地产人结果(分页)
 * @param {String} req.body.keyword
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, {});
    } else {
        estaterService.searchPaging(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
});

/**
 * 根据id获取地产人信息
 */
router.post('/info', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {     
        estaterService.getEstaterByID(req.body.id)
            .then(_data => {                
                helper.comSuccess(res, _data);
            }).catch(err => {
                helper.comError(res, err);
            })
    }
})

export default router;