import express from 'express';
import {LandService} from '../../service';
import helper from '../helper';
const router = express.Router();
/**
 *根据获取列表
 * @param page
 * @param pageSize
 *  @param statu 0:预告 1:成交 true
 * @param typeId 1:拍卖 2：挂牌 false
 * @param results 1:成交 2：流派 3：融派 4：终止 false
 * @param dateTime false 2012-12-12
 */

router.post('/getList',(req,res) =>{
    if(req.body.statu == 0){
        LandService.getForeshowListByType(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(err =>{
                helper.comError(res,err);
            })
    }else if (req.body.statu == 1){
        LandService.getTranListByType(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(err =>{
                helper.comError(res,err);
            })
    }else {
        helper.comError(res, {message: 'statu is error or statu is empty'})
    }
});
/**
 * 获取预告总数
 */
 router.post('/getForeCount',(req,res) =>{
    return LandService.getForeCount().then(_result =>{
        helper.comSuccess(res,{total:_result})
    }).catch(_err =>{
        helper.comError(res,_err);
    })
 });
/**
 * 获取成交总数
 */
router.post('/getTranCount',(req,res) =>{
    return LandService.getTranCount().then(_result =>{
        helper.comSuccess(res,{total:_result})
    }).catch(_err =>{
        helper.comError(res,_err);
    })
});
/**
 * 根据关键字查询竞得企业列表
 * @param keyword
 */
router.post('/search',(req,res) =>{
   if(!req.body.keyword){
       helper.comSuccess(res,[])
   }else {
       LandService.searchByCompany(req.body.keyword)
           .then(_data =>{
               helper.comSuccess(res,_data);
           })
           .catch(err =>{
               helper.comError(res,err);
           })
   }
});
/**
 * 根据竞得企业名字查询列表结果页
 * @param page
 * @param pageSize
 * @param keyword
 * @returns {*}
 */

router.post('/searchList',(req,res) =>{
   if(!req.body.keyword){
       helper.comSuccess(res,[]);
   } else {
       LandService.getSearchByCompanty(req.body)
           .then(_data =>{
               helper.comSuccess(res,_data);
           })
           .catch(err =>{
               helper.comError(res,err);
           })
   }
});
/**
 * 根据竞得企业ID查询列表结果页
 * @param ID
 * @returns {*}
 */

router.post('/listById',(req,res) =>{
    if(!req.body.ID){
        helper.comSuccess(res,[]);
    } else {
        LandService.getSearchByID(req.body)
            .then(_data =>{
                helper.comSuccess(res,_data);
            })
            .catch(err =>{
                helper.comError(res,err);
            })
    }
});

export default router;