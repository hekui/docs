import express from 'express';
import { marketingService } from '../../service';
import helper from '../helper';

const router = express.Router();

/**
 * 获取营销案例列表
 * @param {可选string('xxxx-(x)x')} req.body.date
 */
router.post('/getList', (req, res) => {
    marketingService.getList(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
});

export default router;