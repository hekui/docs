import express from 'express';
import exponent from './exponent';
import bbs from './bbs';
import user from './user';
import article from './article';
import houses from './houses';
import home from './home';
import order from './order';
import report from './report';
import comments from './comments'
import messages from './messages'
import advert from './advert'
import logger from '../logger'
import sys from './sys'

const router = express.Router();
router.use('/exponent', exponent);
router.use('/bbs', bbs);
router.use('/user', user);
router.use('/article', article);
router.use('/houses', houses);
router.use('/home', home);
router.use('/order', order);
router.use('/report', report);
router.use('/comments', comments);
router.use('/messages', messages);
router.use('/advert', advert);
router.use('/sys', sys)

// 写日志
router.post('/logs', (req, res) => {
  logger({
    api: req.body.api,
    desc: JSON.stringify(req.body.desc)
  }).then(result => {
    res.json({
      code: 200,
      data: {},
      msg: '记录成功。'
    })
  })
})

export default router;