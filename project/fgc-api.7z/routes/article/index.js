import express from 'express';
import { articleService, collectionService, orderService, articleDraftService, reportService } from '../../service';
import helper from '../helper';

const router = express.Router(); 

/**
 * 获取文章分类列表
 */
router.post('/getTypes', (req, res) => {
    articleService.getTypes(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
})

// 获取文章标签
router.post('/getTags', (req, res) => {
    articleService.getTags(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
})

// 获取文章来源
router.post('/getSources', (req, res) => {
    articleService.getSources(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
})

// 获取数据支持
router.post('/getSupports', (req, res) => {
    articleService.getSupports(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
})

// 获取声明
router.post('/getStatements', (req, res) => {
    articleService.getStatements(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
})

/**
 * 根据typeID获取文章列表(参数：typeID)
 */
router.post('/getList', (req, res) => {
    articleService.getList(req.body)
        .then(_data => {
            _data.list.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic;
                return item
            })
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });   
})

/**
 * 获取热门文章列表（分页）
 */
router.post('/getHotList', (req, res) => {
    articleService.getHotList(req.body)
        .then(_data => {
            _data.list.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic;
                return item
            })
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });  
})

/**
 * 更新文章浏览量(id：文章id)
 */
router.post('/addPvNum', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {
        articleService.setPvNum(req.body.id)
        .then(msg => {
            helper.comSuccess(res, null, msg);
        }).catch(err => {
            helper.comError(res, err);
        });
    } 
})

/**
 * 根据文章id获取文章详情及推荐文章列表
 */
router.post('/getDetails', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'})
    } else {
        articleService.getDetails(req.body.id)
        .then(_data => {
            articleService.setPvNum(req.body.id);
            if(req.body.u_id){
                orderService.getRewardTimes(req.body).then(_res => {
                    _data.rewardTimes = _res
                    helper.comSuccess(res, _data);
                }).catch(err => {
                    _data.rewardTimes = -1
                    helper.comSuccess(res, _data);
                });
            }else{
                _data.rewardTimes = 0
                helper.comSuccess(res, _data);
            }
        }).catch(err => {
            helper.comError(res, err);
        });
    } 
})

/**
 * 获得文章打赏信息（打赏次数和金额）
 */
router.post('/rewardedInfo', (req, res) => {
    if (!req.body.a_id) {
        helper.comError(res, {message: 'a_id can not be empty.'})
    } else {
        articleService.getTimesAndMoney(req.body.a_id)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
    } 
})

/**
 * 查询文章是否收藏过
 */
router.post('/isCollected', (req, res) => {
    if (!req.body.plate_id) {
        helper.comError(res, {message: 'plate_id can not be empty.'})
    } else {
        collectionService.exists(req.body)
        .then(_data => {
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        });
    } 
})

/**
 * 收藏文章(必填字段:'plate_id', 'u_id')
 */
router.post('/collect', (req, res) => {
    collectionService.add(req.body, 'Article')
        .then(async () => {
            let count = await collectionService.count(req.body.plate_id, 'Article');
            articleService.setCollectionNum(req.body.plate_id, count);
            helper.comSuccess(res, null, '收藏成功');
        }).catch(err => {
            helper.comError(res, err);
        });
})

/**
 * 取消文章收藏
 */
router.post('/uncollect', (req, res) => {
    if (!req.body.plate_id || !req.body.u_id) {
        helper.comError(res, {message: 'plate_id and u_id can not be empty.'})
    } else {
        collectionService.delete(req.body)
        .then(async () => {
            let count = await collectionService.count(req.body.plate_id, 'Article');
            articleService.setCollectionNum(req.body.plate_id, count);
            helper.comSuccess(res, null, '取消收藏');
        }).catch(err => {
            helper.comError(res, err);
        });
    } 
});

/**
 * 根据关键字搜索文章标题列表
 */
router.post('/search', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, []);
    } else {
        articleService.search(req.body)
        .then(_data => {                
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    } 
});

/**
 * 根据关键字搜索话题结果列表(分页)
 */
router.post('/searchResult', (req, res) => {
    if (!req.body.keyword) {
        helper.comSuccess(res, {});
    } else {
        articleService.searchPaging(req.body)
        .then(_data => {        
            // console.log('_data', _data);
            _data.list.map(item => {
                item.pv_num += item.pv_num_basic
                delete item.pv_num_basic
                return item
            })
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    } 
});

/**
 * 根据楼盘id搜索单个楼盘
 */
router.post('/searchSingle', (req, res) => {
    if (!req.body.id) {
        helper.comError(res, {message: 'id can not be empty.'});
    } else {
        articleService.searchArticleByID(req.body.id)
        .then(_data => {
            _data.pv_num += _data.pv_num_basic
            delete _data.pv_num_basic
            helper.comSuccess(res, _data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

/**
 * 创建支付订单（必填字段：'plate_id', 'u_id', 'money';可选字段：'desc'描述信息250个字符, 'type': 默认1表示打赏）
 */
router.post('/addOrder', (req, res) => {
    orderService.addOrder(req.body, 'Article')
        .then(_data => {
            helper.comSuccess(res, _data, '创建订单成功');
        }).catch(err => {
            helper.comError(res, err);
        })
});

/**
 * 更新支付订单状态（1成功，2失败）
 * 参数(id: 订单id, status: 支付状态)
 */
router.post('/setOrderStatus', (req, res) => {
    if (!req.body.id || !req.body.status || !req.body.money) {
        helper.comError(res, {message: 'id, status, money can not be empty.'});
    } else {
        articleService.setOrderStatus(req.body)
        .then(_status => {
          if (_status == 1) {
            reportService.addPayNum(req.body.id);
          }
            helper.comSuccess(res, null, orderService.getOrderMsg(_status));
        }).catch(err => {
            helper.comError(res, err);
        })
    }
});

/** =================草稿================  */

// 发布草稿
router.post('/publishDraft', (req, res) => {
    if (!req.body.draftID || !req.body.wx_openid) {
        helper.comError(res, {message: 'draftID or wx_openid can not be empty.'});
    } else {
        articleDraftService.publish(req.body)
        .then(data => {
            helper.comSuccess(res, data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }    
})

// 获取草稿详情 (参数：id, wx_openid)
router.post('/getDraft', (req, res) => {
    if (!req.body.id || !req.body.wx_openid) {
        helper.comError(res, {message: 'id or wx_openid can not be empty.'});
    } else {
        articleDraftService.getDetails(req.body)
        .then(data => {
            helper.comSuccess(res, data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

// 判断草稿是否可以编辑 (参数：id, wx_openid)
router.post('/canEditDraft', (req, res) => {
    if (!req.body.id || !req.body.wx_openid) {
        helper.comError(res, {message: 'id or wx_openid can not be empty.'});
    } else {
        articleDraftService.canEdit(req.body)
        .then(data => {
            helper.comSuccess(res, data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

// 设置草稿状态 (参数：id, status: 1正常，2编辑中)
router.post('/setDraftStatus', (req, res) => {
    if (!req.body.id || !req.body.status || !req.body.wx_openid) {
        helper.comError(res, {message: 'id or status or wx_openid can not be empty.'});
    } else {
        articleDraftService.setStatus(req.body)
        .then(data => {
            helper.comSuccess(res, data);
        }).catch(err => {
            helper.comError(res, err);
        })
    }
})

export default router;