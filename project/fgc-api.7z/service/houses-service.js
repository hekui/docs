import Sequelize from 'sequelize';
import { HousesBasic, Dict, EvaluationResult, HousesDetails, HOusesPrice, HousesMarket } from '../model';

class HousesService {
    /**
     * 获取区域列表
     */
    getRegions({city_code}) {
        return Dict.findAll({
            attributes: ['id', 'name'],
            where: {
                city_code,
                type: 300,
                status: 1,
                level: 1
            },
            include: [{
                model: Dict,
                as: 'children',
                attributes: ['id', 'name']
            }]
        })
    }

    /**
     * 返回预警情况列表
     * 1.推荐购买：80-100分
     * 2.谨慎购买：60-79分
     * 3.风险预警：0-59分
     */
    getWarns() {
        return [
            { id: 1, name: '推荐购买', range: [80, 100] },
            { id: 2, name: '谨慎购买', range: [60, 79] },
            { id: 3, name: '风险预警', range: [0, 59]}
        ];
    }

    /**
     * 根据得分返回相应的预警情况
     * @param {Number} score
     */
    getWarnByScore(score) {
        if (score <= 59) {
            return '风险预警';
        } else if (score > 59 && score <= 79) {
            return '谨慎购买';
        }
        return '推荐购买';
    }

    /**
     * 获取基本的楼盘列表筛选条件
     */
    getBaseOption() {
        return {
            attributes: ['id', 'name', 'list_cover', 'region', [Sequelize.col('result.score'), 'score'], [Sequelize.literal('CONCAT_WS("-", `secondRegion.parent`.`name` , `secondRegion`.name)'), 'regionName']],            
            include: [{
                model: EvaluationResult,
                as: 'result',
                attributes: []
            }, {
                model: Dict,
                as: 'secondRegion',
                attributes: [],
                include: [{
                    model: Dict,
                    as: 'parent',
                    attributes: []
                }]
            }]
        }
    }
    
    /**
     * 根据条件筛选评测列表(scoreOrder: 1升序，2降序)
     */
    getList({city_code, page, pageSize, regionId, orientationId, warnRnage, scoreOrder}) {
        let conditions = {city_code, status: 1, is_off: 1},
            order = [
                ['sort_order', 'DESC'],
                ['created_at', 'DESC']
            ];

        regionId && (conditions.region = regionId);
        orientationId && (conditions.orientation = orientationId);
        if (warnRnage) {
            conditions.$and = [Sequelize.where(Sequelize.col('result.score'), {between: warnRnage})]
        }
        if (scoreOrder) {
            order.unshift([Sequelize.col('result.score'), (scoreOrder == 1 ? 'ASC' : 'DESC')])
        }

        let options = this.getBaseOption();
        options.where = conditions;
        options.order = order;

        return HousesBasic.pagingQuery(page, pageSize, options).then(result => {
            if (Array.isArray(result.list)) {
                result.list.forEach((item, i, a) => {
                    a[i] = item.get({plain: true}); 
                    a[i].warnMsg = this.getWarnByScore(a[i].score);
                })
            }
            return result;
        })
    }

    /**
     * 根据关键字搜索楼盘名
     * @param {String} keyword
     */
    search({city_code, keyword}) {
        return HousesBasic.findAll({
            attributes: ['id', 'name'],
            where: {
                city_code,
                status: 1,
                is_off: 1,
                name: {$like: '%' + keyword + '%'}
            }
        })
    }

    /**
     * 根据关键字搜索楼盘结果(分页)
     */
    searchPaging({city_code, page, pageSize, keyword}) {
        let options = this.getBaseOption();

        return HousesBasic.pagingQuery(page, pageSize, Object.assign(options, {
            where: {
                city_code,
                status: 1, 
                is_off: 1,
                name: {$like: '%' + keyword + '%'}
            },
            order: [ 
                ['sort_order', 'DESC'],
                ['created_at', 'DESC']
            ]
        })).then(result => {
            if (Array.isArray(result.list)) {
                result.list.forEach((item, i, a) => {
                    a[i] = item.get({plain: true}); 
                    a[i].warnMsg = this.getWarnByScore(a[i].score);
                })
            }
            return result;
        })
    }

    /**
     * 根据关键字获取两个楼盘信息
     */
    searchForHome({city_code, keyword}) {
        let options = this.getBaseOption();

        return HousesBasic.findAll(Object.assign(options, {
            where: {
                city_code,
                status: 1, 
                is_off: 1,
                name: {$like: '%' + keyword + '%'}
            },
            order: [ 
                ['sort_order', 'DESC'],
                ['created_at', 'DESC']
            ],
            limit: 3
        })).then(result => {
            if (Array.isArray(result)) {
                result.forEach((item, i, a) => {
                    a[i] = item.get({plain: true}); 
                    a[i].warnMsg = this.getWarnByScore(a[i].score);
                })
            }
            return result;
        })
    }

    /**
     * 根据楼盘ID搜索楼盘
     * @param {Number} ID
     */
    searchHouseByID(ID) {
        return HousesBasic.findOne({
            attributes: ['id', 'name', 'list_cover', 'region', [Sequelize.col('result.score'), 'score'], [Sequelize.literal('CONCAT_WS("-", `secondRegion.parent`.`name` , `secondRegion`.name)'), 'regionName']],
            where: {status: 1, is_off: 1, id: ID},
            include: [{
                model: EvaluationResult,
                as: 'result',
                attributes: []
            }, {
                model: Dict,
                as: 'secondRegion',
                attributes: [],
                include: [{
                    model: Dict,
                    as: 'parent',
                    attributes: []
                }]
            }]
        }).then(data => {
            if (data) {
                data = data.get({plain: true});
                data.warnMsg = this.getWarnByScore(data.score);
            }
            return data;
        })
    }

    /**
     * 获取楼盘的最新价格
     * @param {Number} h_id
     */
    getNewPrice(h_id) {
        return HOusesPrice.findAll({
            attributes: ['price'],
            where: {
                h_id: h_id
            },
            order: 'price_at DESC',
            limit: 1
        }).then(data => {
            let result = (data[0] && data[0].get({plain: true})) || {};
            return result.price || '';
        })
    }

    /**
     * 根据楼盘ID获取楼盘指数详情
     * @param {Number} ID
     */
    getHouseDetailById(ID) {
        return HousesBasic.findOne({
            attributes: ['id', 'name', 'list_cover', 'developer', 'developer_id', 'region', 'orientation', 'address', [Sequelize.col('detail.opening_times'), 'opening_times'], 
                [Sequelize.col('detail.opening_timed'), 'opening_timed'], [Sequelize.col('detail.sub_time'), 'sub_time'], [Sequelize.col('detail.sys_dict.name'), 'decorate'],
                [Sequelize.col('detail.ratio_plot'), 'ratio_plot'], [Sequelize.col('detail.ratio_afforest'), 'ratio_afforest'],[Sequelize.col('result.score'), 'score'],
                [Sequelize.col('result.score_company'), 'score_company'], [Sequelize.col('result.score_product'), 'score_product'], [Sequelize.col('result.score_property'), 'score_property'],
                [Sequelize.col('result.score_reputation'), 'score_reputation'], [Sequelize.col('result.summary'), 'summary'], [Sequelize.literal('CONCAT_WS("-", `secondRegion.parent`.`name` , `secondRegion`.name)'), 'regionName'],
                [Sequelize.col('detail.decorate_standard'), 'decorate_standard']                    
            ],
            where: {
                status: 1,
                is_off: 1,
                id: ID
            },
            include: [{
                model: HousesDetails,
                attributes: [],
                as: 'detail',
                include: [{
                    model: Dict,
                    attributes: []
                }]
            }, {
                model: EvaluationResult,
                as: 'result',
                attributes: []
            }, {
                model: Dict,
                as: 'secondRegion',
                attributes: [],
                include: [{
                    model: Dict,
                    as: 'parent',
                    attributes: []
                }]
            }]
        }).then(async data => {
            if (data) {
                data = data.get({plain: true});
                data.warnMsg = this.getWarnByScore(data.score);
                data.price = await this.getNewPrice(ID);
            }
            return data;
        })
    }

    /**
     * 获取价格走势的时间区间
     */
    getDateRange() {
        let date = new Date(), year = date.getFullYear(), month = date.getMonth();
        let start = {
            year: month + 1 > 11 ? year : year - 1,
            month: month + 1 > 11 ? 0 : month + 1 
        }
        return [new Date(start.year, start.month, 1).getTime() / 1000, new Date(year, month, 1).getTime() / 1000];
    }

    /**
     * 获取楼盘价格走势
     * @param {Number} h_id
     * @param {Array} dateRange
     */
    getHousePrices(h_id, dateRange) {
        return HOusesPrice.findAll({
            attributes: ['price', 'price_at'],
            where: {
                h_id: h_id,
                price_at: {$between: dateRange}
            },
            order: 'price_at ASC'
        })
    }

    /**
     * 获取区域价格走势图
     * @param {String} name
     * @param {Array} dateRange
     */
    getRegionPrices(city_code, name, dateRange) {
        return HousesMarket.findAll({
            attributes: ['marke_price', 'market_date'],
            where: {
                city_code,
                region_name: name,
                market_date: {$between: dateRange},
                is_off: 1,
                status: 1
            },
            order: 'market_date ASC'
        })
    }

    /**
     * 获取楼盘和区域的价格走势图
     */
    getAllPrices({city_code, h_id, name}) {
        let dateRange = this.getDateRange();
        return Promise.all([
            this.getHousePrices(h_id, dateRange),
            this.getRegionPrices(city_code, name, dateRange)
        ])
    }

    /**
     * 随机获取8个楼盘
     */
    async getRandomList({city_code}) {
        let limit = 8, 
            conditions = {city_code, status: 1, is_off: 1, is_home: 1};
            
        let count = await HousesBasic.count({where: conditions}),
            offset = Math.floor(Math.random() * (count - limit));

        offset = offset < 0 ? 0 : offset;

        let options = this.getBaseOption();
        options.where = conditions;
        options.offset = offset;
        options.limit = limit;

        return HousesBasic.findAll(options).then(result => {
            if (Array.isArray(result)) {
                result.forEach((item, i, a) => {
                    a[i] = item.get({plain: true}); 
                    a[i].warnMsg = this.getWarnByScore(a[i].score);
                })
            }
            return result;
        })
    }

}

export default new HousesService();