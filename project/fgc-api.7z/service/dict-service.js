import { Dict } from '../model';

class DictService {
    /**
     * 根据type值获取相关数据字典
     * @param {number} type 
     */
    getDictByType(city_code, type) {
        return Dict.findPlainAll({
            attributes: ['id', 'name'],
            where: {
                city_code,
                type: type,
                status: 1
            }
        })
    }
}

export default new DictService();