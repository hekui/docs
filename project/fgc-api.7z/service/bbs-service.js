import { BBSPost } from '../model';
import { getUniqueId } from './utils/sequence';
import followService from './user-follow-service';
import UserSearvice from './user-service';
let fields = ['title', 'content', 'u_id'];

class BBSService {
    /**
     * 获取话题列表
     */
    getList({city_code, page, pageSize }) {
        return BBSPost.pagingQuery(page, pageSize, {
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'title', 'content', 'created_at', 'comment_num'],
            order: 'created_at DESC',
            where: { city_code, status: 1 }
        });
    }

    /**
     * 根据id获取话题
     * @param {*} id 
     */
    getPostByID(id, u_id) {
        return BBSPost.findOne({
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'title', 'content', 'created_at', 'comment_num'],
            where: { status: 1, id: id }
        }).then(data => {
            if (data) {
                data = data.get({plain: true});
                return followService.exists({
                    plate_id: data.id,
                    u_id: u_id
                }).then(isFollow => {
                    data.isFollow = isFollow;
                    return data;
                })
            }
        })
    }

    /**
     * 修改评论数和回复时间
     * @param {Number} id 
     * @param {Number} count 
     */
    setCommentNum(id, count) {
        return BBSPost.update({
            comment_num: count,
            back_at: new Date()
        }, {
            where: {
                id: id
            }
        }).then(data => {
            if (data[0] == 1) {
                return {message: '修改评论数和回复时间成功'};
            } else {
                throw {message: '修改评论数和回复时间失败'}
            }
        })
    }

    /**
     * 添加话题
     * @param {Object} model 
     */
    addTopic(model) {
        return BBSPost.checkModel(model, fields)
            .then(() => {
                return UserSearvice.canBack(model.u_id)
                    .then(async () => {                            
                        model.id = await getUniqueId();
                        return BBSPost.create(model);
                    })
            })
    }

    /**
     * 根据关份键字搜索匹配的话题标题
     * @param {String} keyword 
     */
    search({city_code, keyword}) {
        return BBSPost.findAll({
            attributes: ['id', 'title'],
            where: {
                city_code,
                status: 1,
                title: {$like: '%' + keyword + '%'}
            }
        })
    }

    /**
     * 根据关键字搜索匹配的话题标题(分页)
     * @param {*} param0 
     */
    searchPaging({city_code, page, pageSize, keyword}) {
        return BBSPost.pagingQuery(page, pageSize, {
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'title', 'content', 'created_at', 'comment_num'],
            order: 'created_at DESC',
            where: { 
                city_code,
                status: 1,
                title: {$like: '%' + keyword + '%'}
            }
        });
    }

    /**
     * 根据关键字搜索两个话题
     */
    searchForHome({city_code, keyword}) {
        return BBSPost.findAll({
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'title', 'content', 'created_at', 'comment_num'],
            order: [
                ['created_at', 'DESC'],
                ['comment_num', 'DESC']
            ],
            where: { 
                city_code,
                status: 1,
                $or: [{
                    title: {$like: '%' + keyword + '%'}
                }, {
                    content: {$like: '%' + keyword + '%'}
                }]                
            },
            limit: 3
        });
    }
    
}

export default new BBSService();