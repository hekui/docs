import Sequelize from 'sequelize';
import { BBSPostBack, UserLike ,BBSPost} from '../model';
import { getUniqueId } from './utils/sequence';
import UserSearvice from './user-service';
let fields = ['post_id', 'content', 'u_id', 'tou_id'];
let backFields = ['post_id', 'content', 'u_id', 'to_id', 'tou_id'];

class BBSBackService {
    /**
     * 根据postID获取评论信息和最新回复
     * @param {*} param0 
     */
    getCommentsByID({ page, pageSize, postID, u_id }) {
        return BBSPostBack.pagingQuery(page, pageSize, {
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'content', 'created_at', 'back_num', 'hot_num', [Sequelize.col('user_like.id'), 'likeID']],
            where: {
                status: 1,
                post_id: postID,
                to_id: 0
            },
            order: [
                ['hot_num', 'DESC'],
                ['created_at', 'DESC']
            ],                
            include: [{
                model: BBSPostBack,
                as: 'reply',
                attributes: ['u_id', 'u_name', 'content', 'created_at'],
                duplicating: false,
                on: {
                    $and: {
                        to_id: { $eq: Sequelize.col('bbs_post_back.id') },
                        id: {$eq: Sequelize.col('bbs_post_back.new_id')},
                        status: {$eq: 1}
                        // 子查询
                        // id: {
                        //     $eq: Sequelize.literal('(SELECT `b1`.`id` FROM `bbs_post_back` `b1` LEFT JOIN `bbs_post_back` `b2` ON `b1`.`to_id` = `b2`.`id` ORDER BY `b1`.`created_at` DESC LIMIT 1 )')
                        // }
                    }
                }
            }, {
                model: UserLike,
                attributes: [],
                on: {
                    plate: {$eq: 'BbsPostBack'},
                    plate_id: {$eq: Sequelize.col('bbs_post_back.id')},
                    u_id: {$eq: u_id}
                }
            }]
        })
    }

    /**
     * 修改点赞数
     * @param {Number} id 
     * @param {Number} count 
     */
    setLikeNum(id, count) {
        return BBSPostBack.update({
            hot_num: count
        }, {
            where: {
                id: id
            }
        }).then(data => {
            if (data[0] == 1) {
                return {message: '修改点赞数成功'};
            } else {
                throw {message: '修改点赞数失败'}
            }
        })
    }

    /**
     * 增加话题评论
     * @param {Object} model 
     */
    addComment(model) {
        return BBSPostBack.checkModel(model, fields)
            .then(() => {
                return UserSearvice.canBack(model.u_id)
                    .then(async () => {
                        model.id = await getUniqueId();
                        return BBSPostBack.create(model);
                    })                    
            })
    }

    /**
     * 统计话题评论数
     * @param {Number} post_id 
     */
    count(post_id) {
        return BBSPostBack.count({
            where: {
                post_id: post_id,
                to_id: 0,
                status: 1
            }
        })
    }

    /**
     * 根据评论id获取评论信息
     * @param {Number} ID 
     */
    getComment(ID) {
        return BBSPostBack.findOne({
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'content', 'created_at', 'back_num', 'hot_num'],
            where: {
                status: 1,
                id: ID
            }
        })
    }

    /**
     * 根据评论ID获取回复列表
     * @param {Number} commentID 
     */
    getBackList({page, pageSize, commentID, u_id}) {
        return BBSPostBack.pagingQuery(page, pageSize, {
            attributes: ['id', 'u_id', 'u_name', 'u_avator', 'content', 'created_at', 'hot_num', [Sequelize.col('user_like.id'), 'likeID']],
            where: {
                status: 1,
                to_id: commentID
            },
            order: 'created_at DESC',
            include: [{
                model: UserLike,
                attributes: [],
                on: {
                    plate: {$eq: 'BbsPostBack'},
                    plate_id: {$eq: Sequelize.col('bbs_post_back.id')},
                    u_id: {$eq: u_id}
                }
            }]
        })
    }

    /**
     * 增加回复
     * @param {Object} model 
     */
    addBack(model) {
        return BBSPostBack.checkModel(model, backFields)
            .then(() => {
                return UserSearvice.canBack(model.u_id)
                    .then(async () => {
                        model.id = await getUniqueId();
                        return BBSPostBack.create(model)
                            .then(() => {
                                return model.id;
                            })
                    })
                
            })
    }

    /**
     * 更新最新回复id和回复数
     * @param {Number} commentID 
     * @param {Number} new_id 
     */
    editCommentInfo(commentID, new_id, count) {
        return BBSPostBack.update({
            new_id: new_id,
            back_num: count
        }, {
            where: {
                id: commentID
            }
        }).then(data => {
            if (data[0] == 1) {
                return {message: '更新最新回复成功'};
            } else {
                throw {message: '更新最新回复失败'}
            }
        })
    }

    /**
     * 统计评论的回复数
     * @param {Number} commentID 
     */
    countBack(commentID) {
        return BBSPostBack.count({
            where: {
                to_id: commentID,
                status: 1
            }
        })
    }

    /**
     * 统计用户的评论数和回复数
     * @param {Number} id
     */
    countCommentBackNum(id) {
        // return BBSPostBack.count({
        //     where: {
        //         tou_id: u_id,
        //         status: 1,
        //         u_id:{$not:u_id},
        //         $and: [
        //             Sequelize.where(Sequelize.col('bbs_post.status'), '=', 1),
        //         ]
        //     },
        //     include:[{
        //         model:BBSPost,
        //         attributes:[]
        //     },{
        //         model: BBSPostBack,
        //         as: 'comment',
        //         attributes: [],
        //     }]
        //
        // })
        return BBSPostBack.count({
            where:{
                tou_id:id,
                status:1,
                u_id:{$not:id},
                $or:[
                    {
                        to_id: {$not: 0},
                        $and: [
                            Sequelize.where(Sequelize.col('comment.status'), '=', 1)
                        ]
                    },
                    {
                        to_id: 0,
                        $and: [
                            Sequelize.where(Sequelize.col('bbs_post.status'), '=', 1)
                        ]
                    }
                ]

            },
            include: [{
                model: BBSPostBack,
                as: 'comment',
                attributes: [],
                duplicating: false,

            },{
                model:BBSPost,
                attributes:[],
                on: {
                    id: {$eq: Sequelize.col('bbs_post_back.post_id')},
                    $and: [
                        Sequelize.where(Sequelize.col('bbs_post_back.to_id'), '=', 0)
                    ]
                },
            },{
                model:BBSPost,
                as: 'bbs',
                attributes:[],
                where: {
                    status: 1
                }
            }]
        })
    }
    
}

export default new BBSBackService();