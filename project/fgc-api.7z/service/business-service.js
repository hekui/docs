import Sequelize from 'sequelize';
import { PlateBusiness, BusinessDynamic, Dict } from '../model';
import helper from './helper';

class BusinessService {
    /**
     * 根据typeId获取商业项目动态
     * @param {Object} param0 
     */
    getDynamicByType({page, pageSize, typeId}) {
        return BusinessDynamic.pagingQuery(page, pageSize, {
            attributes: ['id', 'plate_business_id', 'rel_date', 'dynamic_content'],
            where: {
                status: 1,
                is_offline: 1,
                '$and': [                    
                    Sequelize.where(Sequelize.col('plate_business.status'), '=', 1),
                    Sequelize.where(Sequelize.col('plate_business.is_offline'), '=', 1),
                    Sequelize.where(Sequelize.col('plate_business.sys_dict.id'), '=', typeId)
                ]
            },
            order: [
                ['rel_date', 'DESC'],
                ['pubdate', 'DESC']
            ],
            include: [{
                model: PlateBusiness,
                attributes: [],
                duplicating: false,
                include: [{
                    model: Dict,
                    attributes: [],
                    duplicating: false
                }]
            }]
        })
    }

    getPagingBase() {
        return {
            attributes: ['id', 'name', 'list_cover', 'developers', 'opening_date', 'section'],
            where: {
                status: 1,
                is_offline: 1
            },
            order: [
                ['sort_order', 'DESC'],
                ['pubdate', 'DESC']
            ]
        }
    }

    /**
     * 根据typeId获取商业项目列表
     * @param {Object} param0 
     */
    getBusinessByType({page, pageSize, typeId}) {
        let options = this.getPagingBase();
        options.where.$and = [Sequelize.where(Sequelize.col('sys_dict.id'), '=', typeId)];
        options.include = [{
            model: Dict,
            attributes: [],
            duplicating: false
        }];

        return PlateBusiness.pagingQuery(page, pageSize, options);
    }

    /**
     * 根据商业项目ID获取商业项目详情
     * @param {number} id 
     */
    getDetailsById(id) {
        let excludeAttrs = helper.getExcludeAttrs();
        excludeAttrs.push('type', 'list_cover', 'plate', 'sort_order', 'developers_company_id', 'property_company_id');
        return PlateBusiness.findOne({
            attributes: {
                include: [[Sequelize.col('sys_dict.name'), 'type']],
                exclude: excludeAttrs
            },
            where:{
                id: id
            },                       
            order: [
                [Sequelize.col('dynamics.rel_date'), 'DESC'],
                [Sequelize.col('dynamics.pubdate'), 'DESC']
            ],
            include: [{
                model: BusinessDynamic,
                as: 'dynamics',
                attributes: ['id', 'rel_date', 'dynamic_content', 'rel_link'],
                on: {
                    plate_business_id: {$eq: Sequelize.col('plate_business.id')},
                    status: {$eq: 1},
                    is_offline: {$eq: 1}
                }
            }, {
                model: Dict,
                attributes: [],
                duplicating: false
            }]
        });
    }

     /**
     * 根据关键字查询商业项目
     * @param {String} keyword
     */
    search(keyword) {
        return PlateBusiness.findAll({
            attributes: ['id', 'name'],
            where: {
                status: 1, 
                is_offline: 1,
                name: {$like: '%' + keyword + '%'}
            }
        })
    }

    /**
     * 根据关键字查询商业项目(分页)
     * @param {*} param0 
     */
    searchPaging({page, pageSize, keyword}) {
        let options = this.getPagingBase();
        options.where.name = {$like: '%' + keyword + '%'};

        return PlateBusiness.pagingQuery(page, pageSize, options);
    }

    /**
     * 根据ID获取商业项目信息
     * @param {*} ID 
     */
    getBusinessByID(ID) {
        return PlateBusiness.findOne({
            attributes: ['id', 'name', 'list_cover', 'developers', 'opening_date', 'section'],
            where: {
                id: ID,
                status: 1,
                is_offline: 1
            }
        });
    }
}

export default new BusinessService();