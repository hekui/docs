import Sequelize from 'sequelize';
import { ArticleDraft, BackendAccount, URule } from '../model';
import articleService from './article-service';

class ArticleDraftService {
    /**
     * 获取文章草稿详情
     * @param {Number} id 
     */
    getDetails({ id, wx_openid }) {
        return this.judgePermission(wx_openid).then(() => {
            return ArticleDraft.findOne({
                attributes: ['id', 'title', 'img_path', 'generate_at'],
                where: {
                    id: id,
                    $and: [
                        Sequelize.literal(`HOUR(timediff(now(), generate_at)) < 24`)
                    ]
                }
            }).then(data => {
                if (data) {
                    return data;
                } else {
                    throw new Error('文章链接已失效');
                }
            })
        })
    }

    /**
     * 判断用户能否编辑发布草稿
     * @param {String} wx_openid 
     */
    judgePermission(wx_openid) {
        return BackendAccount.findOne({
            attributes: ['id'],
            include: [{
                model: URule,
                attributes: []
            }],
            where: {
                wx_openid: wx_openid,
                $and: [
                    Sequelize.where(Sequelize.col('u_rule.state'), '=', 0)
                ]
            }
        }).then(data => {
            if (!data) {
                throw new Error('没有权限')
            } else {
                data = data.get({ plain: true });
                return (data && data.id) || null; 
            }
        })
    }

    // 判断草稿是否在编辑状态
    canEdit({ id, wx_openid }) {
        return this.judgePermission(wx_openid).then(() => {
            return ArticleDraft.findById(id, {
                attributes: ['status', 'generate_at', 'wx_openid']
            }).then(data => {
                if (data) {
                    data = data.get({ plain: true });
                    if (data.generate_at == '0000-00-00 00:00:00' || (Date.now() - new Date(data.generate_at) > 24 * 60 * 60 * 1000)) {
                        throw new Error('文章链接已失效')
                    } else if (data.status == 2 && wx_openid != data.wx_openid) {
                        throw new Error('文章正在编辑中');
                    }
                    return true;
                } else {
                    throw new Error('文章链接已失效');
                }
            })
        })
    }

    // 设置草稿状态
    setStatus({ id, status, wx_openid }) {
        return ArticleDraft.update({
            status: status,
            wx_openid: wx_openid
        }, {
                where: {
                    id: id
                }
            })
    }

    // 删除草稿
    deleteDraft(id) {
        return ArticleDraft.destroy({
            where: {
                id: id
            }
        })
    }

    // 发布草稿
    publish(body) {
        return this.judgePermission(body.wx_openid).then(userID => {            
            body.creater = userID;
            return ArticleDraft.findById(body.draftID)
        }).then(async data => {
            if (data) {
                return articleService.addArticle(body).then(result => {
                    this.deleteDraft(body.draftID);
                    return result;
                });
            } else {
                throw new Error('文章链接已失效');
            }
        })
    }

}

export default new ArticleDraftService();