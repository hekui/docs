import { UserFollow,BBSPost } from '../model';
import { getUniqueId } from './utils/sequence';
import Sequelize from 'sequelize';
let fields = ['plate_id', 'u_id'];

class FollowService {
    /**
     * 添加关注
     * @param {Object} model 
     * @param {String} plate 
     */
    add(model, plate) {
        return UserFollow.checkModel(model, fields)
            .then(async () => {
                model.id = await getUniqueId();
                model.plate = plate;
                return UserFollow.create(model);
            });
    }
    
    /**
     * 判断用户是否已经关注过该板块
     * @param {Number} plateID 
     * @param {Number} uID 
     */
    exists({plate_id, u_id}) {
        return UserFollow.findOne({
            where: {
                plate_id: plate_id,
                u_id: u_id
            }
        }).then(_data => {
            if (_data) {
                return true;
            }
            return false;
        })
    }

    /**
     * 取消关注
     * @param {Number} id 
     */
    delete({plate_id, u_id}) {
        return UserFollow.destroy({
            where: {
                plate_id: plate_id,
                u_id: u_id
            }
        }).then(data => {
            if (data == 1) {
                return true;
            } else {
                throw {message: '取消关注失败'}
            }
        });
    }

    /**
     * 获取用户关注列表
     * @param page
     * @param pageSize
     * @param u_id
     * @returns {*}
     */
    getList({page, pageSize, id}){
        return BBSPost.pagingQuery(page,pageSize,{
            attributes:["id","title","tags","content","u_id",["comment_num", "back_num"],"created_at"],
            where:{status:1,
                $and: [
                    Sequelize.where(Sequelize.col('user_follows.u_id'), '=', id)
                ]},
            order:[
                ["created_at","DESC"],
                ["updated_at","DESC"]
            ],
            include:[{
                model:UserFollow,
                attributes:[],
                duplicating: false
            }]
        })
    }
}

export default new FollowService();