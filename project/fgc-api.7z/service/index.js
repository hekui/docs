import dictService from './dict-service';
import companyService from './company-service';
import LandService from "./land-service";
import businessService from './business-service';
import estaterService from './estater-service';
import districtService from './district-service';
import marketingService from './marketing-service';
import policyService from './policy-service';
import bbsService from './bbs-service';
import bbsBackService from './bbs-back-service';
import UserService from "./user-service";
import followService from './user-follow-service';
import likeService from './user-like-service';
import collectionService from "./user-collection-service";
import articleService from './article-service';
import housesService from './houses-service';
import CommentService from "./user-comment-service";
import EvaluatingService from './houses-evaluating-service';
import bbsReadService from './bbs-read-service';
import housesCommentService from './houses-comment-service';
import homeService from './home-service';
import orderService from './order-service';
import reportService from './report-service';
import articleDraftService from './article-draft-service';
import commentsService from './comments-service';
import advertService from './advert';
import UserAvatar from './user-avatar'
import SysService from './sys-service'

export {
    dictService,
    companyService,
    LandService,
    businessService,
    estaterService,
    districtService,
    marketingService,
    policyService,
    bbsService,
    followService,
    likeService,
    UserService,
    bbsBackService,
    collectionService,
    articleService,
    housesService,
    CommentService,
    EvaluatingService,
    bbsReadService,
    housesCommentService,
    homeService,
    orderService,
    reportService,
    articleDraftService,
    commentsService,
    advertService,
    UserAvatar,
    SysService,
}