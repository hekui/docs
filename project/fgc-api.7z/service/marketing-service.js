import Sequelize from 'sequelize';
import { PlateMarketing } from '../model';
import helper from './helper';

class MarketingService {
    /**
     * 获取营销案例列表
     * @param {Object} param0 
     * @param.date {string('xxxx-(x)x')}
     */
    getList({page, pageSize, date}) {
        let dateRange = date ? helper.getDateRange(date) : helper.getTwoYearsRange(),
            condition = {status: 1, is_offline: 1};
        dateRange && (condition.rel_date = {$between: dateRange});

        return PlateMarketing.pagingQuery(page, pageSize, {
            attributes: {
                exclude: helper.getExcludeAttrs()
            },
            where: condition,
            order: [
                ['rel_date', 'DESC'],
                ['pubdate', 'DESC']
            ]
        })
    }
}

export default new MarketingService();