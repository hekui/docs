import { Article,UCollection,Dict } from '../model';
import { getUniqueId } from './utils/sequence';
import Sequelize from 'sequelize';

let fields = ['plate_id', 'u_id'];

class collectionService{
    /**
     * 获取收藏列表
     */
    getList({page, pageSize,id}){
        return Article.pagingQuery(page,pageSize,{
            attributes:["id","title","list_cover","keywords","pv_num", "pv_num_basic","pubdate",[Sequelize.col("tagTable.name"),"tag"]],
            where:{is_offline: 1,status:1,
                $and:[
                    Sequelize.where(Sequelize.col('user_collections.u_id'),'=',id)
                ]
            },
            order:[
                ["pubdate","DESC"],
                ["updated_at","DESC"]
            ],
            include:[{
                model:UCollection,
                attributes:[],
                duplicating: false
            },{
                model:Dict,
                as:"tagTable",
                attributes:[]
            }
            ],
            raw: true
        })
    }

    /**
     * 判断是否收藏过该内容
     * @param {*} param0 
     */
    exists({plate_id, u_id}) {
        return UCollection.findOne({
            where: {
                plate_id: plate_id,
                u_id: u_id
            }
        }).then(_data => {
            if (_data) {
                return true;
            }
            return false;
        })
    }


    /**
     * 添加收藏
     * @param {Object} model 
     * @param {String} plate
     */
    add(model, plate) {
        return UCollection.checkModel(model, fields)
                .then(() => {
                    return this.exists(model).then(async isExists => {
                        if (isExists) {
                            throw {message: '已收藏过该内容'}
                        } else {                            
                            model.id = await getUniqueId();
                            model.plate = plate;
                            return UCollection.create(model);
                        }
                    })
                })
    }

    /**
     * 取消收藏
     * @param {*} param0 
     */
    delete({plate_id, u_id}) {
        return this.exists({plate_id: plate_id, u_id: u_id})
                .then(isExists => {
                    if (isExists) {
                        return UCollection.destroy({
                            where: {
                                plate_id: plate_id,
                                u_id: u_id
                            }
                        }).then(data => {
                            if (data == 1) {
                                return true;
                            } else {
                                throw {message: '取消收藏失败'}
                            }
                        });
                    } else {
                        throw {message: '要取消的内容不存在'}
                    }
                })        
    }

    /**
     * 统计收藏数
     * @param {Number} plate_id 
     * @param {String} plate 
     */
    count(plate_id, plate) {
        return UCollection.count({
            where: {
                plate_id: plate_id,
                plate: plate
            }
        })
    }

}
export default new collectionService();
