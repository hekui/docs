import {Comment} from '../model'
import { getUniqueId } from './utils/sequence';
import sequlize from '../model/instance'

class CommentsService {
  // 评论列表
  List(param){
    // console.log('in comments-service.js')
    // 原始sql
    // select article_comment.id, article_comment.content, article_comment.u_id, article_comment.username, article_comment.created_at, article_revert.id as revert_id, article_revert.revert_content, article_revert.revert_at, article_revert.creater, article_revert.creater_user, article_revert.revert_isread
    // from article_comment
    // left join article_revert
    // on article_comment.id = article_revert.c_id and (article_revert.status = 1)
    // order by article_comment.created_at desc

    let sqlCount = 'select count(article_comment.id) as count from article_comment left join article_revert on article_comment.id = article_revert.c_id and (article_revert.status = 1) where article_comment.`status` = 1 and article_comment.a_id = '+ parseInt(param.articleId) +';'
    return sequlize.query(sqlCount).spread(res => { //查询条数
      let count = res[0].count
      if(count === 0){
        return  {
          total: count,
          hasPrev: false,
          hasNext: false,
          list: []
        }
      } else { // 查询列表
        let u_id = param.u_id ? param.u_id : 1
        let offset = (param.page - 1) * param.pageSize
        let sql = 'select article_comment.id, article_comment.content, article_comment.u_id, article_comment.username, article_comment.comment_at, article_comment.like, x_info.thumb as user_thumb, article_revert.id as revert_id, article_revert.revert_content, article_revert.revert_at, article_revert.creater, article_revert.creater_user, article_revert.revert_isread, article_comment_like.status as like_status from article_comment left join x_info on x_info.id = article_comment.u_id left join article_revert on article_comment.id = article_revert.c_id and (article_revert.status = 1) left join article_comment_like on article_comment.id = article_comment_like.c_id and (article_comment_like.u_id = '+ u_id +') where article_comment.`status` = 1 and article_comment.a_id = '+ parseInt(param.articleId) +' order by article_comment.created_at desc limit '+ offset +', '+ param.pageSize + ';'
        // 已登录sql
        // select article_comment.id, article_comment.content, article_comment.u_id, article_comment.username, article_comment.comment_at, article_comment.like, 
        // x_info.thumb, 
        // article_revert.id as revert_id, article_revert.revert_content, article_revert.revert_at, article_revert.creater, article_revert.creater_user, article_revert.revert_isread, 
        // article_revert.status, article_comment_like.status as like_status
        // from article_comment 
        // left join x_info on x_info.id = article_comment.u_id
        // left join article_revert on article_comment.id = article_revert.c_id and (article_revert.status = 1) 
        // left join article_comment_like on article_comment.id = article_comment_like.c_id and (article_comment_like.u_id = 15088102898708)
        // where article_comment.a_id = 201709221924421 and article_comment.`status` = 1
        // order by article_comment.created_at desc 
        // limit 0, 10
        return sequlize.query(sql).spread(res => {
          return  {
            total: count,
            hasPrev: param.page > 1,
            hasNext: param.page * param.pageSize < count,
            list: res
          }
        })
      }
    })
  }
  // 读取某条评论
  Get(param){
    let u_id = param.u_id ? param.u_id : 1
    let sql = 'select article_comment.id, article_comment.content, article_comment.u_id, article_comment.username, article_comment.comment_at, article_comment.like, article_comment.status, x_info.thumb as user_thumb, article_revert.id as revert_id, article_revert.status as revert_status, article_revert.revert_content, article_revert.revert_at, article_revert.creater, article_revert.creater_user, article_revert.revert_isread, article_comment_like.status as like_status from article_comment left join x_info on x_info.id = article_comment.u_id left join article_revert on article_comment.id = article_revert.c_id left join article_comment_like on article_comment.id = article_comment_like.c_id and (article_comment_like.u_id = '+ u_id +') where article_comment.id = '+ param.commentId + ';'
    return sequlize.query(sql).spread(res => {
      // 更新为已读
      if(res.length > 0){
        if(res[0].revert_isread === 0){
          sequlize.query('update article_revert set revert_isread = 1 where id = '+ res[0].revert_id + ';')
        }
        return res[0]
      }
      return {}
    })
    // return Comment.findOne({
    //   attributes: ['id', 'content', 'u_id', 'username', 'created_at'],
    //   where: {
    //     id: param.commentId
    //   },
    // })
  }

  // 新增评论
  async Post(param){
    let id = await getUniqueId()
    return Comment.create({
      id: id - 0,
      a_id: param.articleId,
      content: param.content,
      u_id: param.u_id,
      username: param.u_name,
      status: 0
    })
  }

  // 增加点赞 
  incrementLike(param){
    let sqlCount = 'select count(id) as count,status from article_comment_like where u_id = '+ param.u_id +' and c_id = '+ param.commentId +';'
    console.log('sqlCount', sqlCount)
    return sequlize.query(sqlCount).spread(async res => {
      console.log('res[0]：', res[0])
      let sqlUpdateLike = 'update article_comment set `like` = `like` + 1 where id = '+ param.commentId +';'
      let sqlSelectLike = 'select `like` from article_comment where id = '+ param.commentId +';'

      if(res[0].count === 0){ // 用户点赞不存在
        let id = await getUniqueId()
        let sqlInsert = 'insert into article_comment_like (id, c_id, u_id, status) values('+ id +', '+ param.commentId +', '+ param.u_id +', 1);'
        return sequlize.query(sqlInsert).spread(res => {
          // 更新数据
          return sequlize.query(sqlUpdateLike).spread(res => {
            return sequlize.query(sqlSelectLike).spread(res => {
              return res[0]
            })
          })
        })
      } else {
        if(res[0].status === 1){
          throw new Error('你已经点过赞了')
        }else{
          return sequlize.query(sqlUpdateLike).spread(res => {
            let sql = 'update article_comment_like set status = 1 where u_id = '+ param.u_id +' and c_id = '+ param.commentId +';'
            return sequlize.query(sql).spread(res => {
              return sequlize.query(sqlSelectLike).spread(res => {
                return res[0]
              })
            })
          })
        }
      }
    })
  }

  // 取消点赞
  decrementLike(param){
    let sql = 'select count(id) as count,status from article_comment_like where u_id = '+ param.u_id +' and c_id = '+ param.commentId +';'
    return sequlize.query(sql).spread(res => {
      if(res[0].count === 0 || res[0].status !== 1){
        throw new Error('你没有点过赞')
      }else{
        let sqlUpdateLike = 'update article_comment set `like` = `like` - 1 where id = '+ param.commentId +';'
        let sql = 'update article_comment_like set status = 0 where u_id = '+ param.u_id +' and c_id = '+ param.commentId +';'
        let sqlSelectLike = 'select `like` from article_comment where id = '+ param.commentId +';'
        return sequlize.query(sqlUpdateLike).spread(res => {
          return sequlize.query(sql).spread(res => {
            return sequlize.query(sqlSelectLike).spread(res => {
              return res[0]
            })
          })
        })
      }
    })
  }

  // 消息中心 - 评论未读条数
  MessageUnreadCount(param){
    // 原始sql
    // select count(article_revert.id) as count 
    // from article_revert
    // left join article_comment on article_comment.id = article_revert.c_id 
    // where article_revert.u_id = 15088102898708 and article_revert.revert_isread = 0
    let sqlCount = 'select count(article_revert.id) as count from article_revert left join article_comment on article_comment.id = article_revert.c_id where article_revert.u_id = '+ param.u_id +' and article_revert.revert_isread = 0;'
    return sequlize.query(sqlCount).spread(res => {
      return {
        total: res[0].count
      }
    })
  }

  // 消息中心 - 完整列表
  MessageList(param){
    let sqlCount = 'select count(article_revert.id) from article_revert left join article_comment on article_comment.id = article_revert.c_id where article_revert.u_id = '+ param.u_id +';'
    return sequlize.query(sqlCount).spread(res => {
      let count = res[0].count
      if(count === 0){
        return  {
          total: count,
          hasPrev: false,
          hasNext: false,
          list: []
        }
      } else {
        let offset = (param.page - 1) * param.pageSize
        // select article_comment.id, article_comment.a_id, article_comment.content, article_comment.u_id, article_comment.username, article_comment.comment_at, 
        // article_comment.like, article_revert.id as revert_id, article_revert.status as revert_status, article_revert.revert_content, article_revert.revert_at, article_revert.creater, 
        // article_revert.creater_user, article_revert.revert_isread, article.title as article_title 
        // from article_revert
        // left join article_comment on article_comment.id = article_revert.c_id
        // left join article on article.id = article_comment.a_id
        // where article_comment.u_id = 15088102898708
        // order by article_revert.revert_at desc 
        let sql = 'select article_comment.id, article_comment.a_id, article_comment.content, article_comment.u_id, article_comment.username, article_comment.comment_at, article_comment.like, article_comment.status, article_revert.id as revert_id, article_revert.status as revert_status, article_revert.revert_content,article_revert.revert_at, article_revert.creater, article_revert.creater_user, article_revert.revert_isread, article.title as article_title from article_revert left join article_comment on article_comment.id = article_revert.c_id left join article on article.id = article_comment.a_id where article_comment.u_id = '+ param.u_id +' order by article_revert.revert_at desc limit '+ offset +', '+ param.pageSize + ';'
        return sequlize.query(sql).spread(res => {
          return  {
            total: count,
            hasPrev: param.page > 1,
            hasNext: param.page * param.pageSize < count,
            list: res
          }
        })
      }
    })
  }

}

export default new CommentsService()
