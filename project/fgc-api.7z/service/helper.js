export default {
    /**
     * 根据日期得到时间范围
     * @param {String} dateStr 
     * @param {*} separator 
     */
    getDateRange(dateStr, separator) {
        if (!dateStr) {
            return ;
        }
        let dates = dateStr.split(separator || '-'),
            year = dates[0],
            month = dates[1];

        if (dates.length == 1) {
            // 返回一年的起止时间
            return [new Date(year, 0, 1, 0, 0, 0), new Date(year, 11, 31, 23, 59, 59)];
        }
        //返回一个月的起止时间
        return [new Date(year, month - 1, 1, 0, 0, 0), new Date(year, month, 0, 23, 59, 59)];
    },

    /**
     * 得到今年至去年的时间范围
     * @param {Number} year 
     */
    getTwoYearsRange() {
        let year = new Date().getFullYear();
        return [new Date(year - 1, 0, 1, 0, 0, 0), new Date(year, 11, 31, 23, 59, 59)];
    },

    getExcludeAttrs() {
        return ['created_at', 'updated_at', 'check_date', 'check_comment_type', 'check_comment', 'checker', 'check_status', 'is_offline', 'status', 'creater', 'modifier'];
    }
}