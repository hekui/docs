import {getUniqueId} from "./utils/sequence";
import Sequelize from 'sequelize';
import {UInfo,UAccount,UCollection,UserFollow,BbsRead,BBSPost,Article} from "../model";
import helper from './helper';
import sequelize from "../model/instance";
import bbsBackService from './bbs-back-service';
class UserSearvice {
    /**
     * 根据wx_openid查询用户是否存在
     * @param wx_openid
     * @returns {*}
     */
    existsUser({wx_openid}){
        return UAccount.findOne({
            attributes:['wx_openid'],
            where:{state:0,wx_openid: wx_openid}
        }).then(data => {
            return !!data;
        })
    }

    /**
     * 插入user信息
     * @param model
     */
    addUser(model){
        return getUniqueId().then(id =>{
            model.id = id;
            model.last_port = "wx_openid";
            return sequelize.transaction(t1 =>{
                return Promise.all([
                    UInfo.create(model, { transaction: t1 }),
                    UAccount.create(model, { transaction: t1 })
                ]).then(()=>{
                    return model;
                }).catch(_err =>{
                    return _err;
                })
            })
        });
    }

    /**
     * 返回用户信息
     * @param wx_openid
     * @returns {*}
     * @constructor
     */
    UserInfor({wx_openid}){
        return UInfo.findOne({
            attributes:['id','nick_name','thumb',[sequelize.col("x_account.wx_openid"),"wx_openid"], [Sequelize.literal('DATE_FORMAT(`x_account`.`this_time`, "%Y-%m-%d %H:%i:%s")'), 'this_time']],
            where:{
                $and: [
                    Sequelize.where(Sequelize.col('x_account.wx_openid'), '=', wx_openid),
                    Sequelize.where(Sequelize.col('x_account.state'), '=', 0)

                ]
            },
            include:[{
                model:UAccount,
                attributes:[]
            }]
        })
    }

    /**
     * 获取关注总数
     * @param u_id
     * @returns {Promise.<TResult>}
     */

   getFollowCount({id}) {
       return  UserFollow.count({
           where:{
               u_id:id,
               $and: [
                   Sequelize.where(Sequelize.col('bbs_post.status'), '=', 1),
               ]
           },
           include:[{
               model:BBSPost,
               attributes:[]

           }]
       }).then(result =>{
           return result
       });
   }
    /**
     * 获取收藏总数
     * @param u_id
     * @returns {Promise.<TResult>}
     */
    getCollectionCount({id}) {
        return  UCollection.count({
            where:{
                u_id:id,
                $and: [
                    Sequelize.where(Sequelize.col('article.status'), '=', 1),
                    Sequelize.where(Sequelize.col('article.is_offline'), '=', 1),
                ]
            },
            include:{
                model:Article,
                attributes:[]
            }
        }).then(result =>{
            return result
        });
    }
    /**
     * 获取评论总数
     * @param u_id
     * @returns {Promise.<TResult>}
     */
    getUCommentCount({id}) {
        return bbsBackService.countCommentBackNum(id);
    }
    /**
     * 判断是否有未读消息
     * @param u_id
     * @returns {Promise.<TResult>}
     */
    hasNewMessage({id}){
        return BbsRead.findOne({
            where:{u_id:id,is_read:0}
        }).then(data =>{
            return !!data;
        })
    }

    /**
     * 更新消息已读状态
     * @param id
     * @returns {Promise.<TResult>}
     */
    readMessage({id}){
        let updated_at = new Date().getTime();
        return BbsRead.update({
            is_read:1,
            updated_at:updated_at

        },{
            where:{
                u_id: id
            }
        }).then(data=>{
           if(data[0] == 1){
               return {message: '更新已读成功'};
           }else {
               throw {message:'更新已读失败'}
           }
        })
    }

    /**
     * 是否有评论和回复的权限
     */
    canBack(u_id) {
        return UAccount.findOne({
            attributes: ['is_comment'],
            where: {
                id: u_id,
                state: 0
            }
        }).then(data => {
            data = (data && data.get({plain: true})) || {};
            if (data.is_comment == 0) {
                return true;
            }
            throw {message: '你被禁言了'}
        })
    }

    /**
     * 更新账号的登陆时间
     * @param {Number} u_id 
     * @param {Date} last_time 
     */
    updateAccountTime(city_code, u_id, last_time) {
        let date = new Date();
        console.log('account city_code', city_code)
        return UAccount.update({
            city_code: city_code,
            update_time: date,
            this_time: date,
            last_time: last_time
        }, {
            where: {
                id: u_id
            }
        }).then(data => {
            if (data[0] == 1) {
                return true;
            } 
        })
    }

    /**
     * 更新用户的头像和昵称
     * @param {Number} u_id 
     * @param {String} nick_name 
     */
    updateUserInfo(city_code, u_id, nick_name) {
        return UInfo.update({
            city_code,
            nick_name: nick_name,
            update_time: new Date()
        }, {
            where: {
                id: u_id
            }
        }).then(data => {
            if (data[0] == 1) {
                return true;
            }
        })
    }
}
export default new UserSearvice();
