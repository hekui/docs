import Sequelize from 'sequelize';
import {PlateLandForeshow,PlateLandTran,Dict} from "../model";
import helper from './helper';
class LandService {
    /**
     * 获取预告总数
     * @returns {Promise.<TResult>}
     */
    getForeCount(){
        var date = new Date();
        var dateStart = new Date(date.getFullYear(), date.getMonth(), 1,0,0,0);
        var dateEnd = new Date(date.getFullYear(), date.getMonth() +2 , 0,0,0,0);
        return PlateLandForeshow.count({
            include:[{
                model: PlateLandTran,
                attributes: []
            }],
            where:Object.assign({status:1,is_offline:1,
                'rel_date': {
                    $between: [dateStart, dateEnd]
                },
                $or: [
                    {
                        $and: [
                            Sequelize.where(Sequelize.col('PlateLandTran.id'), {$not: null}),
                            {
                                $or: [
                                    Sequelize.where(Sequelize.col('PlateLandTran.status'), {$ne: 1}),
                                    Sequelize.where(Sequelize.col('PlateLandTran.is_offline'), {$ne: 1})
                                ]
                            }
                        ]
                    },
                    {
                        $and: [Sequelize.where(Sequelize.col('PlateLandTran.id'), {$eq: null})]
                    }
                ]
            })
        }).then(result =>{
            return result;
        })
    }

    /**
     * 获取成交总数
     * @returns {Promise.<TResult>}
     */
    getTranCount(){
        return PlateLandTran.count({
            where:{
                status:1,is_offline:1
            }
        }).then(result =>{
            return result;
        })
    }

    /**
     * 根据typeId获取预告列表
     * @param page
     * @param pageSize
     * @param typeId 1:拍卖 2：挂牌 false
     */
  
    getForeshowListByType({page, pageSize, typeId}){
        var data ={};
        if(typeId){
            data.type = typeId;
        }
        var date = new Date();
        var dateStart = new Date(date.getFullYear(), date.getMonth(), 1,0,0,0);
        var dateEnd = new Date(date.getFullYear(), date.getMonth() +2 , 0,0,0,0);
        return PlateLandForeshow.pagingQuery(page,pageSize,{
            attributes: ["id","plate","land_parcel_no","address","region","district","site_area","site_square","use_property","plot_ratio",["price","starting_price"],"total_price","rel_link","dynamic_content","rel_date","type",[Sequelize.col("regionDict.name"),"region"],[Sequelize.col("districtDict.name"),"district"]],
            where:Object.assign({status:1,is_offline:1,
                'rel_date': {
                    $between: [dateStart, dateEnd]
                },
                $or: [
                    {
                        $and: [
                            Sequelize.where(Sequelize.col('PlateLandTran.id'), {$not: null}),
                            {
                                $or: [
                                    Sequelize.where(Sequelize.col('PlateLandTran.status'), {$ne: 1}),
                                    Sequelize.where(Sequelize.col('PlateLandTran.is_offline'), {$ne: 1})
                                ]
                            }
                        ]
                    },
                    {
                        $and: [Sequelize.where(Sequelize.col('PlateLandTran.id'), {$eq: null})]
                    }
                ]
            },data),
            order:[
                ['rel_date','DESC'],//ASC
                ['pubdate','DESC']
            ],
            include:[{
                model:Dict,
                as:"regionDict",
                attributes:[]
            },{
                model:Dict,
                as:"districtDict",
                attributes:[]
            }, {
                model: PlateLandTran,
                attributes: []
            }]
        })
    }

    /**
     *根据typeId获取结果列表
     * @param page
     * @param pageSize
     * @param results 1:成交 2：流派 3：融派 4：终止 false
     * @param dateTime
     */
    getTranListByType({page, pageSize,typeId,dateTime}){
        var data = {};
        var date = new Date();
        var rel_date = {};
        var dateStart = new Date(date.getFullYear()-2, 11, 31, 23, 59, 59);
        var dateEnd = new Date(date.getFullYear(), date.getMonth() +1 , date.getDate(),23,59,59);
        if(dateTime && dateTime == ""){
            rel_date.rel_date = {$between:[dateStart,dateEnd]}
        }else {
            let dateRange = helper.getDateRange(dateTime);
            dateRange && (rel_date.rel_date = {$between: dateRange});
        }
        if(typeId){
            data.results = typeId;
        }
        return PlateLandTran.pagingQuery(page,pageSize,{
            attributes:['id','plate','land_parcel_no','address','region','district','site_area','site_square','use_property','plot_ratio','starting_price','s_unit','tran_price','t_unit','tracn_total_price','get_company','show_company','premium_rate','rel_date','rel_link','dynamic_content',"type",'results',[Sequelize.col("regionDict.name"),"region"],[Sequelize.col("districtDict.name"),"district"]],
            where:Object.assign({status:1,is_offline:1},data,rel_date),
            order:[
                ['rel_date','DESC'],//ASC
                ['pubdate','DESC']
            ],
            include:[{
                model:Dict,
                as:"regionDict",
                attributes:[]
            },{
                model:Dict,
                as:"districtDict",
                attributes:[]
            }]
        })
    }

    /**
     * 根据关键字查询竞得企业列表
     * @param keyword
     */
    searchByCompany(keyword){
        return  PlateLandTran.findAll({
            attributes:["id","show_company"],
            where: {
                status: 1,
                is_offline: 1,
                $or :[  {
                    get_company: {$like: '%' + keyword + '%'}
               }]
            }
        })
    }

    /**
     * 根据竞得企业名字查询列表结果页
     * @param page
     * @param pageSize
     * @param keyword
     * @returns {*}
     */
    getSearchByCompanty({page,pageSize,keyword}){
        return PlateLandTran.pagingQuery(page,pageSize,{
            attributes:['id','plate','land_parcel_no','address','region','district','site_area','use_property','plot_ratio','starting_price','s_unit','tran_price','t_unit','tracn_total_price','get_company','show_company','premium_rate','rel_date','rel_link','dynamic_content',"type","results"],
            where:{
                status: 1,
                is_offline: 1,
                $or:[{
                    get_company:{$like:'%' + keyword + '%'}
                }]
               
            },
            order:[
                ['rel_date','DESC'],//ASC
                ['pubdate','DESC']
            ]
        })
    }
    /**
     * 根据竞得企业id查询列表结果页
     * @param ID
     * @returns {*}
     */
    getSearchByID({ID}){
        return PlateLandTran.findOne({
            attributes:['id','plate','land_parcel_no','address','region','district','site_area','use_property','plot_ratio','starting_price','s_unit','tran_price','t_unit','tracn_total_price','get_company','show_company','premium_rate','rel_date','rel_link','dynamic_content',"type"],
            where:{
                status: 1,
                is_offline: 1,
                id: ID
            },
            order:[
                ['rel_date','DESC'],//ASC
                ['pubdate','DESC']
            ]
        })
    }
}

export default new LandService();