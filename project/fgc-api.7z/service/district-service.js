import Sequelize from 'sequelize';
import { PlateDistrict, DistrictDynamic } from '../model';

class DistrictService {
    /**
     * 获取区域动态
     * @param {Object} param0 
     */
    getDynamicList({page, pageSize}) {
        return DistrictDynamic.pagingQuery(page, pageSize, {
            attributes: ['id', 'rel_link', 'rel_date', 'dynamic_content'],
            where: {
                status: 1,
                is_offline: 1,
                '$and': [                    
                    Sequelize.where(Sequelize.col('plate_district.status'), '=', 1),
                    Sequelize.where(Sequelize.col('plate_district.is_offline'), '=', 1)
                ]
            },
            order: [
                ['rel_date', 'DESC'],
                ['pubdate', 'DESC']
            ],
            include: [{
                model: PlateDistrict,
                attributes: [],
                duplicating: false
            }]
        })
    }

    /**
     * 获取区域列表
     * @param {Object} param0 
     */
    getDistrictList({page, pageSize}) {
        return PlateDistrict.pagingQuery(page, pageSize, {
            attributes: ['id', 'name', 'picture', 'scope_range', 'price', 'score', 'resource_advantage', 'support_plan', 'developers', 'project_price_increase', 'land_price_increase'],
            where: {
                status: 1,
                is_offline: 1
            },
            order: [
                ['sort_order', 'DESC'],
                ['pubdate', 'DESC']
            ]
        })
    }
}

export default new DistrictService();