import { UserLike } from '../model';
import { getUniqueId } from './utils/sequence';
let fields = ['plate_id', 'u_id'];

class LikeService {
    /**
     * 点赞
     * @param {Object} model 
     * @param {String} plate 
     */
    async add(model, plate) {
        model.id = await getUniqueId();
        model.plate = plate;
        return UserLike.create(model);
    }
    
    /**
     * 判断用户是否已经点赞
     * @param {Number} plateID 
     * @param {Number} uID 
     */
    exists({plate_id, u_id}) {
        return UserLike.findOne({
            where: {
                plate_id: plate_id,
                u_id: u_id
            }
        }).then(_data => {
            if (_data) {
                return true;
            }
            return false;
        })
    }

    /**
     * 取消点赞
     * @param {Number} id 
     */
    delete({plate_id, u_id}) {
        return UserLike.destroy({
            where: {
                plate_id: plate_id,
                u_id: u_id
            }
        }).then(data => {
            if (data == 1) {
                return true;
            } else {
                throw {message: '取消点赞失败'}
            }
        });
    }

    /**
     * 统计板块点赞数
     * @param {*} param0 
     */
    count(plate_id, plate) {
        return UserLike.count({
            where: {
                plate_id: plate_id,
                plate: plate
            }
        })
    }
}

export default new LikeService();