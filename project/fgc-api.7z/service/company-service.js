import Sequelize from 'sequelize';
import { PlateCompany, CompanyDynamic, Dict, CompanyBasic } from '../model';

class CompanyService {
    /**
     * 根据typeId获取公司动态
     * @param {Object} param0 
     */
    getDynamicByType({page, pageSize, typeId}) {
        return CompanyDynamic.pagingQuery(page, pageSize, {
            attributes: ['id', 'plate_company_id', 'rel_date', 'dynamic_content'],
            where: {status: 1, is_offline: 1},
            order: [
                ['rel_date', 'DESC'],
                ['pubdate', 'DESC']
            ],
            include: [{
                model: PlateCompany,
                attributes: [],
                where: {status: 1, is_offline: 1},
                duplicating: false,
                include: [{
                    model: Dict,
                    attributes: [],
                    where: {id: typeId},
                    duplicating: false
                }]
            }]
        })
    }

    /**
     * 获取分页查询基本条件
     */
    getPagingBase() {
        return {
            attributes: ['id', 'name', 'list_cover', 'introduce', [Sequelize.col('company_basic.name'), 'real_name']],
            where: {status: 1, is_offline: 1},
            order: [
                ['sort_order', 'DESC'],
                ['pubdate', 'DESC']
            ],
            include: [{
                model: CompanyBasic,
                attributes: [],
                duplicating: false
            }]
        }
    }

    /**
     * 根据typeId获取公司列表
     * @param {Object} param0 
     */
    getCompanyByType({page, pageSize, typeId}) {
        let options = this.getPagingBase();
        options.include.push({
            model: Dict,
            attributes: [],
            where: {id: typeId},
            duplicating: false
        });
        return PlateCompany.pagingQuery(page, pageSize, options);
    }

    /**
     * 根据关键字查询公司列表（分页）
     * @param {Object} param0 
     */
    searchCompanyPaging({page, pageSize, keyword}) {
        let options = this.getPagingBase();
        options.where.$or = [{
            name: {$like: '%' + keyword + '%'},
            company_id: null
        }, {
            $and: [
                Sequelize.where(Sequelize.col('company_basic.name'), 'like', '%' + keyword + '%'),
                {company_id: {$ne: null}}
            ]
        }]
        return PlateCompany.pagingQuery(page, pageSize, options);
    }

    /**
     * 根据关键字查询公司列表(获取所有匹配的公司名称)
     * @param {String} keyword
     */
    searchCompany(keyword) {
        return PlateCompany.findAll({
            attributes: ['id', 'name', [Sequelize.col('company_basic.name'), 'real_name']],
            where: {
                status: 1, 
                is_offline: 1, 
                $or: [{
                    name: {$like: '%' + keyword + '%'},
                    company_id: null
                }, {
                    $and: [
                        Sequelize.where(Sequelize.col('company_basic.name'), 'like', '%' + keyword + '%'),
                        {company_id: {$ne: null}}
                    ]
                }]
            },
            include: [{
                model: CompanyBasic,
                attributes: [],
                duplicating: false
            }]
        })
    }

    /**
     * 根据ID查询公司信息
     * @param {Number} ID 
     */
        getCompanyByID(ID) {
        return PlateCompany.findOne({
            attributes: ['id', 'name', 'list_cover', 'introduce', [Sequelize.col('company_basic.name'), 'real_name']],
            where: {status: 1, is_offline: 1, id: ID},
            include: [{
                model: CompanyBasic,
                attributes: [],
                duplicating: false
            }]
        })
    }

    /**
     * 根据公司ID获取公司详情
     * @param {number} companyId 
     */
    getDetailsById(companyId) {
        return PlateCompany.findOne({
            attributes: ['id', 'name', 'introduce', 'cd_introduce', 'detail_cover', [Sequelize.col('company_basic.name'), 'real_name']],
            where:{
                id: companyId                
            },                       
            order: [
                [Sequelize.col('dynamics.rel_date'), 'DESC'],
                [Sequelize.col('dynamics.pubdate'), 'DESC']
            ],
            include: [{
                model: CompanyBasic,
                attributes: [],
                duplicating: false
            }, {
                model: CompanyDynamic,
                as: 'dynamics',
                attributes: ['id', 'rel_date', 'dynamic_content', 'rel_link'],
                on: {
                    plate_company_id: {$eq: Sequelize.col('plateCompany.id')},
                    status: {$eq: 1},
                    is_offline: {$eq: 1}
                }
            }]
        })
    }
}

export default new CompanyService();