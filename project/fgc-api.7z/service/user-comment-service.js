import Sequelize from 'sequelize';
import {BBSPost,BBSPostBack} from "../model";
import helper from './helper';
import sequelize from "../model/instance";
class CommentService {
    // // /**
    // //  * 是否发表话题
    // //  * @param id
    // //  * @returns {Promise|Promise.<TResult>}
    // //  */
    // // hasBbspost({id}){
    // //     return BBSPost.findAll({
    // //         where:{u_id:id,status:1}
    // //     }).then(_data =>{
    // //         if(_data){
    // //             return true;
    // //         }else {
    // //             return false;
    // //         }
    // //     })
    // // }
    // //
    // // /**
    // //  * 我话题下的评论
    // //  * @param page
    // //  * @param pageSize
    // //  * @param id
    // //  * @returns {*}
    // //  */
    // hasBbsAndCommentList({page,pageSize,id}){
    //     return BBSPostBack.pagingQuery(page,pageSize,{
    //         attributes:["id","post_id","tags","content","u_id","u_name","u_avator","to_id","tou_id",Sequelize.col(BBSPost.content)],
    //         where:{tou_id:id,status:1,to_id:0},
    //         order:[
    //             ["updated_at",DESC],
    //             ["created_at",DESC]
    //         ],
    //         include:[{
    //             model:BBSPost,
    //             attributes:[]
    //         }]
    //     })
    // }
    /**
     * 评论回复列表
     * @param page
     * @param pageSize
     * @param id
     * @returns {*}
     */
    commentAndReply({page,pageSize,id}){
        return BBSPostBack.pagingQuery(page,pageSize,{
            attributes:["id","post_id","tags","content","u_id","u_name","u_avator",'tou_id',"to_id","created_at"],
            where:{
                tou_id:id,
                status:1,
                u_id:{$not:id},
                $or:[
                    {
                        to_id: {$not: 0},
                        $and: [
                            Sequelize.where(Sequelize.col('comment.status'), '=', 1)
                        ]
                    },
                    {
                        to_id: 0,
                        $and: [
                            Sequelize.where(Sequelize.col('bbs_post.status'), '=', 1)
                        ]
                    }
                ]

            },
            order: [
                ["created_at","DESC"],
                ["updated_at","DESC"]

            ],
            include: [{
                model: BBSPostBack,
                as: 'comment',
                attributes: ['id', 'u_id', 'u_name', 'content',"created_at"],
                duplicating: false,

            },{
                model:BBSPost,
                attributes:["id","tags","title"],
                on: {
                    id: {$eq: Sequelize.col('bbs_post_back.post_id')},
                    $and: [
                        Sequelize.where(Sequelize.col('bbs_post_back.to_id'), '=', 0)
                    ]
                },
            },{
                model:BBSPost,
                as: 'bbs',
                attributes:[],
                where: {
                    status: 1
                }
            }]
        })
    }
}
export default new CommentService;