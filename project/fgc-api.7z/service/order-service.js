import Sequelize from 'sequelize';
import { Order } from '../model';
import { getUniqueId } from './utils/sequence';

let fields = ['plate_id', 'u_id', 'money'];

class OrderService {
    /**
     * 增加支付订单
     * @param {Object} model
     * @parma {String} plate
     */
    addOrder(model, plate) {
        return Order.checkModel(model, fields)
                .then(async () => {
                    model.id = await getUniqueId();
                    model.plate = plate;
                    return Order.create(model).then(data => {
                        if (data) {
                            return data;
                        } 
                        throw {message: '增加支付订单失败'};
                    });
                })
    }

    /**
     * 更新订单的支付状态
     */
    updateStatus({id, status, money}, options) {
        return this.checkMoney({
            id: id,
            money: money
        }).then(isCorrect => {
            if (!isCorrect) {
                status = 3;  // 状态3表示支付价格与订单价格不一致导致的支付失败
            }            
            return Order.update({
                status: status,
                updated_at: new Date()
            }, Object.assign({
                where: {
                    id: id
                }
            }, options)).then(data => {
                if (data[0] == 1) {
                    return status;
                }
                throw {message: '修改订单支付状态失败'};
            })
        })
    }

    /**
     * 获取订单状态信息
     * @param {Number} status 
     */
    getOrderMsg(status) {
        let msg = '';
        switch(status) {
            case 1:
                msg = '支付成功';
                break;
            case 2: 
                msg = '支付失败';
                break;
            case 3: 
                msg = '支付失败,支付价格与订单价格不一致';
                break;
            default: 
                msg = '订单创建成功'
        }
        return msg;
    }

    // 检查支付的money与订单的money是否一致
    checkMoney({id, money}) {
        return Order.findOne({
            attributes: ['id', 'money'],
            where: {
                id: id,
                money: money
            }
        }).then(data => {
            return !!data;
        })
    }

    /**
     * 根据订单ID获取订单信息
     */
    getOrderByID(ID, options) {
        return Order.findOne(Object.assign({
            attributes: ['id', 'plate_id', 'u_id', 'money'],
            where: {
                id: ID,
                status: 1
            }
        }, options));
    }

    /**
     * 查询用户是否支付过该模块
     * @param {Number} u_id 
     * @param {Number} plate_id 
     * @param {String} plate 
     */
    isExist(u_id, plate_id, plate, type) {
        if (!u_id) {
            return Promise.resolve(false);
        }
        return Order.findOne({
            attributes: ['id'],
            where: {
                u_id: u_id,
                plate_id: plate_id,
                plate: plate,
                status: 1,
                type: type
            }
        }).then(data => {
            return !!data;
        })
    }

    /**
     * 获取订单的plate_id
     * @param {Number} id 
     */
    getPlateID(id) {
        return Order.findById(id, {
            attributes: ['plate_id']
        }).then(_data => {
            _data = (_data && _data.get({plain: true})) || {};
            return _data.plate_id;
        })
    }

    /**
     * 统计支付成功的订单数量
     * @param {*} param0 
     */
    countNum({plate_id, plate, type}) {
        return Order.count({
            where: {
                plate_id: plate_id,
                plate: plate,
                type: type,
                status: 1
            }
        })
    }

    
    /**
     * 获取用户的打赏情况
     * @param {Number} uid
     */
    getRewardTimes({u_id, id}){
        return Order.count({
            where: {
                plate_id: id,
                u_id: u_id,
                type: 1,
                status: 1
            }
        }) 
    }

}

export default new OrderService();