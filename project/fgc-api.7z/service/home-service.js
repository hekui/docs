import { ContentAdvert, ContentPosition } from '../model';
import sequlize from '../model/instance'

class HomeService {
    /**
     * 获取banner列表
     */
    getBannerList({city_code}) {
        let curDate = new Date();

        // let sql = "select id, title, activity_img, relation_url, start_time, end_time, `status`, created_at, updated_at from content_advert where city_code = '"+ city_code +"' and status = 1 and start_time < now() and end_time > NOW() and activity_position = (select code from content_position where city_code = '"+ city_code +"' and code = "+ positionCode +") order by sort_order desc, start_time asc"

        let sql = "SELECT `content_advert`.`id`, `content_advert`.`title`, `content_advert`.`activity_img`, `content_advert`.`relation_url` FROM `content_advert` AS `content_advert` INNER JOIN `content_position` AS `content_position` ON `content_advert`.`activity_position` = `content_position`.`code`  AND `content_position`.`code` = 500002001 AND `content_position`.`status` = 1 WHERE `content_advert`.`city_code` = '"+ city_code +"' AND `content_position`.`city_code` = '"+ city_code +"' AND `content_advert`.`status` = 1 AND `content_advert`.`start_time` <= now() AND `content_advert`.`end_time` >= now() ORDER BY sort_order DESC;"
        return sequlize.query(sql).spread(res => {
            return res
        })


        // return ContentAdvert.findAll({
        //     attributes: ['id', 'title', 'activity_img', 'relation_url'],
        //     where: {
        //         city_code,
        //         status: 1,
        //         start_time: {$lte: curDate},
        //         end_time: {$gte: curDate}
        //     },
        //     order: 'sort_order DESC',
        //     include: [{
        //         model: ContentPosition,
        //         attributes: [],
        //         where: {
        //             code: 500002001,
        //             status: 1
        //         }
        //     }]
        // })
    }
}

export default new HomeService();