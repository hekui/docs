import redis from 'redis';
import {redisConfig} from '../../config/sys.config';

const redisClient = redis.createClient(redisConfig);
redisClient.on('error', err => {
    console.log('Redis Error: ', err);
});

function getValue(key) {
    return new Promise((resolve, reject) => {
        redisClient.get(key, (err, reply) => {
            if (err) {
                reject(err);
            } else {
                resolve(reply);
            }            
        });
    })
} 

/**
 * 返回唯一的id值(Promise)
 */
function getUniqueId() {
    let time = new Date().getTime(),
        key = 'fgc:seq:cnt',
        timeKey = `seq_cnt_${time}`,
        data = {},
        count = Math.floor(Math.random() * 9 + 1);

    return getValue(key).then(_data => {
        if (_data) {
            data = JSON.parse(_data);
            if (data[timeKey]) {
                count = data[timeKey] + 1;
            } 
        }
        data[timeKey] = count;
        redisClient.set(key, JSON.stringify(data));
        return time + '' + count;
    });
}

export {
    getUniqueId
}