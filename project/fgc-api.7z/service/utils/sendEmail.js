import request from 'request'
import { reportService } from '../../service';
import {adminHost} from './../../config/sys.config'
/**
 * 发送邮件 - 调用php admin 接口
 * @param {Object} id 
 * {
 *  id,  // 数据记录主键id (table: content_report_details)
 * }
 */
function sendReportEmail(id){
  console.log('url:', adminHost+ '/noauth/mail')
  console.log('id:', id)
  request({
    url: adminHost+ '/noauth/mail',
    method: 'POST',
    json: true,
    form: {
      id,
    }
  }, (error, response, body) => {
    console.log('error:', error)
    console.log('body:', JSON.stringify(body))
    if(!error && body.code == 200){
      // 更新邮件发送时间
      reportService.updateEmailSendTime(id)
    }
  })
}

// test 
// sendReportEmail(15114219794378)

export {
  sendReportEmail
}