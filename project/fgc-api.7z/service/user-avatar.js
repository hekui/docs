// https://help.aliyun.com/document_detail/32070.html
// https://help.aliyun.com/document_detail/32072.html?spm=5176.doc32071.6.742.zEEr5H
// https://segmentfault.com/a/1190000008352305
var co = require('co')
var OSS = require('ali-oss')
var request = require('request')
import sequlize from '../model/instance'
import {OSSConfig, fgcImgHost} from '../config/sys.config'

var client = new OSS({
  region: OSSConfig.region,
  accessKeyId: OSSConfig.accessKeyId,
  accessKeySecret: OSSConfig.accessKeySecret,
  bucket: OSSConfig.bucket
});

// 修改数据库：增加字段last_thumb存储上次下载的头像URL
// 获取用户头像，判断是否需要更新
function getOldAvatar({thumb, u_id}){
  // console.log('thumb', thumb)
  // console.log('u_id', u_id)
  if(thumb){
    let sql = `select last_thumb from x_info where id = ${u_id}`
    sequlize.query(sql).spread(res => {
      let last_thumb = res[0].last_thumb
      if(!last_thumb || last_thumb !== thumb){
        // console.log('need down')
        asyncDownAvatar({thumb, u_id})
      }
    })
  }
}

// 异步下载用户头像，保存至oss
function asyncDownAvatar({thumb, u_id}){
  request(thumb).on('response', (response) => {
    co(function* () {
      let fileName = '/images/avatar/' + u_id + '_' + Math.floor(Math.random() * 1000000) + '.jpg'
      let result = yield client.putStream(fileName, response, {timeout: 30 * 60 * 1000});
      // console.log(result);
      updateAvatar({
        u_id, thumb, 
        newThumb: fgcImgHost + result.name
      })
    }).catch(err => {
      console.log('err in func asyncDownAvatar: ')
      console.warn(err);
    });
  });
}

// 更新用户头像至数据库
function updateAvatar({newThumb, thumb, u_id}){
  let sql = `update x_info set thumb = '${newThumb}', last_thumb = '${thumb}' where id = ${u_id}`
  sequlize.query(sql).spread(res => {
    // console.log('updated')
  })
}

// getOldAvatar({
//   u_id: '15102894506989',
//   thumb: 'https://wx.qlogo.cn/mmopen/vi_32/MicF1Sut8xX8Nw10VvibjYfeghObXVv503CgX45Szxdz8jI9EVLSTFgriaQalKJq8QQQFYWpLfiaAn7ZUvaKuHX5VQ/0'
// })

// asyncDownAvatar({
//   thumb: 'https://wx.qlogo.cn/mmopen/vi_32/MicF1Sut8xX8Nw10VvibjYfeghObXVv503CgX45Szxdz8jI9EVLSTFgriaQalKJq8QQQFYWpLfiaAn7ZUvaKuHX5VQ/0',
//   u_id: '201711221026'
// })

export default getOldAvatar