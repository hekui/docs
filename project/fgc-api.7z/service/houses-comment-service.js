import Sequelize from 'sequelize';
import { HousesComment } from '../model';
import { getUniqueId } from './utils/sequence';
import UserSearvice from './user-service';
let fields = ['h_id', 'content', 'com_score', 'pdu_score', 'pty_score', 'mou_score', 'u_id'];

class HousesCommentService {
    /**
     * 增加楼盘评价
     * @param {Object} model
     */
    addComment(model) {
        return HousesComment.checkModel(model, fields)
            .then(() => {
                return UserSearvice.canBack(model.u_id)
                    .then(async () => {
                        let id = await getUniqueId();
                        model.id = id;
                        return HousesComment.create(model);
                    })
                
            })
    }

    /**
     * 获取用户评价综合得分
     */
    getCommentScore(h_id) {
        return HousesComment.findOne({
            attributes: [
                [Sequelize.fn('sum', Sequelize.col('com_score')), 'comsum'], 
                [Sequelize.fn('sum', Sequelize.col('pdu_score')), 'pdusum'],
                [Sequelize.fn('sum', Sequelize.col('pty_score')), 'ptysum'],
                [Sequelize.fn('sum', Sequelize.col('mou_score')), 'mousum'],
                [Sequelize.fn('count', 'h_id'), 'count']
            ],
            where: {
                h_id: h_id,
                status: 1
            }
        }).then(data => {
            data = (data && data.get({plain: true})) || {};
            if (!data.count) {
                return {};
            }
            return {
                all: this.getRound((data.comsum + data.pdusum + data.ptysum + data.mousum) / data.count / 4),
                com_average: this.getRound(data.comsum / data.count),
                pdu_average: this.getRound(data.pdusum / data.count),
                pty_average: this.getRound(data.ptysum / data.count),
                mou_average: this.getRound(data.mousum / data.count)
            }
        })
    }

    /**
     * 四舍五入后取一位小数
     * @param {Number} num 
     */
    getRound(num) {
        return Math.round(num * 10) / 10;
    }

    /**
     * 获取楼盘评价列表
     */
    getCommentList({page, pageSize, h_id}) {
        return HousesComment.pagingQuery(page, pageSize, {
            attributes: ['id', 'h_id', 'content', 'com_score', 'pdu_score', 'pty_score', 'mou_score', 'comment_at', 'u_id', 'u_name', 'u_avator'],
            where: {
                h_id: h_id,
                status: 1
            },
            order: 'comment_at DESC'
        })
    }

}

export default new HousesCommentService();