import Sequelize from 'sequelize';
import { PlatePolicy } from '../model';
import helper from './helper';

class PolicyService {
    /**
     * 获取政策列表
     * @param {Object} param0 
     * @param.date {string('xxxx')}
     */
    getList({page, pageSize, date}) {
        let dateRange = date ? helper.getDateRange(date) : helper.getTwoYearsRange(),
            condition = {status: 1, is_offline: 1};
        dateRange && (condition.rel_date = {$between: dateRange});

        return PlatePolicy.pagingQuery(page, pageSize, {
            attributes: {
                exclude: helper.getExcludeAttrs()
            },
            where: condition,
            order: [
                ['rel_date', 'DESC'],
                ['pubdate', 'DESC']
            ]
        })
    }
}

export default new PolicyService();