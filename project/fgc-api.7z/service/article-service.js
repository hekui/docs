import Sequelize from 'sequelize';
import {
    Article,
    Dict,
    ArticleGift,
    Resource
} from '../model';
import {
    getUniqueId
} from './utils/sequence';
import orderService from './order-service';
import housesService from './houses-service';
import sequelize from '../model/instance';

let giftFields = ['a_id', 'money'],
    articleFields = ['title', 'description', 'keywords', 'author', 'column_id'],
    articleType = 102,
    tagType = 104,
    sourceType = 106,
    supportType = 200;

class ArticleService {
    /**
     * 获取文章分类列表
     */
    getTypes({city_code}) {
        return this.getDictsByType(city_code, articleType, {
            order: 'sort_order DESC'
        }).then(result => {
            result.unshift({
                name: '热门'
            })
            return result;
        })
    }

    // 获取文章标签
    getTags({city_code}) {
        return this.getDictsByType(city_code, tagType);
    }

    // 获取文章来源
    getSources({city_code}) {
        return this.getDictsByType(city_code, sourceType);
    }

    // 获取数据支持
    getSupports({city_code}) {
        let filter = ['住宅', '住宅-动态', '文章资讯', '物业-舆情', '物业-公司', '违法违纪'];
        return this.getDictsByType(city_code, supportType)
            .then(result => {
                let temp = null;
                return result.filter(item => {
                    temp = item.get({
                        plain: true
                    });
                    return filter.indexOf(temp.name) < 0;
                })
            })
    }

    // 获取声明
    getStatements({city_code}) {
        return Resource.findAll({
            attributes: ['code', 'name'],
            where: {
                city_code, 
                type: 1,
                status: 1
            }
        })
    }

    // 根据type获取字典配置
    getDictsByType(city_code, type, options) {
        return Dict.findAll(Object.assign({
            attributes: ['id', 'name'],
            where: {
                city_code, 
                type: type,
                status: 1
            }
        }, options))
    }

    /**
     * 获取文章的浏览量
     * @param {*} id
     */
    getPvNum(id) {
        return Article.findOne({
            attributes: ['pv_num'],
            where: {
                id: id
            }
        }).then(data => {
            let result = (data && data.get({
                plain: true
            })) || {};
            return result.pv_num || 0;
        })
    }

    /**
     * 修改文章的浏览量
     * @param {Number} id
     * @param {Number} count
     */
    async setPvNum(id) {
        let count = await this.getPvNum(id);
        return Article.update({
            pv_num: count + 1
        }, {
            where: {
                id: id
            }
        }).then(data => {
            if (data[0] == 1) {
                return {
                    message: '更新浏览量成功'
                };
            } else {
                throw {
                    message: '更新浏览量失败'
                }
            }
        })
    }

    /**
     * 根据文章分类id获取文章列表
     * @param {Number} typeID
     */
    getList({
        city_code,
        page,
        pageSize,
        typeID
    }) {
        return Article.pagingQuery(page, pageSize, {
            attributes: ['id', 'title', [Sequelize.col('tagTable.name'), 'tag'], 'pubdate', 'pv_num', 'pv_num_basic', 'list_cover', 'is_top'],
            order: [
                ['is_top', 'DESC'],
                ['pubdate', 'DESC'],
                ['pv_num', 'DESC']
            ],
            where: {
                city_code,
                status: 1,
                is_offline: 1,
                column_id: typeID,
                prerelease_time: {
                    $lt: new Date()
                }
            },
            include: [{
                model: Dict,
                as: 'tagTable',
                attributes: []
            }],
            raw: true
        })
    }

    /**
     * 获取热门文章
     * @param {*} param0
     */
    getHotList({
        city_code,
        page = 1,
        pageSize = 20
    }) {
        return Article.pagingQuery(page, pageSize, {
            attributes: ['id', 'title', [Sequelize.col('tagTable.name'), 'tag'], 'pubdate', 'pv_num', 'pv_num_basic', 'list_cover', 'is_top'],
            order: [
                ['is_top', 'DESC'],
                ['pubdate', 'DESC'],
                ['pv_num', 'DESC']
            ],
            where: {
                city_code,
                status: 1,
                is_offline: 1,
                is_hot: 1,
                prerelease_time: {
                    $lt: new Date()
                }
            },
            include: [{
                model: Dict,
                as: 'tagTable',
                attributes: []
            }],
            raw: true
        })
    }

    /**
     * 根据文章id获取文章详情及推荐文章列表
     * @param {Number} id
     */
    getDetails(id) {
        return Article.findOne({
            attributes: ['id', 'city_code', 'title', 'list_cover', 'description', 'pubdate', [Sequelize.col('src.name'), 'source'], 'author', 'content', [Sequelize.col('support.name'), 'support_type'], 'support_url', 'editor', 'column_id', [Sequelize.col('type.name'), 'typeName'], 'statement_code', 'qr_code', 'relation_id', 'pv_num', 'pv_num_basic', [Sequelize.col('tagTable.name'), 'tagName']],
            where: {
                status: {
                    $in: [1, 3]
                },
                is_offline: 1,
                id: id
            },
            include: [{
                model: Dict,
                as: 'src',
                attributes: []
            }, {
                model: Dict,
                as: 'support',
                attributes: []
            }, {
                model: Dict,
                as: 'type',
                attributes: []
            }, {
                model: Dict,
                as: 'tagTable',
                attributes: []
            }]
        }).then(async data => {
            if (data) {
                let article = data.get({
                    plain: true
                });
                article.pv_num += article.pv_num_basic;
                delete article.pv_num_basic;

                let recommends = await this.getRecommendArticles(article);
                recommends.map(item => {
                    item.pv_num += item.pv_num_basic
                    delete item.pv_num_basic
                    return item
                })
                let statement = [];
                if (article.statement_code) {
                    let codes = article.statement_code.split(',');
                    statement = await Resource.findAll({
                        attributes: ['name', 'content'],
                        where: {
                            city_code: article.city_code,
                            type: 1,
                            code: {
                                $in: codes
                            },
                            status: 1
                        }
                    })
                }
                article.recommends = recommends;
                
                article.statement = statement;
                if (article.relation_id) {
                    let hId = article.relation_id.split(',')[0];
                    article.relation_house = await housesService.searchHouseByID(hId);
                }
                return article;
            }
        })
    }

    /**
     * 获取两篇推荐文章列表(UNIX_TIMESTAMP将时间换算成秒)
     * @param {*} param0
     */
    getRecommendArticles({
        city_code,
        column_id,
        id,
        pubdate
    }) {
        return Article.findAll({
            attributes: ['id', 'title', [Sequelize.col('tagTable.name'), 'tag'], 'pubdate', 'pv_num', 'pv_num_basic', 'list_cover'],
            where: {
                city_code,
                id: {
                    $ne: id
                },
                column_id: column_id,
                status: 1,
                is_offline: 1
            },
            order: Sequelize.literal(`ABS(UNIX_TIMESTAMP(article.pubdate) - ${new Date(pubdate).getTime() / 1000}) ASC`),
            limit: 2,
            include: [{
                model: Dict,
                as: 'tagTable',
                attributes: []
            }],
            raw: true
        })
    }

    /**
     * 修改文章的收藏数
     * @param {*} id
     * @param {*} count
     */
    setCollectionNum(id, count) {
        return Article.update({
            collection_num: count
        }, {
            where: {
                id: id
            }
        }).then(data => {
            if (data[0] == 1) {
                return {
                    message: '修改文章收藏数成功'
                };
            } else {
                throw {
                    message: '修改文章收藏数失败'
                }
            }
        });
    }

    /**
     * 根据关份键字搜索匹配的话题标题
     * @param {String} keyword
     */
    search({city_code, keyword}) {
        return Article.findAll({
            attributes: ['id', 'title'],
            where: {
                city_code,
                status: 1,
                is_offline: 1,
                title: {
                    $like: '%' + keyword + '%'
                }
            }
        })
    }

    getBaseOption() {
        return {
            attributes: ['id', 'title', [Sequelize.col('tagTable.name'), 'tag'], 'pubdate', 'pv_num', 'pv_num_basic', 'list_cover', 'prerelease_time'],
            include: [{
                model: Dict,
                as: 'tagTable',
                attributes: []
            }],
            raw: true
        }
    }

    /**
     * 根据关键字搜索匹配的话题标题(分页)
     * @param {*} param0
     */
    searchPaging({
        city_code,
        page,
        pageSize,
        keyword
    }) {
        let options = this.getBaseOption();
        return Article.pagingQuery(page, pageSize, Object.assign(options, {
            order: [
                ['pubdate', 'DESC'],
                ['pv_num', 'DESC']
            ],
            where: {
                city_code,
                status: 1,
                is_offline: 1,
                title: {
                    $like: '%' + keyword + '%'
                }
            }
        }));
    }

    /**
     * 根据关键字获取两个文章
     */
    searchForHome({city_code, keyword}) {
        let options = this.getBaseOption();
        return Article.findAll(Object.assign(options, {
            order: [
                ['pubdate', 'DESC'],
                ['pv_num', 'DESC']
            ],
            where: {
                city_code,
                status: 1,
                is_offline: 1,
                title: {
                    $like: '%' + keyword + '%'
                },
                prerelease_time: {
                  $lt: new Date()
                },
            },
            limit: 3
        }));
    }

    /**
     * 根据文章ID搜索文章
     */
    searchArticleByID(ID) {
        return Article.findOne({
            attributes: ['id', 'title', [Sequelize.col('tagTable.name'), 'tag'], 'pubdate', 'pv_num', 'pv_num_basic', 'list_cover'],
            where: {
                status: 1,
                is_offline: 1,
                id: ID
            },
            include: [{
                model: Dict,
                as: 'tagTable',
                attributes: []
            }],
            raw: true
        })
    }

    // 增加文章(直接更新为发布状态)
    addArticle(model) {
        return Article.checkModel(model, articleFields)
            .then(async() => {
                model.id = await getUniqueId();
                model.check_status = 20;
                model.status = 1;
                model.is_offline = 1;
                model.pubdate = new Date();
                return Article.create(model);
            })
    }


    // =========================文章打赏==============================

    /**
     * 打赏文章
     * @param {Object} model
     */
    rewardArticle(model, options) {
        return ArticleGift.checkModel(model, giftFields)
            .then(() => {
                return this.isExistGift(model.a_id)
                    .then(isExist => {
                        if (isExist) {
                            return this.updateGift(model, options);
                        } else {
                            return this.addGift(model, options);
                        }
                    })
            });
    }

    /**
     * 判断文章是否打赏过
     * @param {Number} a_id
     */
    isExistGift(a_id) {
        return ArticleGift.findOne({
            where: {
                a_id: a_id
            }
        }).then(data => {
            return !!data;
        })
    }

    /**
     * 增加打赏
     * @param {Object} model
     */
    addGift(model, options) {
        return ArticleGift.checkModel(model, giftFields)
            .then(async() => {
                model.id = await getUniqueId();
                model.times = 1;
                return ArticleGift.create(model, options);
            })
    }

    /**
     * 获取文章打赏次数和金额
     * @param {Number} a_id
     */
    getTimesAndMoney(a_id) {
        return ArticleGift.findOne({
            attributes: ['times', 'money'],
            where: {
                a_id: a_id
            }
        }).then(data => {
            return (data && data.get({
                plain: true
            })) || {};
        })
    }

    /**
     * 修改打赏信息
     * @param {Object} model
     */
    async updateGift(model, options) {
        let oldInfo = await this.getTimesAndMoney(model.a_id);
        model.times = oldInfo.times + 1;
        model.money += oldInfo.money;
        model.updated_at = new Date();
        return ArticleGift.update(model, Object.assign({
            where: {
                a_id: model.a_id
            }
        }, options)).then(data => {
            if (data[0] == 1) {
                return true;
            } else {
                throw {
                    message: '修改打赏信息失败'
                }
            }
        });
    }

    /**
     * 更新订单支付状态并更新文章打赏表
     * @param {Object} params
     */
    setOrderStatus(params) {
        return sequelize.transaction(t => {
            return orderService.updateStatus(params, {
                transaction: t
            }).then(_status => {
                if (_status == 1) {
                    return orderService.getOrderByID(params.id, {
                            transaction: t
                        })
                        .then(model => {
                            return this.rewardArticle({
                                a_id: model.plate_id,
                                money: model.money
                            }, {
                                transaction: t
                            }).then(() => _status);
                        })
                }
                return _status;
            })
        })
    }
}

export default new ArticleService();
