import Sequelize from 'sequelize';
import { PlateEstater, EstaterDynamic, CompanyBasic } from '../model';

class EstaterService {
    /**
     * 获取地产人动态
     * @param {Object} param0 
     */
    getDynamicList({page, pageSize}) {
        return EstaterDynamic.pagingQuery(page, pageSize, {
            attributes: ['id', 'plate_company_id', 'rel_date', 'dynamic_content'],
            where: {
                status: 1,
                is_offline: 1,
                '$and': [                    
                    Sequelize.where(Sequelize.col('plate_estater.status'), '=', 1),
                    Sequelize.where(Sequelize.col('plate_estater.is_offline'), '=', 1)
                ]
            },
            order: [
                ['rel_date', 'DESC'],
                ['pubdate', 'DESC']
            ],
            include: [{
                model: PlateEstater,
                attributes: [],
                duplicating: false
            }]
        })
    }

    getPagingBase() {
        return {
            attributes: ['id', 'name', 'avatar', 'introduce', 'job_position', 'company', [Sequelize.col('company_basic.name'), 'real_company']],
            where: {status: 1, is_offline: 1},
            order: [
                ['sort_order', 'DESC'],
                ['pubdate', 'DESC']
            ],
            include: [{
                model: CompanyBasic,
                attributes: [],
                duplicating: false
            }]
        }
    }

    /**
     * 获取地产人列表
     * @param {Object} param0 
     */
    getEstaterList({page, pageSize}) {
        let options = this.getPagingBase();

        return PlateEstater.pagingQuery(page, pageSize, options)
            .then(result => {
                if (Array.isArray(result.list)) {
                    result.list.forEach((item, i, arr) => {
                        arr[i] = item.get({plain: true});
                        arr[i].job_position && (arr[i].job_position = arr[i].job_position.split(',')[0]);
                    })
                }
                return result;
            });
    }

    /**
     * 根据id获取地产人详情
     * @param {number} id 
     */
    getDetailsById(id) {
        return PlateEstater.findOne({
            attributes: ['id', 'name', 'avatar', 'introduce', 'job_position', 'company', [Sequelize.col('company_basic.name'), 'real_company']],
            where:{
                id: id
            },                       
            order: [
                [Sequelize.col('dynamics.rel_date'), 'DESC'],
                [Sequelize.col('dynamics.pubdate'), 'DESC']
            ],
            include: [{
                model: EstaterDynamic,
                as: 'dynamics',
                attributes: ['id', 'rel_date', 'dynamic_content', 'rel_link'],
                on: {
                    plate_company_id: {$eq: Sequelize.col('plate_estater.id')},
                    status: {$eq: 1},
                    is_offline: {$eq: 1}
                },
                duplicating: false 
            }, {
                model: CompanyBasic,
                attributes: [],
                duplicating: false 
            }]
        }).then(data => {
            if (data) {
                data = data.get({plain: true});
                data.job_position && (data.job_position = data.job_position.split(',')[0]);
            }
            return data;
        })
    }

    /**
     * 根据关键字查询地产人
     * @param {String} keyword
     */
    search(keyword) {
        return PlateEstater.findAll({
            attributes: ['id', 'name'],
            where: {
                status: 1, 
                is_offline: 1,
                name: {$like: '%' + keyword + '%'}
            }
        })
    }

    /**
     * 根据关键字查询地产人(分页)
     * @param {*} param0 
     */
    searchPaging({page, pageSize, keyword}) {
        let options = this.getPagingBase();
        options.where.name = {$like: '%' + keyword + '%'};

        return PlateEstater.pagingQuery(page, pageSize, options)
            .then(result => {
                if (Array.isArray(result.list)) {
                    result.list.forEach((item, i, arr) => {
                        arr[i] = item.get({plain: true});
                        arr[i].job_position && (arr[i].job_position = arr[i].job_position.split(',')[0]);
                    })
                }
                return result;
            });;
    }

    /**
     * 根据id获取地产人信息
     * @param {*} ID 
     */
    getEstaterByID(ID) {
        return PlateEstater.findOne({
            attributes: ['id', 'name', 'avatar', 'introduce', 'job_position', 'company', [Sequelize.col('company_basic.name'), 'real_company']],
            where: {status: 1, is_offline: 1, id: ID},
            include: [{
                model: CompanyBasic,
                attributes: [],
                duplicating: false
            }]
        }).then(data => {
            if (data) {
                data = data.get({plain: true});
                data.job_position && (data.job_position = data.job_position.split(',')[0]);
            }
            return data;
        })
    }
}

export default new EstaterService();