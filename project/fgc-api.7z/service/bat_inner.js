// 用户头像本地存储批处理代码

var co = require('co')
var OSS = require('ali-oss')
var request = require('request')

// npm install co ali-oss request

// var OSSConfig = {
//   region: process.env.aliOssRegion || 'oss-cn-beijing',
//   accessKeyId: process.env.aliOssAccessKeyId || 'LTAITrE7L8rNTN8k',
//   accessKeySecret: process.env.aliOssAccessKeySecret || 'LYsICBPmcecaDsogD38R3K2osy0iKF',
//   bucket: process.env.aliOssBucket || 'fangguancha-img'
// }

var OSSConfig = {
  region: process.env.aliOssRegion || 'oss-cn-beijing',
  accessKeyId: process.env.aliOssAccessKeyId || 'LTAITrE7L8rNTN8k',
  accessKeySecret: process.env.aliOssAccessKeySecret || 'LYsICBPmcecaDsogD38R3K2osy0iKF',
  bucket: process.env.aliOssBucket || 'fangguancha-img'
}

var fgcImgHost = process.env.fgcImgHost || 'https://img1.fangguancha.com';//图片服务器地址

var client = new OSS({
  region: OSSConfig.region,
  accessKeyId: OSSConfig.accessKeyId,
  accessKeySecret: OSSConfig.accessKeySecret,
  bucket: OSSConfig.bucket
});

// 异步下载用户头像，保存至oss
function asyncDownAvatar({thumb, u_id}){
  request(thumb).on('response', (response) => {
    co(function* () {
      let fileName = '/images/avatar/' + u_id + '_' + Math.floor(Math.random() * 1000000) + '.jpg'
      let result = yield client.putStream(fileName, response, {timeout: 30 * 60 * 1000});
      // console.log(result);
      console.log('url:', fgcImgHost + result.name)
    }).catch(err => {
      console.log('err in func asyncDownAvatar: ')
      console.warn(err);
    });
  });
}


asyncDownAvatar({
  u_id: '15102894506989',
  thumb: 'https://wx.qlogo.cn/mmopen/vi_32/MicF1Sut8xX8Nw10VvibjYfeghObXVv503CgX45Szxdz8jI9EVLSTFgriaQalKJq8QQQFYWpLfiaAn7ZUvaKuHX5VQ/0'
})