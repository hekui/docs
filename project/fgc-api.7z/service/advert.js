import sequlize from '../model/instance'
class Advert {
  /**
   * 单个图片广告
   * @param {string} positionCode
   */
  Image({positionCode, city_code}){
    // select id, title, activity_img, relation_url, start_time, end_time, `status`, created_at, updated_at from content_advert 
    // where status = 1 and start_time < now() and end_time > NOW() and activity_position = (select code from content_position where code = 500002001)
    // order by sort_order desc, start_time asc
    // limit 1
    let sql = "select id, title, activity_img, relation_url, start_time, end_time, `status`, created_at, updated_at from content_advert where city_code = '"+ city_code +"' and status = 1 and start_time < now() and end_time > NOW() and activity_position = (select code from content_position where city_code = '"+ city_code +"' and code = "+ positionCode +") order by sort_order desc, start_time asc"
    return sequlize.query(sql).spread(res => {
      return res
    })
  }

  /**
   * 文章详情页大小图广告 - 该接口 positionCode 是写死的
   */
  ArticleBottomImage({ city_code }){
    let sql = "select id, title, activity_img, relation_url, start_time, end_time, `status`, created_at, updated_at from content_advert where city_code = '"+ city_code +"' and status = 1 and activity_position in (select code from content_position where city_code = '"+ city_code +"' and code in (500002004, 500002005)) and start_time < now() and end_time > NOW() order by sort_order desc, start_time asc limit 1"
    return sequlize.query(sql).spread(res => {
      if(res.length > 0){
        return res[0]
      } else {
        return {}
      }
    })
  }
}

export default new Advert()