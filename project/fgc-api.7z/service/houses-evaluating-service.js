import Sequelize from 'sequelize';
import { HousesEvaluating, EvaluationResult, PlateCompany, PlateLandTran, Dict, PropertyYq, CompanyIllegal, HousesRights, HousesScore, HousesBasic, PlateProperty } from '../model';

class EvaluatingService {    
    /**
     * 根据楼盘id获取公司评测信息
     * @param {Number} houseID
     * @param {Number} companyID
     */
    getCompanyEvaluation(houseID, companyID) {
        return Promise.all([
            this.getCompanyDebt(companyID),
            this.countLand(companyID),
            HousesEvaluating.findOne({
                attributes: [[Sequelize.col('result.score_company'), 'score'], 'score_liabilities', 'share_liabilities', 'score_buildinglands', 'share_buildinglands'],
                where: {
                    h_id: houseID
                },
                include: [{
                    model: EvaluationResult,
                    as: 'result',
                    attributes: []
                }]
            })
        ]).then(result => {
            let data = (result[2] && result[2].get({plain: true})) || {};
            data.debt = result[0];
            data.landNum = result[1];
            data.share_liabilities = data.share_liabilities || data.score_liabilities;
            data.share_buildinglands = data.share_buildinglands || data.score_buildinglands;
            return data;
        })
    }

    /**
     * 获取行业标准分
     */
    getStandardScore() {
        return HousesScore.findOne({
            attributes: ['com_score', 'com_show', 'pdu_score', 'pdu_show', 'pty_score', 'pty_show', 'mou_score', 'mou_show'],
        }).then(data => {
            data = (data && data.get({plain: true})) || {};
            data.com_show = data.com_show || data.com_score;
            data.pdu_show = data.pdu_show || data.pdu_score;
            data.pty_show = data.pty_show || data.pty_score;
            data.mou_show = data.mou_show || data.mou_score;
            return data;
        })
    }

    /**
     * 获取公司负债率
     * @param {Number} companyID
     */
    getCompanyDebt(companyID) {
        return PlateCompany.findOne({
            attributes: ['debt'],
            where: {
                company_id: companyID,
                status: 1,
                is_offline: 1
            }
        }).then(data => {
            if (data) {
                data = data.get({plain: true});
            }
            return (data && data.debt) || '';
        })
    }

    /**
     * 统计公司拿地数量
     * @param {Number} companyID
     */
    countLand(companyID) {
        return PlateLandTran.count({
            where: {
                get_company_id: companyID,
                status: 1,
                is_offline: 1
            }
        })
    }

    /**
     * 根据区域ID获取区域信息
     */
    getRegionName(regionID) {
        return Dict.findOne({
            attributes: [[Sequelize.literal('CONCAT_WS("-", `parent`.`name` , `sys_dict`.`name`)'), 'regionName']],
            where: {status: 1, id: regionID},
            include: [{
                model: Dict,
                as: 'parent',
                attributes: []
            }]
        }).then(data => {
            if (data) {
                data = data.get({plain: true});
            }
            return (data && data.regionName) || '';
        })
    }

    /**
     * 根据id范围获取从字典里获取名字
     */
    getDictNames(range) {
        return Dict.findAll({
            attributes: ['name'],
            where: {
                status: 1,
                id: {$in: range}
            }
        });
    }

    /**
     * 获取产品评测信息
     * @param {Number} houseID
     * @param {Number} regionID
     */
    getProductEvaluation(houseID, regionID) {
        return Promise.all([
            this.getRegionName(regionID),
            HousesEvaluating.findOne({
                attributes: [ [Sequelize.col('result.score_product'), 'score'], 'score_areascore', 'share_areascore', 'lfdesign_code', 'lfdesign_des', 'score_lfdesign', 'share_lfdesign', 'layoutdesign_code', 'layoutdesign_des', 'share_layoutdesign',
                    'sales_area', 'sales_num', 'sales_order', 'score_sales', 'share_sales'],
                where: {
                    h_id: houseID
                },
                include: [{
                    model: EvaluationResult,
                    as: 'result',
                    attributes: []
                }]
            })
        ]).then(async result => {
            let data = (result[1] && result[1].get({plain: true})) || {};
            data.regionName = result[0];
            if ((typeof data.layoutdesign_code == 'string') && data.layoutdesign_code.length) {
                try {
                    data.layoutDesign = await this.getDictNames(JSON.parse(data.layoutdesign_code));
                } catch(e) {
                    throw e;
                }
            }
            if ((typeof data.lfdesign_code == 'string') && data.lfdesign_code.length) {
                try {
                    data.lfDesign = await this.getDictNames(JSON.parse(data.lfdesign_code));
                } catch(e) {
                    throw e;
                }
            }
            data.share_areascore = data.share_areascore || data.score_areascore;
            data.share_lfdesign = data.share_lfdesign || data.score_lfdesign;
            data.share_sales = data.share_sales || data.score_sales;
            return data;
        })
    }

    /**
     * 根据物业公司id统计舆情
     * @param {Number} property_id 
     */
    countYq(property_id) {
        return PropertyYq.count({
            where: {
                status: 1,
                is_offline: 1,
                property_id: property_id
            }
        })
    }

    /**
     * 获取最新舆情信息
     * @param {Number} property_id
     */
    getNewYq(property_id) {
        return PropertyYq.findAll({
            attributes: ['content'],
            where: {
                status: 1,
                is_offline: 1,
                property_id: property_id
            },
            order: 'pubdate DESC',
            limit: 1
        }).then(data => {
            let result = (data[0] && data[0].get({plain: true})) || {};
            return result.content || '';
        })
    }

    /**
     * 获取物业评测信息
     * @param {Number} houseID
     */
    getPropertyEvaluation(houseID) {
        return HousesEvaluating.findOne({
            attributes: [[Sequelize.col('result.score_property'), 'score'], 'property_id', 'property_name', [Sequelize.col('plate_property.sys_dict.name'), 'qualified'], 'score_property', 'share_property', 'score_propertyyq', 'share_propertyyq'],
            where: {
                h_id: houseID
            },
            include: [{
                model: EvaluationResult,
                as: 'result',
                attributes: []
            }, {
                model: PlateProperty,
                attributes: [],
                include: [{
                    model: Dict,
                    attributes: [] 
                }]
            }]
        }).then(async data => {
            data = (data && data.get({plain: true})) || {};
            data.newYq = await this.getNewYq(data.property_id);
            data.propertyyq_num = await this.countYq(data.property_id);
            data.share_property = data.share_property || data.score_property;
            data.share_propertyyq = data.share_propertyyq || data.score_propertyyq;
            return data;
        })
    }

    /**
     * 根据公司ID统计违法违纪数量
     * @param {Number} companyID 
     */
    countIllegal(companyID) {
        return CompanyIllegal.count({
            where: {
                status: 1,
                is_offline: 1
            },
            include: [{
                model: PlateCompany,
                attributes: [],
                where: {
                    company_id: companyID
                }
            }]
        })
    }
    
    /**
     * 获取最新的违法违纪信息
     * @param {Number} companyID
     */
    getNewIllegal(companyID) {
        return CompanyIllegal.findAll({
            attributes: ['content'],
            where: {
                status: 1,
                is_offline: 1
            },
            order: [
                [Sequelize.col('plate_company_illegal.pubdate'), 'DESC']
            ],
            limit: 1,
            include: [{
                model: PlateCompany,
                attributes: [],
                where: {
                    company_id: companyID
                }
            }]
        }).then(data => {
            let result = (data[0] &&  data[0].get({plain: true})) || {};
            return result.content || '';
        })
    }

    /**
     * 根据楼盘ID统计维权条数
     * @param {*} h_id 
     */
    countRights(h_id) {
        return HousesRights.count({
            where: {
                h_id: h_id
            }
        })
    } 

    /**
     * 获取最新维权内容
     * @param {Number} houseID
     */
    getNewRights(houseID) {
        return HousesRights.findAll({
            attributes: ['content'],
            where: {
                h_id: houseID
            },
            order: 'rights_at DESC',
            limit: 1
        }).then(data => {
            let result = (data[0] && data[0].get({plain: true})) || {};
            return result.content || '';
        })
    }

    /**
     * 获取口碑评测信息
     * @param {Number} houseID
     * @param {Number} companyID
     */
    getReputationEvaluation(houseID, companyID) {
        return HousesEvaluating.findOne({
            attributes: [[Sequelize.col('result.score_reputation'), 'score'], 'score_illegal', 'share_illegal', 'score_rights', 'share_rights'],
            where: {
                h_id: houseID
            },
            include: [{
                model: EvaluationResult,
                as: 'result',
                attributes: []
            }]
        }).then(async data => {
            data = (data && data.get({plain: true})) || {};
            data.illegal_num = await this.countIllegal(companyID);
            data.rights_num = await this.countRights(houseID);
            data.illegal_content = await this.getNewIllegal(companyID);
            data.rights_content = await this.getNewRights(houseID);
            data.share_illegal = data.share_illegal || data.score_illegal;
            data.share_rights = data.share_rights || data.score_rights;
            return data;
        })
    }

    /**
     * 获取楼盘名和数据来源
     */
    getBaseInfo(h_id) {
        return HousesEvaluating.findOne({
            attributes: [[Sequelize.col('houses_basic.name'), 'name'], 'data_sources'],
            where: {
                h_id: h_id
            },
            include: [{
                model: HousesBasic,
                attributes: []
            }]
        })
    }

    /**
     * 获取所有维度的评测报告
     */
    getAllEvaluation({houseID, companyID, regionID}) {
        return Promise.all([
            this.getCompanyEvaluation(houseID, companyID),
            this.getProductEvaluation(houseID, regionID),
            this.getPropertyEvaluation(houseID),
            this.getReputationEvaluation(houseID, companyID),
            this.getBaseInfo(houseID),
            this.getStandardScore()
        ]).then(result => {
            let standardMap = result[5];
            result[0].standardScore = standardMap.com_show;
            result[1].standardScore = standardMap.pdu_show;
            result[2].standardScore = standardMap.pty_show;
            result[3].standardScore = standardMap.mou_show;
            result.pop();
            return result;
        })
    }

    /**
     * 获取维权信息报表
     * @param houseID
     * @returns {*}
     */
    getRightsLists({page,pageSize,houseID}){
        return HousesRights.pagingQuery(page,pageSize,{
            attributes:["id","content","rights_at"],
            where:{h_id:houseID},
            order:[
                ["updated_at","DESC"]
            ]
        })
    }

    /**
     * 获取违法信息报表
     * @param companyID
     * @returns {*} illegal_type:1严重违法 2普通违法
     */
    getIllegalLists({page,pageSize,companyID}){
        return CompanyIllegal.pagingQuery(page,pageSize,{
            attributes:["id","content","illegal_type","relation_date"],
            where: {
                status: 1,
                is_offline: 1
            },
            order: [
                [Sequelize.col('plate_company_illegal.pubdate'), 'DESC']
            ],
            include: [{
                model: PlateCompany,
                attributes: [],
                where: {
                    company_id: companyID
                }
            }]
        })
    }
    /**
     * 获取舆情信息报表
     * @param property_id
     * @returns {*}
     */
    getYqList({page,pageSize,property_id}) {
        return PropertyYq.pagingQuery(page,pageSize,{
            attributes: ['content',"relation_date"],
            where: {
                status: 1,
                is_offline: 1,
                property_id: property_id
            },
            order: 'relation_date DESC'
        })
    }

}

export default new EvaluatingService();