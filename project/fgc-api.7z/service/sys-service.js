import sequlize from '../model/instance'

class SysService {
  // 城市列表
  List(param){
    // 原始sql
    // status: 1正常0删除2禁用
    // select * from sys_city where status = 1 ORDER BY created_at asc
    let sqlList = 'select * from sys_city where status = 1 ORDER BY created_at desc;'
    return sequlize.query(sqlList).spread(res => {
      return res;
    })
  }

}

export default new SysService()
