import { BbsRead } from '../model';
import { getUniqueId } from './utils/sequence';
let fields = ['u_id'];

class BBSReadService {
    /**
     * 增加阅读记录
     * @param {Number} u_id
     */
    async addRead(u_id) {
        let id = await getUniqueId();
        return BbsRead.create({
            id: id,
            u_id: u_id
        }).then(data => {
            if (data) {
                return data;
            } 
            throw {message: '增加阅读记录失败'};
        })
    }

    /**
     * 更新阅读状态
     */
    updateRead(u_id, is_read) {
        return BbsRead.update({
            is_read: is_read,
            updated_at: new Date()
        }, {
            where: {
                u_id: u_id
            }
        }).then(data => {
            if (data[0] == 1) {
                return true;
            }
            throw {message: '更新阅读状态失败'};
        })
    }

    /**
     * 判断是否已存在该用户的记录
     */
    exists(u_id) {
        return BbsRead.findOne({
            where: {
                u_id: u_id
            }
        }).then(data => {
            return !!data;
        })
    }

    /**
     * 设置用户的阅读状态
     */
    setReadStatus(u_id, is_read) {
        return this.exists(u_id)
                .then(isExist => {
                    if (isExist) {
                        return this.updateRead(u_id, is_read);
                    } else {
                        return this.addRead(u_id);
                    }
                })
    }
}

export default new BBSReadService();