import Sequelize from 'sequelize';
import { ContentReport, Dict, ReportElement, Analysts, Resource, Order, UReportEmail } from '../model';
import orderService from './order-service';
import { getUniqueId } from './utils/sequence';
import { sendReportEmail } from './utils/sendEmail';

// 行业报告列表所需字段
let baseOption = {
    attributes: ['id', 'title', 'description', 'list_cover', 'pv_num', 'pv_num_basic', 'money', [Sequelize.col('sys_dict.name'), 'type'], [Sequelize.col('sys_dict.id'), 'typeId']],
    include: [{
        model: Dict,
        attributes: []
    }],
    raw: true
}

class ReportService {
    /**
     * 根据筛选条件获取行业报告列表
     * @param {*} param0 (typeID: 报告分类; charge: 1免费，2付费)
     */
    getList({city_code, page, pageSize, typeID, charge}) {
        let condition = {
            status: 1,
            city_code,
        }
        typeID && (condition.column = typeID);
        if (charge) {
            condition.money = charge == 1 ? {
                $or: [{$eq: null}, {$eq: 0}]
            } : {
                $and: [{$not: null}, {$ne: 0}]
            }
        }
        return ContentReport.pagingQuery(page, pageSize, Object.assign({}, baseOption, {
            where: condition,
            order: [
                ['online_date', 'DESC'],
                ['pv_num', 'DESC']
            ]
        })).then(result => {
            this.processCharge(result.list);
            return result;
        })
    }

    /**
     * 行业报告结果增加收费类型
     * @param {Array|Object} arr
     */
    processCharge(arr) {
        if (Array.isArray(arr)) {
            arr.forEach((v, i, a) => {
                // a[i] = v.get({plain: true});
                a[i].chargeType = a[i].money ? '付费' : '免费'
            })
        } else if (typeof arr == 'object') {
            arr.chargeType = arr.money ? '付费' : '免费'
        }
    }

    /**
     * 根据关键字搜索行业报告标题
     * @param {String} keyword
     */
    search({city_code, keyword}) {
        return ContentReport.findAll({
            attributes: ['id', 'title'],
            where: {
                city_code,
                status: 1,
                title: {$like: '%' + keyword + '%'}
            },
            order: [
                ['online_date', 'DESC'],
                ['pv_num', 'DESC']
            ]
        })
    }

    /**
     * 根据关键字搜索行业报告（分页）
     * @param {*} param0
     */
    searchPaging({city_code, page, pageSize, keyword}) {
        return ContentReport.pagingQuery(page, pageSize, Object.assign({}, baseOption, {
            where: {
                city_code,
                status: 1,
                title: {$like: '%' + keyword + '%'}
            },
            order: [
                ['online_date', 'DESC'],
                ['pv_num', 'DESC']
            ]
        })).then(result => {
            this.processCharge(result.list);
            return result;
        })
    }

    /**
     * 根据ID搜索行业报告
     * @param {Number} ID
     */
    searchSingle(ID) {
        return ContentReport.findOne(Object.assign({}, baseOption, {
            where: {
                status: 1,
                id: ID
            }
        })).then(data => {
            if (data) {
                // data = data.get({plain: true});
                this.processCharge(data);
            }
            return data;
        })
    }

    /**
     * 获取行业报告浏览量
     * @param {Number} ID
     */
    getPvNum(ID) {
        return ContentReport.findById(ID, {
            attributes: ['pv_num']
        }).then(data => {
            data = (data && data.get({plain: true})) || {};
            return data.pv_num || 0;
        })
    }

    /**
     * 更新行业报告浏览量（不需要判断是否更新成功）
     * @param {Number} ID
     */
    async updatePvNum(ID) {
        let pvNum = await this.getPvNum(ID);
        return ContentReport.update({
            pv_num: pvNum + 1,
            updated_at: new Date()
        }, {
            where: {
                id: ID
            }
        })
    }

    /**
     * 获取发布时间最新的x条行业报告数据
     */
    getLimitList({city_code}) {
        return ContentReport.findAll({
            attributes: ['id', 'title'],
            where: {
                city_code,
                status: 1
            },
            order: [
                ['online_date', 'DESC'],
                ['pv_num', 'DESC']
            ],
            limit: 5
        })
    }

    /**
     * 根据plate_id获取行业报告详情
     * @param {Number} u_id
     * @param {Number} plate_id
     */
    getDetailByID({u_id, plate_id, isPreview}) {
        return orderService.isExist(u_id, plate_id, 'ContentReport', 2)
            .then(isExist => {
                let condition = null, outerCondition = { id: plate_id };
                if (!isExist) {
                    condition = { is_pay: 0 }
                }
                if (!isPreview) {
                    outerCondition.status = 1;
                }
                return ContentReport.findOne({
                    attributes: ['id', 'title', 'description', 'list_cover', 'money', 'analysiser', 'statement_code', 'column', 'pv_num', 'pv_num_basic', 'online_date', 'city_code'],
                    include: [{
                        model: ReportElement,
                        as: 'details',
                        attributes: ['id', 'content', 'sort_order', 'type', 'whenlong', 'is_pay'],
                        where: condition,
                        required: false
                    }],
                    where: outerCondition,
                    order: [
                        [Sequelize.col('details.sort_order'), 'ASC']
                    ]
                }).then(async data => {
                    if (data) {
                        data = data.get({plain: true});
                        data.pv_num += data.pv_num_basic;
                        delete data.pv_num_basic;
                        if (data.analysiser) {
                            data.analysts = await this.getAnalysts(data.city_code, data.analysiser.split(','));
                        }
                        if (data.statement_code) {
                            data.statements = await this.getStatement(data.city_code, data.statement_code.split(','));
                        }
                        if (data.online_date != '0000-00-00 00:00:00') {
                            data.prev = await this.getPrevReport(data.city_code, data.column, data.online_date);
                            data.next = await this.getNextReport(data.city_code, data.column, data.online_date);
                        }
                        data.isPaid = isExist;
                    }
                    return data;
                });
            })
    }

    /**
     * 根据id数组查询分析师
     * @param {Array} ids
     */
    getAnalysts(city_code, ids) {
        return Analysts.findAll({
            attributes: ['id', 'name', 'describe', 'head_img'],
            where: {                
                city_code,
                id: {$in: ids}
            }
        })
    }

    /**
     * 根据code获取声明
     * @param {Array} codes
     */
    getStatement(city_code, codes) {
        return Resource.findAll({
            attributes: ['id', 'name', 'content'],
            where: {
                city_code,
                type: 1,
                code: {$in: codes},
                status: 1
            }
        })
    }

    /**
     * 获取前一篇同类型的报告
     * @param {Number} column
     * @param {String} date
     */
    getPrevReport(city_code, column, date) {
        return ContentReport.findOne({
            attributes: ['id', 'title'],
            where: {
                city_code,
                status: 1,
                column: column,
                online_date: {$lt: new Date(date)}
            },
            order: 'online_date DESC'
        })
    }

    /**
     * 获取后一篇同类型的报告
     * @param {Number} column
     * @param {String} date
     */
    getNextReport(city_code, column, date) {
        return ContentReport.findOne({
            attributes: ['id', 'title'],
            where: {
                city_code,
                status: 1,
                column: column,
                online_date: {$gt: new Date(date)}
            },
            order: 'online_date ASC'
        })
    }

    /**
     * 根据关键字搜索两个行业报告
     * @param {String} keyword
     */
    searchForHome({city_code, keyword}) {
        return ContentReport.findAll(Object.assign({}, baseOption, {
            where: {
                city_code,
                status: 1,
                $or: [{
                    title: {$like: '%' + keyword + '%'}
                }, {
                    description: {$like: '%' + keyword + '%'}
                }]
            },
            order: [
                ['online_date', 'DESC'],
                ['pv_num', 'DESC']
            ],
            limit: 3
        })).then(result => {
            this.processCharge(result);
            return result;
        })
    }

    /**
     * 获取用户购买过的行业报告
     * @param {*} param0
     */
    getPaidReports({page, pageSize, u_id}) {
        return ContentReport.pagingQuery(page, pageSize, {
            attributes: ['id', 'title', 'description', 'list_cover', 'pv_num', 'pv_num_basic', 'money', [Sequelize.col('sys_dict.name'), 'type'], [Sequelize.col('sys_dict.id'), 'typeId']],
            include: [{
                model: Dict,
                attributes: []
            }, {
                model: Order,
                attributes: [],
                duplicating: false
            }],
            where: {
                status: 1,
                $and: [
                    Sequelize.where(Sequelize.col('orders.plate'), '=', 'ContentReport'),
                    Sequelize.where(Sequelize.col('orders.u_id'), '=', u_id),
                    Sequelize.where(Sequelize.col('orders.status'), '=', 1),
                    Sequelize.where(Sequelize.col('orders.type'), '=', 2)
                ]
            },
            order: 'online_date DESC',
            raw: true
        }).then(result => {
            this.processCharge(result.list);
            return result;
        })
    }

    /**
     * 增加行业报告支付数
     * @param {Number} id
     */
     addPayNum(id) {
        return orderService.getPlateID(id)
            .then(async plate_id => {
                if (plate_id) {
                    let count = await orderService.countNum({
                        plate_id: plate_id,
                        plate: 'ContentReport',
                        type: 2
                    })
                    return ContentReport.update({
                        pay_num: count,
                        updated_at: new Date()
                    }, {
                        where: {
                            id: plate_id,
                            status: 1
                        }
                    })
                }
            })
    }

    /**
     * 获取邮箱录入次数
     * @param {*} param0
     */
     getReportEmail(model) {
        // model.u_id = 1
        return UReportEmail.findAll({
          where: {
            r_id: model.report_id,
            u_id: model.u_id
          }
        }).then(data => {
          return data
        })
    }

    /**
     * 增加邮箱获取报告
     * @param {*} param0
     */
     addEmail(model) {
        // model.u_id = 1
        return this.reportEmailCount({
            r_id: model.report_id,
            u_id: model.u_id
        }).then(async _count => {
          if(_count > 1){
            return 3
          } else {
            let id = await getUniqueId()
            return UReportEmail.create({
                id: id - 0,
                r_id: model.report_id,
                report_name: model.report_name,
                u_id: model.u_id,
                username: model.u_name,
                email: model.email
            }).then(_data => {
                // 发送邮件
                sendReportEmail(id)
                return _count + 1;
            })
          }
        })
    }

    /**
     * 查询报告 - 邮箱录入次数
     * @param {*} param0
     */
    reportEmailCount(model) {
        return UReportEmail.count({
            where: model
        }).then(_data => {
            return _data;
        })
    }

    /**
     * 报告 - 修改邮箱发送时间
     * @param {Number} id
     */
    updateEmailSendTime(id) {
        return UReportEmail.update({
            send_at: new Date()
        }, {
            where: {
                id: id
            }
        })
    }
}

export default new ReportService();
