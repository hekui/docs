// 用户头像本地存储批处理代码

var co = require('co')
var OSS = require('ali-oss')
var request = require('request')
var Sequelize = require('sequelize');

var dbConfig = {
  host: process.env.dbHost || '192.168.10.239',
  port: process.env.dbPort || 3306,
  database: process.env.dbDatabase || 'fgc',
  username: process.env.dbUsername || 'mylive',
  password: process.env.dbPassword || 'devsgo'
}

var OSSConfig = {
  region: process.env.aliOssRegion || 'oss-cn-beijing',
  accessKeyId: process.env.aliOssAccessKeyId || 'LTAITrE7L8rNTN8k',
  accessKeySecret: process.env.aliOssAccessKeySecret || 'LYsICBPmcecaDsogD38R3K2osy0iKF',
  bucket: process.env.aliOssBucket || 'fangguancha-img'
}

var fgcImgHost = process.env.fgcImgHost || 'https://img1.fangguancha.com';//图片服务器地址



const sequelize = new Sequelize(dbConfig.database, dbConfig.username, dbConfig.password, {
    host: dbConfig.host,
    port: dbConfig.port,
    dialect: 'mysql',

    pool: {
        max: 5,
        min: 0, 
        idle: 10000
    },

    define: {
        freezeTableName: true,
        timestamps: false
    },

    timezone: '0',

    logging: process.argv.indexOf('--production') > -1 ? false : console.log
    //logging:false
});

sequelize.authenticate().then(err => {
    console.log('Connection has been established successfully.')
}).catch(err => {
    console.log('Unable to connect to the database:', err);
});


var client = new OSS({
  region: OSSConfig.region,
  accessKeyId: OSSConfig.accessKeyId,
  accessKeySecret: OSSConfig.accessKeySecret,
  bucket: OSSConfig.bucket
});


var pullCount = 0


// 修改数据库：增加字段last_thumb存储上次下载的头像URL
// 获取用户头像，判断是否需要更新
function getOldAvatar({thumb, u_id}){
  // console.log('thumb', thumb)
  // console.log('u_id', u_id)
  if(thumb){
    let sql = `select last_thumb from x_info where id = ${u_id}`
    sequelize.query(sql).spread(res => {
      let last_thumb = res[0].last_thumb
      if(!last_thumb || last_thumb !== thumb){
        console.log('=====================need down')
        // pullNext()
        asyncDownAvatar({thumb, u_id})
      }else{
        console.log('---------------------skip')
        pullNext()
      }
    })
  }else{
    console.log('---------------------next')
    pullNext()
  }
}

// 异步下载用户头像，保存至oss
function asyncDownAvatar({thumb, u_id}){
  request(thumb).on('response', (response) => {
    co(function* () {
      let fileName = '/images/avatar/' + u_id + '_' + Math.floor(Math.random() * 1000000) + '.jpg'
      let result = yield client.putStream(fileName, response, {timeout: 30 * 60 * 1000});
      // console.log(result);
      pullCount += 1
      updateAvatar({
        u_id, thumb, 
        newThumb: fgcImgHost + result.name
      })
    }).catch(err => {
      console.log('err in func asyncDownAvatar: ')
      console.warn(err);
    });
  });
}

// 更新用户头像至数据库
function updateAvatar({newThumb, thumb, u_id}){
  let sql = `update x_info set thumb = '${newThumb}', last_thumb = '${thumb}' where id = ${u_id}`
  sequelize.query(sql).spread(res => {
    // console.log('updated')
    pullNext()
  })
}

// getOldAvatar({
//   u_id: '15102894506989',
//   thumb: 'https://wx.qlogo.cn/mmopen/vi_32/MicF1Sut8xX8Nw10VvibjYfeghObXVv503CgX45Szxdz8jI9EVLSTFgriaQalKJq8QQQFYWpLfiaAn7ZUvaKuHX5VQ/0'
// })

let dataList

function pullBat(){
  let sql = "select * from x_info order by id asc"
  sequelize.query(sql).spread(res => {
    dataList = res
    // console.log('dataList', dataList)
    pullNext()
    // dataList.forEach(item => {
    //   console.log(item.id, item.thumb)
    // })
  })
}

function pullNext(){
  let unit = dataList.pop()
  if(unit){
    console.log(unit.id, unit.thumb)
    getOldAvatar({
      u_id: unit.id,
      thumb: unit.thumb
    })
  }else{
    console.log('===================================================')
    console.log('finished')
    console.log('update count = ', pullCount)
  }
}

pullBat()