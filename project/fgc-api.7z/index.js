import path from 'path';
import express from 'express';
import bodyParser from 'body-parser';
// import session from 'express-session';
//import connectRedis from 'connect-redis';

import { port, redisConfig } from './config/sys.config';
import routes from './routes';

const app = express();
// var RedisStore = connectRedis(session);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
// app.use(session({
//     name: 'SSID',
//     secret: 'fgc',
//     resave: false,
//     saveUninitialized: true,
//     store: new RedisStore(redisConfig)
// }))

// let timer = null
// app.use(function(req, res, next){
//     if(!timer){
//         timer = setInterval(function(){
//             let memoryUsage = process.memoryUsage()
//             let n = 1024 * 1024
//             console.log('------------------------------------------------------------------------')
//             console.log('[进程常驻内存]memoryUsage.rss:\t\t', memoryUsage.rss / n + 'MB')
//             console.log('[已申请的堆内存]memoryUsage.heapTotal:\t', memoryUsage.heapTotal / n + 'MB')
//             console.log('[已使用的量]memoryUsage.heapUsed:\t', memoryUsage.heapUsed / n + 'MB')
//             console.log('[C++对象的内存]memoryUsage.external:\t', memoryUsage.external / n + 'MB')
//         }, 2000)
//     }
//     next()
// })

app.use((req, res, next)=> {
    console.log('url:', req.url)
    console.log('req.body.city_code', req.body)
    if(!req.body.city_code){
        req.body.city_code = '51010000'
    }
    next()
})
app.use('/', routes);

app.get('/', (req, res, next) => {
    let env = process.argv.indexOf('--production') > -1 ? 'production' : 'development';
    res.send(`hello fgc api ${env}!`);
})

// catch 404 and forward to error handler
app.use((req, res, next)=> {
    var err = new Error('资源没有找到');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (process.argv.indexOf('--production') < 0) {
    app.use((err, req, res, next)=> {
        res.status(err.status || 500);
        res.json({
            code: err.status || 500,
            msg: err.message
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use((err, req, res, next)=> {
    res.status(err.status || 500);
    res.json({
        code: err.status || 500,
        msg: "服务器内部错误"
    });
});

app.listen(port, () => {
    console.log(`==> Listening at http://localhost:${port}`);
});

module.exports = app;

