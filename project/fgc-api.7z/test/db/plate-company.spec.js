import should from 'should';
import { PlateCompany } from '../../model';

describe('test db', () => {
    describe('test plateCompany', () => {
        it ('paging query', () => {
            return PlateCompany.pagingQuery(1, 2, {
                where: {
                    name: {$like: '%司%'}
                }
            }).then(data => {
                data.should.be.Object();
                console.log('plateCompany paging: ', data);
            })
        })
    })
})
 