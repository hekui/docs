import request from 'supertest';
import should from 'should';

describe('/user/follow route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })


    it('POST /delete', done => {
        server.post('/user/follow/delete')
            .set('Accept', 'application/json')
            .send({
                plate_id: 1,
                u_id: 12
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('delete result: ', res.body);
                res.body.code.should.be.equal(200);
                done();
            })
    })

})
