import request from 'supertest';
import should from 'should';

describe('/exponent/district route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })

    describe('POST /getDynamic', () => {
        it('respond with json', done => {
            server.post('/exponent/district/getDynamic')
                .set('Accept', 'application/json')
                .expect(200)
                .end((err, res) => {
                    if (err) {
                        return done(err);
                    }
                    console.log('district dynamics: ', res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    })

    describe('POST /getDistrictList', () => {
        it('respond with json', done => {
            server.post('/exponent/district/getDistrictList')
                .set('Accept', 'application/json')
                .expect(200)
                .end((err, res) => {
                    if (err) {
                        return done(err);
                    }                    
                    console.log('district list: ', res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    })

})
