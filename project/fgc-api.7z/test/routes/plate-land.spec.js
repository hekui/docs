import request from 'supertest';
import should from 'should';

describe('/exponent/land route test',()=>{
   let server;
    before(() =>{
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    });
    describe('POST/getList',() =>{
        it('respond with json',done =>{
            server.post('/exponent/land/getList')
                .send({statu: 0,dateTime:'2017'})
                .set('Accept','application/json')
                .expect(200)
                .end((err,res) =>{
                    if(err){
                        return done(err);
                    }
                    console.log("land type:",res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    });
    // describe('POST/search',() =>{
    //     it('respond with json',done =>{
    //         server.post('/exponent/land/search')
    //             .send({keyword:"12"})
    //             .set('Accept','application/json')
    //             .expect(200)
    //             .end((err,res) =>{
    //                 if(err){
    //                     return done(err);
    //                 }
    //                 console.log("land type:",res.body);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // });
    // describe('POST/searchList',() =>{
    //     it('respond with json',done =>{
    //         server.post('/exponent/land/searchList')
    //             .send({keyword:"3123"})
    //             .set('Accept','application/json')
    //             .expect(200)
    //             .end((err,res) =>{
    //                 if(err){
    //                     return done(err);
    //                 }
    //                 console.log("land type:",res.body);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // });
});