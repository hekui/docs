import request from 'supertest';
import should from 'should';

describe('/exponent/policy route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })

    describe('POST /getList', () => {
        it ('get year data', done => {
            server.post('/exponent/policy/getList')
                .set('Accept', 'application/json')
                .send({date: '2016'})
                .expect(200)
                .end((err, res) => {
                    if (err) {
                        return done(err);
                    }                    
                    console.log('policy list: ', res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    })

})
