import request from 'supertest';
import should from 'should';
describe('/user/home route test',()=>{
    let server;
    before(() =>{
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    });
    describe('POST/getUser',() =>{
        it('respond with json',done =>{
            server.post('/user/home/getUser')
                .send({wx_openid:"12sdfsdf3",thumb:"dd",username:"ss"})
                .set('Accept','application/json')
                .expect(200)
                .end((err,res) =>{
                    if(err){
                        return done(err);
                    }
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    });
   /* describe('POST/getCount',() =>{
        it('respond with json',done =>{
            server.post('/user/home/getUser')
                .send({wx_openid:"123",thumb:"dd",username:"ss"})
                .set('Accept','application/json')
                .expect(200)
                .end((err,res) =>{
                    if(err){
                        return done(err);
                    }
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    });*/

});