import request from 'supertest';
import should from 'should';

describe('/bbs route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })
 
    // it('POST /getList', done => {
    //     server.post('/bbs/getList')
    //         .set('Accept', 'application/json')
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('post list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    it('POST /getPostById', done => {
        server.post('/bbs/getPostById')
            .set('Accept', 'application/json')
            .send({id: 14951775923378})
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('post detail: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    // it('POST /getComments', done => {
    //     server.post('/bbs/getComments')
    //         .set('Accept', 'application/json')
    //         .send({postID: 1, u_id: 58})
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('comment list: ', res.body.data);
    //             console.log('list length', res.body.data.list.length);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /followTopic', done => {
    //     let date = new Date();
    //     server.post('/bbs/followTopic')
    //         .set('Accept', 'application/json')
    //         .send({
    //             plate_id: 1,       
    //             u_id: Math.floor(Math.random() * 100),
    //             u_name: 'test',
    //             created_at: new Date()
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('follow topic result: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /likeComment', done => {
    //     let date = new Date();
    //     server.post('/bbs/likeComment')
    //         .set('Accept', 'application/json')
    //         .send({
    //             plate_id: 2,       
    //             u_id: Math.floor(Math.random() * 100),
    //             u_name: 'test'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('like comment result: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /unlikeComment', done => {
    //     let date = new Date();
    //     server.post('/bbs/unlikeComment')
    //         .set('Accept', 'application/json')
    //         .send({
    //             plate_id: 2,       
    //             u_id: 35
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('delete result: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /addComment', done => {
    //     let date = new Date();
    //     server.post('/bbs/addComment')
    //         .set('Accept', 'application/json')
    //         .send({
    //             post_id: 1,
    //             content: '测试评论',
    //             u_id: 14937799139537,
    //             u_name: '测试',
    //             u_avator: '无',
    //             tou_id: '14816832481601'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('add comment result: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /addTopic', done => {
    //     let date = new Date();
    //     server.post('/bbs/addTopic')
    //         .set('Accept', 'application/json')
    //         .send({
    //             title: '话题测试',
    //             content: '我我是话题我是话题我是话题是话题',
    //             u_id: Math.floor(Math.random() * 100),
    //             u_name: '测试',
    //             u_avator: '无'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('add topic result: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /search', done => {
    //     let date = new Date();
    //     server.post('/bbs/search')
    //         .set('Accept', 'application/json')
    //         .send({
    //             keyword: '话'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('search topic title: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /searchResult', done => {
    //     let date = new Date();
    //     server.post('/bbs/searchResult')
    //         .set('Accept', 'application/json')
    //         .send({
    //             keyword: '话'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('search topic result: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getComment', done => {
    //     server.post('/bbs/getComment')
    //         .set('Accept', 'application/json')
    //         .send({
    //             id: '14937933274228'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('get comment: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /addBack', done => {
    //     server.post('/bbs/addBack')
    //         .set('Accept', 'application/json')
    //         .send({
    //             post_id: 1,
    //             content: '测试回复',
    //             u_id: 14937800674108,
    //             u_name: '测试',
    //             u_avator: '无',
    //             to_id: '14937933274228',
    //             tou_id: 23
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('add back result: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })
    
    // it('POST /getBackList', done => {
    //     server.post('/bbs/getBackList')
    //         .set('Accept', 'application/json')
    //         .send({
    //             commentID: '14937933274228',
    //             u_id: 82
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('back list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

})
