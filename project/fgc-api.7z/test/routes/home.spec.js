import request from 'supertest';
import should from 'should';

describe('/home route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })
    
    // it('POST /getBanner', done => {
    //     server.post('/home/getBanner')
    //         .set('Accept', 'application/json')
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('banner list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getHouseList', done => {
    //     server.post('/home/getHouseList')
    //         .set('Accept', 'application/json')
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('houses list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    it('POST /search', done => {
        server.post('/home/search')
            .set('Accept', 'application/json')
            .expect(200)
            .send({keyword: '测'})
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('home search: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

})
