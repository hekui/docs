import request from 'supertest';
import should from 'should';

describe('/houses route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })

    // it('POST /getRegions', done => {
    //     server.post('/houses/getRegions')
    //         .set('Accept', 'application/json')
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('type list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getWarnList', done => {
    //     server.post('/houses/getWarnList')
    //         .set('Accept', 'application/json')
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('warn list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    it('POST /getList', done => {
        server.post('/houses/getList')
            .set('Accept', 'application/json')
            .send({
                regionId: 14829140304071,
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('ping ce list: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    // it('POST /search', done => {
    //     server.post('/houses/search')
    //         .set('Accept', 'application/json')
    //         .send({
    //             keyword: '测'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('search name list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    it('POST /searchResult', done => {
        server.post('/houses/searchResult')
            .set('Accept', 'application/json')
            .send({
                keyword: '测'
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('searchResult list: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    // it('POST /searchSingle', done => {
    //     server.post('/houses/searchSingle')
    //         .set('Accept', 'application/json')
    //         .send({
    //             id: 1
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('search single: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /detail', done => {
    //     server.post('/houses/detail')
    //         .set('Accept', 'application/json')
    //         .send({
    //             id: 14942145143831
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('house detail: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getEvaluation', done => {
    //     server.post('/houses/getEvaluation')
    //         .set('Accept', 'application/json')
    //         .send({
    //             houseID: 14942145143831,
    //             companyID: 14913810304121,
    //             regionID: 14942390578401
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('evaluation result: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getPrices', done => {
    //     server.post('/houses/getPrices')
    //         .set('Accept', 'application/json')
    //         .send({
    //             h_id: 14942145143831,
    //             name: '天府新区'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('prices result: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /addComment', done => {
    //     server.post('/houses/addComment')
    //         .set('Accept', 'application/json')
    //         .send({
    //             h_id: 14942145143831,
    //             content: '楼盘评论测试',
    //             com_score: 10,
    //             pdu_score: 20,
    //             pty_score: 30,
    //             mou_score: 40,
    //             u_id: 14817013256351,
    //             u_name: '匿名'
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('add houses comment: ', res.body);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getCommentScore', done => {
    //     server.post('/houses/getCommentScore')
    //         .set('Accept', 'application/json')
    //         .send({
    //             h_id: 14942145143831,
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('houses comment score: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })

    // it('POST /getCommentList', done => {
    //     server.post('/houses/getCommentList')
    //         .set('Accept', 'application/json')
    //         .send({
    //             h_id: 14942145143831,
    //         })
    //         .expect(200)
    //         .end((err, res) => {
    //             if (err) {
    //                 return done(err);
    //             }
    //             console.log('houses comment list: ', res.body.data);
    //             res.body.code.should.be.equal(200);
    //             done();
    //         })
    // })
})
