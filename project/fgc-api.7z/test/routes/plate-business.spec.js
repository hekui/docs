import request from 'supertest';
import should from 'should';

describe('/exponent/business route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })
 
    // describe('POST /getTypes', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/business/getTypes')
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }
    //                 console.log('business types: ', res.body);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /getDynamic', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/business/getDynamic')
    //             .send({typeId: 14817046998061})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }
    //                 console.log('business dynamics: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /getBusiness', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/business/getBusinessList')
    //             .send({typeId: 14817046998061})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('business list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

     describe('POST /getBusinessDetails', () => {
        it('respond with json', done => {
            server.post('/exponent/business/getBusinessDetails')
                .send({id: 14836923666191})
                .set('Accept', 'application/json')
                .expect(200)
                .end((err, res) => {
                    if (err) {
                        return done(err);
                    }                    
                    console.log('business details: ', res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    })

    // describe('POST /search', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/business/search')
    //             .send({keyword: 't'})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('search business: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /searchResult', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/business/searchResult')
    //             .send({name: '商业名称2'})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('business result list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

})
