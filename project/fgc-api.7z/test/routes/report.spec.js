import request from 'supertest';
import should from 'should';

describe('/report route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })

    it.skip('POST /getType', done => {
        server.post('/report/getType')
            .set('Accept', 'application/json')
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('report type: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /getList', done => {
        server.post('/report/getList')
            .set('Accept', 'application/json')
            .send({
                charge: 2
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('report list: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /search', done => {
        server.post('/report/search')
            .set('Accept', 'application/json')
            .send({
                keyword: '测'
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('search list: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /searchResult', done => {
        server.post('/report/searchResult')
            .set('Accept', 'application/json')
            .send({
                keyword: '测'
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('search result list: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /searchSingle', done => {
        server.post('/report/searchSingle')
            .set('Accept', 'application/json')
            .send({
                id: 111
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('search single: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /setPvNum', done => {
        server.post('/report/setPvNum')
            .set('Accept', 'application/json')
            .send({
                id: 112
            })
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('setPvNum: ', res.body);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /getScrollList', done => {
        server.post('/report/getScrollList')
            .set('Accept', 'application/json')
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('scroll list: ', res.body);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /getDetail', done => {
        server.post('/report/getDetail')
            .set('Accept', 'application/json')
            .expect(200)
            .send({
                plate_id: 111
            })
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('report detail: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /addOrder', done => {
        server.post('/report/addOrder')
            .set('Accept', 'application/json')
            .expect(200)
            .send({
                plate_id: 111,
                u_id: 111,
                money: 20
            })
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('add order: ', res.body);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it('POST /setOrderStatus', done => {
        server.post('/report/setOrderStatus')
            .set('Accept', 'application/json')
            .expect(200)
            .send({
                id: 14969018283217,
                status: 1
            })
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('set order: ', res.body);
                res.body.code.should.be.equal(200);
                done();
            })
    })

    it.skip('POST /getPaidList', done => {
        server.post('/report/getPaidList')
            .set('Accept', 'application/json')
            .expect(200)
            .send({
                u_id: 14969076788421
            })
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                console.log('paid reports: ', res.body.data);
                res.body.code.should.be.equal(200);
                done();
            })
    })

})
