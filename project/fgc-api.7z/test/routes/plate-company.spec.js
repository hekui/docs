import request from 'supertest';
import should from 'should';

describe('/exponent/company route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })
 
    // describe('POST /getTypes', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/company/getTypes')
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }
    //                 console.log('company types: ', res.body);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /getDynamic', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/company/getDynamic')
    //             .send({typeId: 14817044427771})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }
    //                 console.log('company dynamics: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /getCompany', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/company/getCompanyList')
    //             .send({typeId: 14817044427771})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('company list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

     describe('POST /getCompanyDetails', () => {
        it('respond with json', done => {
            server.post('/exponent/company/getCompanyDetails')
                .send({id: 14836853654571})
                .set('Accept', 'application/json')
                .expect(200)
                .end((err, res) => {
                    if (err) {
                        return done(err);
                    }                    
                    console.log('company details: ', res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    })

    // describe('POST /search', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/company/search')
    //             .send({keyword: '公'})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('search list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /searchResult', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/company/searchResult')
    //             .send({name: '公司名称'})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('company result list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

})
