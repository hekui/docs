import request from 'supertest';
import should from 'should';

describe('/exponent/estater route test', () => {  
    let server;

    before(() => {
        process.env.PORT = 3006;
        const app = require('../../index');
        server = request(app);
    })

    // describe('POST /getDynamic', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/estater/getDynamic')
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }
    //                 console.log('estater dynamics: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /getEstaterList', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/estater/getEstaterList')
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('estater list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

     describe('POST /getEstaterDetails', () => {
        it('respond with json', done => {
            server.post('/exponent/estater/getEstaterDetails')
                .send({id: 14836900089491})
                .set('Accept', 'application/json')
                .expect(200)
                .end((err, res) => {
                    if (err) {
                        return done(err);
                    }                    
                    console.log('estater details: ', res.body.data);
                    res.body.code.should.be.equal(200);
                    done();
                })
        })
    })

    // describe('POST /search', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/estater/search')
    //             .send({keyword: 't'})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('search estater: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

    // describe('POST /searchResult', () => {
    //     it('respond with json', done => {
    //         server.post('/exponent/estater/searchResult')
    //             .send({name: 'test'})
    //             .set('Accept', 'application/json')
    //             .expect(200)
    //             .end((err, res) => {
    //                 if (err) {
    //                     return done(err);
    //                 }                    
    //                 console.log('estater result list: ', res.body.data);
    //                 res.body.code.should.be.equal(200);
    //                 done();
    //             })
    //     })
    // })

})
