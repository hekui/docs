# fgc-api

## 安装
```
npm install
```

## 开发模式
```
npm run dev
```

## 生产模式
``` 
打包: npm run build
运行: npm run start  
```

## 环境变量
```
PORT:           服务端口号  
dbHost:         Mysql地址  
dbPort:         Mysql端口  
dbDatabase:     数据库名称  
dbUsername:     数据库用户名  
dbPassword:     数据库密码  

redisHost:      redis主机
redisPort:      redis端口
redisDB:        redis表
```