const Router = require('koa-router')
const router = new Router()
const api = require('./../api')
const axios = require('axios')

/**
 * 
 */
router.all('/', (ctx, next) => {
  // console.log('hello api xinchuan *', ctx.request.body)

  let labels = ctx.request.body.labels
  let gets = []
  
  ctx.request.url = '/content/labelcontentlist'
  labels.forEach(item => {
    gets.push(api.fetchJava(ctx, {
      labelId: item,
      curPage: 1,
      pageSize: 10
    }))
  })

  ctx.request.url = '/label/labellist'
  gets.push(api.fetchJava(ctx, {"cityId":51010000}))

  return axios.all(gets).then(res => {
    // console.log('res', res)
    let resLabel = res.pop().data.list
    // console.log('resLabel', resLabel)
    let results = []
    labels.forEach((item, index) => {
      let result = {
        labelId: item,
        labelName: '',
        data: res[index].data.list
      }
      
      resLabel.forEach(label => {
        if(label.id == item){
          result.labelName = label.name
          return 
        }
      })

      results.push(result)
    })
    
    ctx.body = {
      code: 0,
      data: results
    }
  }, res => {
    ctx.body = {
      code: 1,
      msg: '数据获取失败'
    }
  });
})

module.exports = router.routes()