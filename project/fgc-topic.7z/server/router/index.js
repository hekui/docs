const Router = require('koa-router')
const router = new Router()

const xinchuanRouter = require('./xinchuan')

router.use('/xinchuan', xinchuanRouter)

router.all('*', (ctx, next) => {
  console.log('hello api *', ctx.request.path)
  ctx.body = {
    msg: '不存在的接口'
  }
})

module.exports = router.routes()