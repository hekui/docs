
const
  javaHost = process.env.javaHost || 'http://mpweb.test1.fangguancha.com', // 测试环境
  // javaHost = process.env.javaHost || 'http://192.168.10.196:8087', // 周波电脑
  // javaHost = process.env.javaHost || 'http://192.168.10.88:8081', // 何洋
  // javaHost = process.env.javaHost || 'http://mock.maifangma.com', // rap2模拟数据
  // passportHost = process.env.passportHost || "http://uiap.test1.maifangma.com", // 登陆 测试环境
  // passportHost = process.env.passportHost || 'http://dev.passport.maifangma.com'
  passportHost = process.env.passportHost || 'http://192.168.10.88:8090' // 何洋电脑
  timeout = 5000; // 超时时间

module.exports = {
  javaHost,
  passportHost,
  timeout,
}
