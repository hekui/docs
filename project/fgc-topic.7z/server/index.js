const Koa = require('koa')
const serve = require('koa-static')
const Router = require('koa-router')
const koaBody = require('koa-body')
const session = require('koa-session')
const log = require('./log')('http')
const serverRouter = require('./router')

const app = new Koa()
const router = new Router()
const port = 3000
const maxage = 30 * 24 * 60 * 60 * 1000 // 30天

app.keys = ['some secret hurr'];
const sessionOptions = {
  key: 'FGCMPSSID', /** (string) cookie key (default is koa:sess) */
  /** (number || 'session') maxAge in ms (default is 1 days) */
  /** 'session' will result in a cookie that expires when session/browser is closed */
  /** Warning: If a session cookie is stolen, this cookie will never expire */
  maxAge: maxage,
  overwrite: true, /** (boolean) can overwrite or not (default true) */
  // httpOnly: true, /** (boolean) httpOnly or not (default true) */
  // signed: true, /** (boolean) signed or not (default true) */
  rolling: false, /** (boolean) Force a session identifier cookie to be set on every response. The expiration is reset to the original maxAge, resetting the expiration countdown. (default is false) */
  renew: false, /** (boolean) renew session when session is nearly expired, so we can always keep user logged in. (default is false)*/
};
app.use(session(sessionOptions, app))

app.use(koaBody())

app.use(async (ctx, next) => {
  const start = new Date()
  console.log('ctx.request.url', ctx.request.url)
  await next()
  const ms = new Date() - start
  // console.log('ctx.type', ctx.type)
  // html 取消缓存
  if(ctx.type === 'text/html'){
    ctx.set('Cache-Control', 'no-cache');
  }
  log.trace(`"${ctx.request.method} ${ctx.request.url}" ${ctx.status} ${ms}ms "${ctx.request.header['user-agent']}"`)
})

router.use('/api', serverRouter)
app.use(router.routes())

app.use(serve(__dirname+ './../public/', {
  maxage: maxage
}));
// 7月月报
app.use(serve(__dirname+ './../', {
  maxage: maxage
}));

process.on('unhandledRejection', (message, stack) => {
  log.error("未捕捉的Promise错误：", stack);
  // res.status(500).send('Internal server error.')
});

app.listen(port, ()=>{
  console.log(`server listening on port http://localhost:${port}/`)
})