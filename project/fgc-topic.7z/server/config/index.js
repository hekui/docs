const config = {
  appId: 'wx0725bb8630fac487',
  appSecret: '146a607fa446e4588068fad5103ff710'
}

module.exports = config