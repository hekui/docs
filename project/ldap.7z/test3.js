var ActiveDirectory = require('activedirectory');

var config = { 
  url: 'ldap://192.168.10.6:389',
  // url: 'ldap://218.89.222.13:389',
  baseDN: 'OU=成都瑞智创家网络科技有限公司,DC=chuangjialive,DC=com',
  // username: 'zhubo',
  // password: 'm*5.6@9#' 
}

var ad = new ActiveDirectory(config);
console.log(ad)

let user = 'hekui@chuangjialive.com'
let pwd = 'Hek142536'
ad.authenticate(user, pwd, function(err, auth) {
  if (err) {
    console.log('ERROR: '+JSON.stringify(err));
    return;
  }
  
  if (auth) {
    console.log('Authenticated!');
  } else {
    console.log('Authentication failed!');
  }
});

// let sAMAccountName = 'zhubo'
// ad.findUser(sAMAccountName, function(err, user) {
//   if (err) {
//     console.log('ERROR: ' +JSON.stringify(err));
//     return;
//   }

//   if (! user) console.log('User: ' + sAMAccountName + ' not found.');
//   else console.log(JSON.stringify(user));
// });