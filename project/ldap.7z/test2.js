var LDAP = require('ldap-client');

var ldap = new LDAP({
    uri:             'ldap://192.168.10.6:389',   // string
    validatecert:    false,             // Verify server certificate
    connecttimeout:  -1,                // seconds, default is -1 (infinite timeout), connect timeout
    base:            'dc=com',          // default base for all future searches
    attrs:           '*',               // default attribute list for future searches
    filter:          '(objectClass=*)', // default filter for all future searches
    scope:           LDAP.SUBTREE,      // default scope for all future searches
    connect:         function(){},        // optional function to call when connect/reconnect occurs
    disconnect:      function(){},        // optional function to call when disconnect occurs        
}, function(err) {
    // connected and ready    
});


var ldap = new LDAP({
  uri: 'ldap://server',
  connect: function() {
      this.bind({
          binddn: 'cn=zhubo,dc=com', // CN=zhubo,OU=成都瑞智创家网络科技有限公司,DC=chuangjialive,DC=com
          password: 'm*5.6@9#'
      }, function(err) {
        
      });
  }
})