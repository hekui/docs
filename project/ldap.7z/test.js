var ldap = require('ldapjs');

const auth = (user, pwd) => {
  var client = ldap.createClient({
    // url: 'ldap://218.89.222.13:389'
    url: 'ldap://192.168.10.6:389',
    strictDN: false
  });
  
  client.bind(`user=zhubo`, 'm*5.6@9#', function(err) {
    console.log('err', err)
    // client.unbind();
    if(err){
      return {
        code: 1,
        msg: '登录失败'
      }
    }
    return {
      code: 0, 
      msg: '登录成功'
    }
  });
}

let user = 'zhubo',
  pwd = 'm*5.6@9#';
auth(user, pwd)

//创建LDAP查询选项
//filter的作用就是相当于SQL的条件
// var opts = {
//   filter: '(uid=ldap)', //查询条件过滤器，查找uid=kxh的用户节点
//   scope: 'sub',        //查询范围
//   timeLimit: 500       //查询超时
// };

//将client绑定LDAP Server
//第一个参数：是用户，必须是从根节点到用户节点的全路径
//第二个参数：用户密码
// client.bind('uid=administrator,cn=users,dc=chuangjialive,dc=com', 'Cj123456', function (err, res1) {
//   console.log('line1', err, res1)
//   // 开始查询
//   // 第一个参数：查询基础路径，代表在查询用户信心将在这个路径下进行，这个路径是由根节开始
//   // 第二个参数：查询选项
//   client.search('DC=chuangjialive,DC=com', opts, function (err, res2) {
//       //查询结果事件响应
//       res2.on('searchEntry', function (entry) {
//           //获取查询的对象
//           var user = entry.object;
//           var userText = JSON.stringify(user,null,2);
//           console.log(userText);
//       });
      
//       res2.on('searchReference', function(referral) {
//           console.log('referral: ' + referral.uris.join());
//       });
      
//       //查询错误事件
//       res2.on('error', function(err) {
//           console.error('error: ' + err.message);
//           //unbind操作，必须要做
//           client.unbind();
//       });
      
//       //查询结束
//       res2.on('end', function(result) {
//           console.log('search status: ' + result.status);
//           //unbind操作，必须要做
//           client.unbind();
//       });        
      
//   });
    
// });