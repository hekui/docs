const fetch = require('node-fetch')
const moment = require('moment')
const log4js = require('log4js')
log4js.configure({
  appenders: { 
    dateFile: {
      type: 'dateFile',
      filename: __dirname +'/prod-log',
      // pattern: 'yyyy-MM-dd-hh',
      pattern: '.yyyy-MM-dd'
      // compress: true
    },
    out: {
      type: 'stdout'
    }
  },
  categories: {
    default: { 
      appenders: ['dateFile', 'out'], 
      level: 'trace' 
    }
  }
});
let log = log4js.getLogger()
let formatStr = 'YYYY-MM-DD HH:mm:ss.SSS'

let url = 'https://cd.maifangma.com/'
// let url = 'http://localhost:3002/'

const request = (url) => {
  let start = new Date()
  fetch(url, {
    timeout: 30 * 1000,
  }).then(res => {
    let end = new Date()
    let cost = end.getTime() - start.getTime()
    let temp = `[${moment(start).format(formatStr)}] ${url} - ${res.status} - ${cost}ms`
    if(cost < 3000){
      log.info(temp);
    }else{
      log.error(temp);
    }
  }).catch(res => {
    let end = new Date()
    let cost = end.getTime() - start.getTime()
    log.error(`[${moment(start).format(formatStr)}] ${url} - ${res.status} - ${cost}ms - err:\n${res}`);
  })
}

request(url)
setInterval(()=>{
  request(url)
}, 10 * 1000)