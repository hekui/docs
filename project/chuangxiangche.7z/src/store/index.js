import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
import api from './../api'

import product from './product'
import user from './user'
import invoice from './invoice'

export default new Vuex.Store({
  state: {
    project: {},
    projectList: [], // 项目列表
    orderStatus: { // 待支付:0, 支付失败:10, 已付款:20, 可退款:25, 退款中:30, 已完成:40, 已退款:45
      0: '待支付',
      10: '支付失败',
      20: '支付成功',
      25: '支付成功',
      30: '退款中',
      40: '已完成',
      45: '已退款'
    }
  },
  getters: {
    activityNotice: (state) => (id) => {
      if(state.project.id){
        return state.project
      }else{
        console.log('state.projectList', state.projectList)
        return state.projectList.find(pjt => pjt.id == id)
      }
    },
  },
  mutations: {
    indexSet(state, data){
      state[data['target']] = data.data
    }
  },
  actions: {
    fetchProject({commit}, params){
      return api.post('/carproject/findprojectid', params).then(res => {
        commit('indexSet', {
          target: 'project',
          data: res.data
        })
        return Promise.resolve()
      }, res => {
        console.log('fail')
        return Promise.reject()
      })
    },
    fetchProjectList({commit}, params){
      return api.post('/carproject/list', params).then(res => {
        commit('indexSet', {
          target: 'projectList',
          data: res.data.list
        })
        return Promise.resolve(res)
      }, res => {
        console.log('fail')
        return Promise.reject(res)
      })
    },
  },
  modules: {
    product,
    user,
    invoice
  }
})