import api from './../api'

export default {
  state: {
    detail: {}, // 开票详情
    historyList: [],
    historyInfo: [],
  },
  mutations: {
    invoiceSet(state, data){
      state[data['target']] = data.data
    }
  },
  actions: {
    // 查询开票详情
    fetchFindInvoice({commit, state}, params){
      // 有开票id时（查看历史开票详情），查询数据
      return api.post('/invoice/findinvoice', params).then(res => {
        commit('invoiceSet', {
          target: 'detail',
          data: res.data
        })
        return Promise.resolve(res)
      }, res => {
        // 报错设置成默认数据
        commit('invoiceSet', {
          target: 'detail',
          data: {}
        })
        return Promise.reject(res)
      })
    },
    // 保存开票信息
    fetchSaveInvoice({}, params) {
      return api.post('/invoice/saveinvoice', params).then(res => {
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
      })
    },
    fetchInvoiceHistory({commit}, params) {
      return api.post('/invoice/historyinvoicelist', params).then(res => {
        commit('invoiceSet', {
          target: 'historyList',
          data: res.data
        })
        return Promise.resolve()
      }, res => {
        console.log('fail')
        return Promise.reject()
      })
    },
    fetchInvoiceInfo({commit}, params) {
      return api.post('/invoice/findinvoice', params).then(res => {
        commit('invoiceSet', {
          target: 'historyInfo',
          data: res.data
        })
        return Promise.resolve()
      }, res => {
        console.log('fail')
        return Promise.reject()
      })
    },
  }
}