import api from './../api'
import cookie from 'js-cookie'
import axios from 'axios'
export default {
  state: {
    // account: {
    //   id: 1,
    //   userName: 'hekui',
    //   phone: '13982271436'
    // },
    account: '',
    orderData: {
      data: [],
      now: ''
    },
    orderList: [],
    orderDetail: {
      carPort: {}
    }
  },
  mutations: {
    userSet(state, data){
      if(data['target']){
        state[data['target']] = data.data || ''
      }
    }
  },
  actions: {
    ssoLogin({}, params){
      let url = `https://wxsso.maifangma.com/cxc/getuser?ssid=${params.ssid}`
      return new Promise((resolve, reject) => {
        axios({
          method: 'get',
          url: url,
          withCredentials: true,
          timeout: 10000,
          headers: {
            'Content-Type': 'application/json'
          },
        }).then(res => {
          console.log(`[get]${url}`, res)
          if (res.status === 200) {
            if (res.data.code === 200) {
              resolve(res.data)
            } else {
              reject(res.data)
            }
          }
        }).catch(error => {
          console.log('error', error)
          console.log('error.response', error.response)
          console.log('error.request', error.request)
          reject(error.response)
        })
      })
      // return api.get()
    },
    sendPhoneCode({}, params){
      return api.post('/users/securitycode', params)
    },
    userReg({commit}, params){
      return api.post('/users/register', params).then(res => {
        commit('userSet', {
          target: 'account',
          data: res.data
        })
        cookie.set('CXC_ticketId', res.data.ticketId, { expires: 30 });
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
      })
    },
    userLogin({commit}, params){
      return api.post('/users/quicklogin', params).then(res => {
        commit('userSet', {
          target: 'account',
          data: res.data
        })
        cookie.set('CXC_ticketId', res.data.ticketId, { expires: 30 });
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
      })
    },
    userEditSave({commit}, params){
      return api.post('/users/completeusers', params).then(res => {
        commit('userSet', {
          target: 'account',
          data: res.data
        })
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
      })
    },
    fetchUser({commit}, params){
      // 增加unionid openid
      let cacheSSOUser = window.localStorage.getItem('CXC_CACHE_WXSSO_USER')
      if(cacheSSOUser){
        let cacheUser = JSON.parse(cacheSSOUser)
        params.unionid = cacheUser.unionid
        params.openid = cacheUser.uid
      }

      return api.post('/users/userdata', params).then(res => {
        commit('userSet', {
          target: 'account',
          data: res.data
        })
        cookie.set('CXC_ticketId', res.data.ticketId, { expires: 30 });
        return Promise.resolve(res)
      }, res => {
        commit('userSet', {
          target: 'account',
          data: {}
        })
        if(res.code === 1012){ // 登陆过期，清除ticketId
          cookie.set('CXC_ticketId', '', { expires: 30 });
        }
        return Promise.reject(res)
      })
    },
    // fetchOrderList({commit}, params){
    //   return api.post('/order/listorder', params).then(res => {
    //     commit('userSet', {
    //       target: 'orderData',
    //       data: res.data
    //     })
    //     return Promise.resolve(res)
    //   }, res => {
    //     return Promise.reject(res)
    //   })
    // },
    // 查询用户订单列表（v1.3.0）
    fetchOrderList({commit}){
      return api.post('/order/listuserorder').then(res => {
        commit('userSet', {
          target: 'orderData',
          data: res.data
        })
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
      })
    },
    fetchOrderDetail({commit}, params){
      return api.post('/order/orderdetails', params).then(res => {
        commit('userSet', {
          target: 'orderDetail',
          data: res.data.data
        })
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
      })
    },
    userLogout({commit}){
      return api.post('/users/userlogout').then(res => {
        commit('userSet', {
          target: 'account',
          data: {}
        })
        cookie.set('CXC_ticketId', '', { expires: 0 });
        // window.localStorage.removeItem('CXC_CACHE_WXSSO_USER')
        return Promise.resolve(res)
      }, res => {
        if(res.code === 1012){ // 登陆过期
          commit('userSet', {
            target: 'account',
            data: {}
          })
          cookie.set('CXC_ticketId', '', { expires: 30 });
        }
        return Promise.reject(res)
        console.log('fail')
      })
    }
  }
}