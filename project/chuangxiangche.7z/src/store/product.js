import api from './../api'
export default {
  state: {
    projectCode: '',
    projectId: '',
    amount: '-',
    choosePS: '',
    imgList: []
  },
  mutations: { 
    productSet(state, data){
      if(data['target']){
        state[data['target']] = data.data || ''
      }
    }
  },
  actions: {
    fetchPSAmount({commit}, params){
      api.post('/carport/canbuycount', params).then(res => {
        console.log('/carport/canbuycount res', res);
        commit('productSet', {
          target: 'amount',
          data: res.data.count || 0
        })
      })
    },
    fetchProduct({commit}, params){
      return api.post('/carport/listcarport', params)
    },
    fetchProductImg({commit}, params){
      return api.post('/carport/listcarportpic', params).then(res => {
        commit('productSet', {
          target: 'imgList',
          data: res.data
        })
        return Promise.resolve(res)
      }, res => {
        return Promise.reject(res)
        console.log('fail')
      })
    },
    fetchCarportDetail({commit}, params){
      return api.post('/carport/findcarportone', params)
    },
    createOrder({commit, dispatch}, params){
      return api.post('/order/createorder', params)
    },
    fetchOrderStatus({commit}, params){
      return api.post('/order/findcarportorderone', params)
    },
    updateOrderStatus({commit}, params){
      return api.post('/order/updateorderstatus', params)
    }
  }
}