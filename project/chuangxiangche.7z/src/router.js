import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

import InfoRule from './pages/info/rule.vue'
import InfoGift from './pages/info/gift.vue'
import Case from './pages/product/case'
import Product from './pages/product'
import ProductPay from './pages/product/pay.vue'
import ProductPayResult from './pages/product/reserve.vue'

import UserIndex from './pages/user/index'
import UserValid from './pages/user/valid'
import UserLogin from './pages/user/login'
import UserAgreement from './pages/user/agreement'
import UserInfo from './pages/user/info'
import UserOrder from './pages/user/order'
import OrderDetail from './pages/user/orderDetail'
import Home from './pages/home'
import NotFound from './pages/404'

import InvoiceIndex from './pages/invoice'
import InvoiceRule from './pages/invoice/rule'
import InvoiceHistory from './pages/invoice/history'
import InvoiceInfo from './pages/invoice/info'
import InvoiceDetail from './pages/invoice/detail'
import InvoiceSuccess from './pages/invoice/success'

import Booking from './pages/booking'

export default new VueRouter({
  routes: [
    {path: '/info/rule', component: InfoRule},
    {path: '/info/gift', component: InfoGift},
    {path: '/case', component: Case},
    {path: '/product', component: Product},
    {path: '/product/pay', component: ProductPay},
    {path: '/product/pay/result', component: ProductPayResult},
    {path: '/user/index', component: UserIndex},
    {path: '/user/info', component: UserInfo},
    {path: '/user/login', component: UserLogin},
    {path: '/user/agreement', component: UserAgreement},
    {path: '/user/valid', component: UserValid},
    {path: '/user/order', component: UserOrder},
    {path: '/user/orderDetail', component: OrderDetail},
    {path: '/invoice/index' ,alias: '/invoice', component: InvoiceIndex},
    {path: '/invoice/rule', component: InvoiceRule},
    {path: '/invoice/history', component: InvoiceHistory},
    {path: '/invoice/detail', component: InvoiceDetail},
    {path: '/invoice/success', component: InvoiceSuccess},
    {path: '/invoice/info', component: InvoiceInfo},
    {path: '/booking/index' ,alias: '/booking', component: Booking},
    {path: '/', component: Home},
    {path: '*', component: NotFound}
  ]
})