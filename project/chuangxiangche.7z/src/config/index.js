
const 
  projectCode = 'projectCode',
  webUrl = 'http://che.test1.maifangma.com/', // 用以配置微信支付回调
  // webUrl = 'https://m.maifangma.com/cxc/',

  serverUrl = 'http://192.168.10.196:8080', // 周波 
  // serverUrl = 'https://pscarport.test1.maifangma.com', // 后端接口
  // serverUrl = 'https://pscarport.maifangma.com',
  productName = '信息服务费', // 支付用 - 商品名称
  a = 0;

export {
  projectCode,
  webUrl,
  serverUrl,
  productName,
}