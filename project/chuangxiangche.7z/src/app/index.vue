<template>
  <div class="container-fluid">
    <router-view v-if="projectOk"></router-view>
    <div v-else class="global-loading">
      <span v-if="loading">努力加载中...</span>
      <div v-else>
        <p>{{errMsg}}</p>
        <p><a href="javascript: void(0);" @click="reload">点击重试</a></p>
      </div>
    </div>
  </div>
</template>
<script>
// import Vue from 'vue'
import {mapState} from 'vuex'
// import Toast from './../components/toast/'
import './../assets/css/iconfont/style.css';
// Vue.prototype.$toast = Toast;
import utils from './../assets/js/utils'
import cookie from 'js-cookie'

export default {
  name: 'App',
  data(){
    return {
      loading: false,
      projectOk: false,
      errMsg: '加载失败，网络错误',
    }
  },
  computed: mapState({
    projectCode: state => state.product.projectCode,
    project: state => state.project,
  }),
  created(){
    this.loading = true
    console.log('this.$route', this.$route)
    // 获取项目ID，如果有则获取信息
    let projectId = this.$route.query.projectId || ''
    if(projectId){
      cookie.set('CXC_PROJECTID',)
    }else{
      if(cookie.get('CXC_PROJECTID')){
        projectId = cookie.get('CXC_PROJECTID')
      }
    }
    if(!!projectId){
      this.fetchProjectInfo(projectId)
    }else{
      // this.loading = false
      // this.projectOk = true
      // 判断用户登录
      this.checkUser()

      //分享
      utils.initShare()
    }

  },
  mounted(){
    let isWechat = /micromessenger/.test(navigator.userAgent.toLowerCase())
    if(!isWechat){
      this.$toast('请在微信中打开使用')
    }
  },
  methods: {
    fetchProjectInfo(projectId){
      // 获取项目信息
      
      this.$store.dispatch('fetchProject', {
        code: 'wkygc',
        id: projectId
      }).then(res => {
        // 判断用户登录
        this.checkUser()

        //分享
        utils.initShare()
      }, res => {
        console.log('projectFail')
        this.loading = false
        this.projectOk = false
        // this.$toast('该活动不存在或已结束')
      })
    },
    checkUser(){
      let ticketId = cookie.get('CXC_ticketId')
      if(ticketId){
        this.fetchUser()
      }else{
        let cacheSSOUser = window.localStorage.getItem('CXC_CACHE_WXSSO_USER')
        if(cacheSSOUser){ // 如果有unionid和openid
          this.fetchUser();
        }else{// 调用 微信授权登陆
          this.ssoLogin()
        }
      }
    },
    fetchUser(){
      this.$store.dispatch('fetchUser', {
        projectId: this.project.id
      }).then(res => {
        this.loading = false
        this.projectOk = true
      }, res => {
        this.loading = false
        this.projectOk = true
      })
    },
    ssoLogin(){
      this.$store.dispatch('ssoLogin', {
        ssid: window.localStorage.getItem('CXC_SSID') || "",
      }).then(res => {
        // console.log('sso res:', res)
        if (res.ssid) {
          window.localStorage.setItem('CXC_SSID', res.ssid)
        }
        // 缓存 微信用户信息
        window.localStorage.setItem('CXC_CACHE_WXSSO_USER', JSON.stringify(res.user))
        this.fetchUser();
        this.loading = false
        this.projectOk = true
      }, res => {
        this.loading = false
        this.projectOk = true
        // console.log('sso fail res:', res)
        if (res.ssid) {
          window.localStorage.setItem('CXC_SSID', res.ssid)
        }
        if(res.code == 201){
          // 跳转到微信授权页面
          window.location.assign(res.url);
        }
      })
    },
    reload(){
      this.fetchProjectInfo()
    }
  }
}
</script>
<style lang="scss">
// @import './../assets/css/iconfont/style.css';
*{
  box-sizing: border-box;
}
body{
  font-size: 16px; 
  margin: 0; padding: 0; color: #333; background-color: #fff;
  font-family: Arial, PingFang Medium, SimHei;
}
html,body,.container-fluid{
  height: 100%;
}

.global-loading{
  height: 100%; text-align: center; display: flex; align-items: center; justify-content: center; color: #999;
}

.mb15{
  margin-bottom: 0.9375rem;;
}
a{
  // font-size: .875rem;
  color: #7CA7D8;
  text-decoration: none;
}
.center{
  text-align: center;
}
.fs14{
  font-size: 0.875rem;
}
.fs15{
  font-size: 0.9375rem;
}
.fs16{
  font-size: 1rem;
}
.fs17{
  font-size: 1.0625rem;
}
.fs20{
  font-size: 1.25rem;
}

.empty{
  text-align: center; margin-top: 10rem; color: #999;
}

.btn {
  display: inline-block;
  padding: .375rem .75rem;
  margin-bottom: 0;
  font-size: .875rem;
  font-weight: 400;
  line-height: 1.42857143;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  -ms-touch-action: manipulation;
  touch-action: manipulation;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  background-image: none;
  border: none;
  border-radius: 4px;
}
.btn .icon-loading {
  display: inline-block;
  margin-right: 0.3125rem;
  visibility: hidden;
}
.btn.submit .icon-loading {
  visibility: visible;
}
.btn.active, .btn:active {
  background-image: none;
  outline: 0;
  // -webkit-box-shadow: inset 0 3px 5px rgba(0,0,0,.125);
  // box-shadow: inset 0 3px 5px rgba(0,0,0,.125);
}
.btn-block {
  display: block;
  width: 100%;
}
.btn.disabled, .btn[disabled], fieldset[disabled] .btn {
  cursor: not-allowed;
  filter: alpha(opacity=65);
  -webkit-box-shadow: none;
  box-shadow: none;
  opacity: .65;
}
.btn-default {
  color: #333;
  background-color: #fff;
  border-color: #ccc;
}
.btn-primary {
  color: #fff;
  background-color: #337ab7;
  border-color: #2e6da4;
}
.btn-success {
  color: #fff;
  background-color: #5cb85c;
  border-color: #4cae4c;
}
.btn-info {
  color: #fff;
  background-color: #5bc0de;
  border-color: #46b8da;
}
.btn-warning {
  color: #fff;
  background-color: #f0ad4e;
  border-color: #eea236;
}
.btn-danger {
  color: #fff;
  background-color: #d9534f;
  border-color: #d43f3a;
}
.btn-prepay{
  width: 100%; height: 3rem; line-height: 2.25rem; border-radius: 0;
  background: #444652; font-size: 16px; color: #E3B689;
  &.disabled,&.submit{
    background-color: #f6f6f6; color: #999; cursor: not-allowed;
  }
}

.warning{
  color: #f0ad4e
}
.danger{
  color: #d9534f
}

.bg-warning {
  background-color: #fcf8e3;
}

.form-group {
  margin-bottom: 0.9375rem;
}
label {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 5px;
  font-weight: 700;
}
.form-control {
  display: block;
  width: 100%;
  height: 2.5rem;
  padding: .375rem .75rem;
  font-size: .875rem;
  line-height: 1.42857143;
  color: #555;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
  box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
  -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
  -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
  transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}
.form-control:focus {
  border-color: #66afe9;
  outline: 0;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
  box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
}
.form-group.has-feedback{
  position: relative;
}

.icon{
  position: relative;
  top: 1px;
  display: inline-block;
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  background-size: 100%;
  background-position: center center;
  background-repeat: no-repeat;
}

.icon-radio{
  width: 1.13rem; height: 1.13rem; margin-right: .5rem; 
  background-image: url('./../assets/images/icon-radio.png');
  &.checked{
    background-image: url('./../assets/images/icon-radio-checked.png');
  }
}

.fix-bar{
  position: fixed;
  bottom: 0; left: 0; width: 100%;
}

.icon-loading{
  animation-fill-mode: backwards;
  animation: rotate 2s linear infinite;
}
@keyframes rotate{
  0%{
    transform: rotate(0deg);
  }
  100%{
    transform: rotate(360deg);
  }
}
</style>
