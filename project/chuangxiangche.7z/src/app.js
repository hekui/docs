// import 'babel-polyfill'

import Vue from 'vue'
import router from './router'

import App from './app/index.vue'
import store from './store'

import ProgressBar from './components/ProgressBar.vue'
// global progress bar
const bar = Vue.prototype.$bar = new Vue(ProgressBar).$mount()
document.body.appendChild(bar.$el)

import Toast from './components/toast/'
Vue.use(Toast)

Vue.mixin({
  created(){
    let title = this.$options.title
    if(title){
      document.title = title
    }
  }
})

const app = new Vue({
  el: '#app',
  router,
  store,
  data: {
    step: ''
  },
  render: h => h(App)
})

router.onReady(() => {
  router.beforeResolve((to, from, next) => {
    const matched = router.getMatchedComponents(to)
    const prevMatched = router.getMatchedComponents(from)
    let diffed = false
    const activated = matched.filter((c, i) => {
      return diffed || (diffed = (prevMatched[i] !== c))
    })
    const asyncDataHooks = activated.map(c => {
      return c.asyncData
    }).filter(_ => _)
    if (!asyncDataHooks.length) {
      return next()
    }
    bar.start()
    Promise.all(asyncDataHooks.map(hook => hook({ store, route: to})))
      .then(() => {
        bar.finish()
        next()
      })
      .catch(next)
  })
})