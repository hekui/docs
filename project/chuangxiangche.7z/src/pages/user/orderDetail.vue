<template>
  <div class="order-detail-page">
    <div v-if="loading" class="empty">
      正在努力加载中...
    </div>
    <div v-else>
      <div class="order-detail">
        <div class="title">订单详情<div class="order-status">{{orderStatus[orderDetail.orderStatus]}}</div></div>
        <div class="order-detail-info">
            <div class="left">
              <div>意向金：<span class="prepay-price">¥ {{orderDetail.orderAmount}} 元</span></div>
              <div>预选时间：{{dayjs(orderDetail.createTime)}}</div>
            </div>
            <div class="right">
              <div>
                <!-- 订单未支付，且车位未出售 -->
                <button type="button" v-if="orderDetail.orderStatus === 0 && orderDetail.carPort.carStatus !== 30" class="btn btn-prepay" @click="validPay(orderDetail)">完成支付</button>
                <button type="button" v-if="orderDetail.orderStatus === 25" class="btn btn-refund" @click="refund(orderDetail)">申请退款</button>
              </div>
            </div>
          </div>
          <div class="rest-time" v-if="orderDetail.orderStatus === 0 && orderDetail.carPort.carStatus !== 30 && orderDetail.payEndTime > now">支付倒计时：{{diffTime(orderDetail.payEndTime)}}</div>
      </div>
      <div class="carPort-detail">
        <div class="title">车位详情</div>
        <div class="carPort-detail-info">
          <div>车位总价：<span class="prepay-price">¥ {{orderDetail.carPortPrice}} 元</span></div>
          <template v-if="orderDetail.dealCarPort">
            <div>最终认购车位：{{orderDetail.dealCarPort.carNum}}</div>
          </template>
          <div>车位编号：{{orderDetail.carPort.carNum}}</div>
          <div>所属项目：{{orderDetail.projectName}}</div>
          <div>车位类型：{{orderDetail.carPort.carType}}</div>
          <div>车位面积：{{orderDetail.carPort.carArea}}㎡</div>
        </div>
      </div>
    </div>
    <div class="" v-if="showDialog">
      <div class="mask" @click="showDialog = false;"></div>
      <div class="dialog-wrapper dialog-refund">
        <div class="dialog-content">
          <div class="dialog-head">
            申请退款
          </div>
          <div class="dialog-body">
            如果您最终没有选购到满意车位的，我们将在您提出退款申请后二十个工作日内原路退还您所预付的全部服务费（无息。如需产生手续费的，将由您个人承担全部手续费用）。
          </div>
          <div class="dialog-foot">
            <button type="button" class="btn btn-prepay" @click="showDialog = false;">取消</button>
            <button type="button" class="btn btn-prepay" @click="refundSubmit">确认申请</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
import dayjs from 'dayjs'
import {webUrl, serverUrl, productName} from './../../config'

export default {
  name: "Order",
  title: '订单详情',
  data(){
    return {
      showDialog: false,
      now: '',
      curOrder: '',
      loading: false,
      id: this.$route.query.id
    }
  },
  computed: mapState({
    project: state => state.project,
    account: state => state.user.account,
    orderStatus: state => state.orderStatus,
    orderDetail: state => state.user.orderDetail,
  }),
  mounted(){
    this.fetchOrderData()
  },
  beforeDestroy(){
    clearInterval(this.timer)
  },
  methods: {
    fetchOrderData(){
      this.loading = true
      this.$store.dispatch("fetchOrderDetail", {
        projectId: this.project.id,
        id: this.id
      }).then(res => {
        this.now = res.data.now
        this.timer = setInterval(function(){
          this.now += 1000
        }.bind(this), 1000)
        this.loading = false
      }, res => {
        this.loading = false
        if(res.code === 1012){
          this.$router.replace({path: '/user/login', query: { url: '/user/order'}})
        }
        this.$toast(res.msg)
      })
    },
    diffTime(payEndTime){
      // console.log('payEndTime', payEndTime)
      let nowTime = this.now
      let hour = dayjs(payEndTime).diff(dayjs(nowTime), 'hour')
      let minute = dayjs(payEndTime).subtract(hour, 'hour').diff(dayjs(nowTime), 'minute')
      let second = dayjs(payEndTime).subtract(hour, 'hour').subtract(minute, 'minute').diff(dayjs(nowTime), 'second')
      var str = `${hour}小时${minute}分${second}秒`
      //倒计时结束，刷新数据
      if(hour === 0 && minute === 0 && second === 0){
        clearInterval(this.timer)
        this.fetchOrderData()
      }
      // console.log(str)
      return str
    },
    dayjs(stamp) {
      return dayjs(stamp).format('YYYY-MM-DD HH:mm')
    },
    refund(item) {
      this.showDialog = true
      this.curOrder = item
    },
    refundSubmit(){
      this.showDialog = false
      console.log('curOrder', this.curOrder)
      this.$store.dispatch('updateOrderStatus', {
        id: this.curOrder.id
      }).then(res => {
        this.$toast('申请成功')
        this.fetchOrderList()
        // this.$store.dispatch("fetchOrderList")
      }, res => {
        this.$toast('网络错误')
      })
    },
    validPay(item){
      this.$store.dispatch('fetchOrderStatus', {
        id: item.id
      }).then(res => {
        console.log('fetchOrderStatus res', res)
        if(res.data.data.orderStatus === 0){
          this.pay(item)
        }else{
          this.$toast('订单已无法支付')
        }
      }, res => {
        this.$toast('网络错误')
      })
    },
    pay(data){
      console.log('in pay()')
      console.log('data', data)
      let total_fee = data.orderAmount * 100
      // let total_fee = 1
      //微信内调用支付
      let url = `https://wxsso.maifangma.com/cxc/pay.html?body=${productName}&detail=${productName}&total_fee=${total_fee}&out_trade_no=${data.id}&origin_url=${encodeURIComponent(`${webUrl}#/product/pay/result?id=${data.id}`)}&notify_url=${serverUrl}/order/wechatpayreturn`
      console.log('pay url:', url)
      location.href = url
    }
  }
}
</script>
<style lang="scss">
.mask{
  position: fixed;
  z-index: 2000;
  background-color: rgba(0, 0, 0, .4);
  top: 0; left: 0;
  width: 100%; height: 100%;
}
.dialog-wrapper{
  position: fixed;
  width: 80%;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2100;
  background-color: #fff;
  border-radius: 4px;
  
  .dialog-body{
    padding: 1rem;
  }
  .dialog-foot{
    padding: 1rem;
    display: flex; justify-content: space-between;
  }
}

.dialog-refund{
  .dialog-head{
    font-size: 20px; text-align: center;
    padding: 1rem; border-bottom: 1px solid #ddd;
  }
  .dialog-foot{
    padding-bottom: 1.5rem;
    .btn{
      width: 42%; height: 2.2rem; line-height: 1; border-radius: 4px;
    }
  }
}

.order-detail-page {
  height: 100%;
  overflow-y: auto;
  background-color: #f3f3f3;
  font-size: .875rem;
  color: #444652;
  .title {
    position: relative;
    display: flex;
    justify-content: space-between;
    .order-status {
      color: #E3B689;
    }
    &::before {
      content: '';
      position: absolute;
      left: -.5rem;
      top: 0;
      width: .19rem;
      height: 1.06rem;
      background: #E3B689;
    }
  }
  .order-detail {
    padding: 1.25rem 1.19rem .75rem;
    border-bottom: 1px solid #DDD;
    .order-detail-info {
      margin: .75rem 0 1rem;
      display: flex; justify-content: space-between;
      color: #444652;
      line-height: 1.5rem;
      .left {
        .prepay-price {
          font-size: 1rem;
          color: #FF5656;
        }
      }
      .right {
        display: flex;
        align-items: flex-end;
        .btn {
          width: 5.75rem; height: 1.88rem; font-size: .875rem; line-height: .875rem; border-radius: 1.88rem;
        }
      }
    }
    .rest-time {
      color: #BABABA;
    }
  }
  .carPort-detail {
    padding: 1.25rem 1.19rem 1.19rem;
    .carPort-detail-info {
      margin-top: .75rem;
      color: #999;
      line-height: 1.5rem;
      .prepay-price {
          font-size: 1rem;
        }
    }
  }
  
}
</style>
