<template>
  <div class="login-page">
    <h1>验证码快捷登陆</h1>
    <div>
      <div class="form-group has-feedback has-send">
        <input type="tel" class="form-control" v-model.number="form.phone" maxlength="11" oninput="if(this.value.length > 11) this.value = this.value.slice(0,11)" placeholder="请输入业主手机号">
        <button type="button" class="btn btn-prepay btn-send" :class="{'disabled': isSending || !(/^1\d{10}$/.test(form.phone))}" v-if="canSend" @click="sendPhoneCode">发送验证码</button>
        <button type="button" class="btn btn-send btn-sended" v-else>{{seconed}}s</button>
      </div>
      <div class="form-group">
        <input type="tel" class="form-control" maxlength="6" oninput="if(this.value.length > 6) this.value = this.value.slice(0,6)" v-model="form.verificationCode" placeholder="验证码">
      </div>
      <div class="form-agreement" @click="toggleChecked">
        <span class="icon icon-radio" :class="{'checked': isChecked}"></span>我已阅读并同意<router-link to="/user/agreement">《创享车用户注册协议》</router-link>
      </div>
      <button type="button" class="btn btn-prepay btn-login" :class="{'disabled': !isValid}" @click="valid">立即登陆</button>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
  name: "Login",
  title: '快捷登陆',
  data(){
    return {
      form: {
        phone: '',
        verificationCode: '',
      },
      isChecked: true,
      isValid: false,

      // 发送验证码
      canSend: true,
      isSending: false, // 发送中
      seconed: 60, // 多少秒后可发送短信
      timer: null,
    }
  },
  watch: {
    form: {
      deep: true,
      handler: function(newVal){
        this.validate()
      },
    },
    isChecked: function(newVal){
      this.validate()
    },
  },
  computed: mapState({
    project: state => state.project,
  }),
  created(){
    // 读取缓存
    let cacheForm = window.localStorage.getItem('CXC_CACHE_LOGIN_FORM')
    if(cacheForm){
      this.form = JSON.parse(cacheForm)
    }
  },
  methods: {
    validate(){
      if(this.isChecked && /^1\d{10}$/.test(this.form.phone) && /^\d{4,6}$/.test(this.form.verificationCode)){
        this.isValid = true
      } else {
        this.isValid = false
      }
      // 缓存form表单
      window.localStorage.setItem('CXC_CACHE_LOGIN_FORM', JSON.stringify(this.form))
    },
    toggleChecked(){
      this.isChecked = !this.isChecked
    },
    initSend(){
      clearInterval(this.timer)
      this.canSend = true
      this.seconed = 60
    },
    sendPhoneCode(){
      if(this.form.phone === ''){
        return 
      }
      if(/^1\d{10}$/.test(this.form.phone)){
        if(this.canSend && !this.isSending){
          this.isSending = true

          // setTimeout(function(){
          //   this.isSending = false
          //   this.canSend = false

          //   this.timer = setInterval(function(){
          //     this.seconed --
              
          //     if(this.seconed === 0){
          //       this.initSend()
          //     }
          //   }.bind(this), 1000)
          // }.bind(this), 1000)
          this.form.verificationCode = ''
          this.$store.dispatch('sendPhoneCode', {
            phone: this.form.phone
          }).then(res => {
            this.isSending = false
            this.canSend = false

            this.timer = setInterval(function(){
              this.seconed --
              if(this.seconed === 0){
                this.initSend()
              }
            }.bind(this), 1000)
          }, res => {
            this.isSending = false
            this.canSend = true
            this.$toast('发送失败，请重试')
          })
        }
      }else{
        this.$toast('手机号不正确')
      }
    },

    valid(){
      let url = this.$route.query.url
      let params = {
        projectId: this.project.id,
        phone: this.form.phone,
        verificationCode: this.form.verificationCode
      }

      // 增加unionid openid
      let cacheSSOUser = window.localStorage.getItem('CXC_CACHE_WXSSO_USER')
      if(cacheSSOUser){
        let cacheUser = JSON.parse(cacheSSOUser)
        params.unionid = cacheUser.unionid
        params.openid = cacheUser.uid
      }

      console.log('params', params)
      if(this.isValid){
        this.$store.dispatch('userLogin', params).then(res => {
          window.localStorage.removeItem('CXC_CACHE_LOGIN_FORM')
          this.$toast('登陆成功')
          if(url){
            this.$router.replace(url)
          }else{
            this.$router.replace('/user/index')
          }
        }, res => {
          if(res.code === 1035){
            this.$toast('验证码错误')
          }else{
            this.$toast(`登陆失败，${res.msg}`)
          }
        })
      }      
    }
  }
}
</script>
<style lang="scss">
.login-page{
  padding: 1.88rem 1.13rem;
  h1{
    font-size: 1.625rem; margin-top: 0; margin-bottom: 3rem; font-weight: 400;
  }
  .form-group{
    border-bottom: 1px solid #ddd;
  }
  .form-control{
    border: none; border-radius: 0; box-shadow: none;
    &:focus{
      border-color: #999; 
      box-shadow: none;
    }
  }
  .has-send{
    padding-right: 8rem;
  }
  .has-feedback{
    .btn-send{
      width: 7rem; height: 2.06rem; font-size: .875rem; line-height: 1; border-radius: 4px;
      position: absolute; right: 0; top: 0; 
      &.btn-sended{
        background-color: #f9f9f9; color:#999;
      }
    }
  }
  .btn-login{
    margin-top: 4.4rem;
  }
  .form-agreement{
    a{
      color: #E3B689;
    }
  }
}
</style>
