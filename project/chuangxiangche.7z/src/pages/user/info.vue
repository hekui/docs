<template>
  <div class="userinfo-page">
    <h1>编辑业主信息</h1>
    <div>
      <div class="form-group">
        <input type="text" class="form-control" maxlength="10" v-model="form.userName" placeholder="请输入业主姓名">
      </div>
      <div class="house-list">
        <!-- <div class="form-group has-feedback has-opt" 
        v-for="(item, index) in form.housesCode"
        :key="index"
        >
          <input type="text" class="form-control" maxlength="11" v-model="item.value" placeholder="房号（格式：10-1-1601）">
          <span class="icon icon-plus" v-if="index == 0" @click="plusHouse"></span>
          <span class="icon icon-minus" v-else @click="minusHouse(index)"></span>
        </div> -->
      </div>
      <button type="button" class="btn btn-prepay btn-edit" :class="{'disabled': !isValid}" @click="submit">提交</button>
    </div>
  </div>
</template>
<script>
import {mapState} from 'vuex'
export default {
  name: 'UserInfo',
  title: '编辑业主信息',
  data(){
    return {
      form: {
        userName: '',
        housesCode: [{value: ''}],
      },
      isValid: false
    }
  },
  computed: mapState({
    project: state => state.project,
    account: state => state.user.account,
  }),
  created(){
    this.initForm()
  },
  watch: {
    account: function(){
      this.initForm()
    },
    form: {
      deep: true,
      handler: function(newVal){
        this.validate()
      }
    },
  },
  methods: {
    initForm(){
      this.form.userName = this.account.userName
      if(this.account.housesCode.length > 0){
        this.form.housesCode = this.account.housesCode.map(item => {
          return {value: item}
        })
      }
    },
    validate(){
      let hasEmpty = false
      this.form.housesCode.forEach(item => {
        if(item.value === ''){
          hasEmpty = true
        }
      })
      
      if(this.form.userName !== '' && !hasEmpty){
        this.isValid = true
      } else {
        this.isValid = false
      }
    },
    plusHouse(){
      this.form.housesCode.push({value: ''})
    },
    minusHouse(index){
      this.form.housesCode.splice(index, 1)
    },
    submit(){
      if(this.isValid){
        let url = this.$route.query.url
        let params = {
          projectId: this.project.id,
          userName: this.form.userName,
        }
        // let hasEmpty = false
        // params.housesCode = this.form.housesCode.map(item => {
        //   if(item.value === ''){
        //     hasEmpty = true
        //   }
        //   return item.value
        // })
        console.log('params', params)

        this.$store.dispatch('userEditSave', params).then(res => {
          this.$toast('提交成功')
          if(url){
            this.$router.replace(url)
          }else{
            this.$router.replace('/user/index')
          }
        }, res => {
          if(res.code === 1035){
            this.$toast('验证码错误')
          }else{
            this.$toast(`提交失败，${res.msg}`)
          }
        })
      }
    }
  }
}
</script>
<style lang="scss">
.userinfo-page{
  padding: 1.88rem 1.13rem;
  h1{
    font-size: 1.625rem; margin-top: 0; margin-bottom: 3rem; font-weight: 400;
  }
  .form-group{
    border-bottom: 1px solid #ddd;
  }
  .form-control{
    border: none; border-radius: 0; box-shadow: none;
    font-family: 'PingFangSC-Regular';
    font-size: 1rem;
    padding: 0;
    // color: #C8C8C8;
    &:focus{
      border-color: #999; 
      box-shadow: none;
    }
  }
  .btn-edit{
    border-radius: 2px;
    font-size: 1.0625rem;
  }
  .has-send{
    padding-right: 8rem;
  }
  .has-feedback{
    .btn-send{
      width: 7rem; height: 2.06rem; font-size: .875rem; line-height: 1; border-radius: 4px;
      position: absolute; right: 0; top: 0; 
      &.btn-sended{
        background-color: #f9f9f9; color:#999;
      }
    }
  }
  .has-opt{
    padding-right: 2.31rem;
  }
  .icon-plus, .icon-minus{
    width: 1.31rem; height: 1.31rem; margin-right: .5rem;
    position: absolute; right: 0; top: 0.5rem;
  }
  .icon-plus{
    background-image:url('./../../assets/images/icon-plus.png');
  }
  .icon-minus{
    background-image:url('./../../assets/images/icon-minus.png');
  }
  .house-list{
    min-height: 6.875rem;
  }
}
</style>
