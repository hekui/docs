<template>
  <div class="order-page">
    <div v-if="loading" class="empty">
      正在努力加载中...
    </div>
    <div v-else>
      <div v-if="orderData.data.length === 0" class="empty">您还没有订单。</div>
      <div v-else class="order-list">
        <div class="order-item" 
          v-for="(item, index) in orderData.data" :key="index" @click="toDetailPage(item.id)">
          <div class="order-item__top">
            <div class="order-item-orderNum">订单编号：<span class="order-txt">{{item.orderNum}}</span></div>
            <!-- 待支付:0, 支付失败:10, 已付款:20, 可退款:25, 退款中:30, 已完成:40, 已退款:45 -->
            <div class="order-item-orderStatus">{{orderStatus[item.orderStatus]}}</div>
          </div>
          <div class="order-item__head">
            <div class="left">
              <template v-if="item.dealCarPort">
                <div>最终认购车位：<span class="order-txt">{{item.dealCarPort.carNum}}</span></div>
              </template>
              <div>车位编号：<span class="order-txt">{{item.carPort.carNum}}</span></div>
              <div>所属项目：<span class="order-txt">{{item.projectName}}</span></div>
              <div>预选时间：<span class="order-txt">{{dayjs(item.createTime)}}</span></div>
            </div>
            <div class="right">
              <div class="prepay-wrapper"><span class="prepay-name">意向金</span><span class="prepay-price order-txt">¥ {{item.orderAmount}} 元</span></div>
              <div>
                <!-- 订单未支付，且车位未出售 -->
                <button type="button" v-if="item.orderStatus === 0 && item.carPort.carStatus !== 30" class="btn btn-prepay" @click.stop="validPay(item)">完成支付</button>
                <button type="button" v-if="item.orderStatus === 25" class="btn btn-refund" @click.stop="refund(item)">申请退款</button>
              </div>
            </div>
          </div>
          <div class="order-item__body">
            <div class="rest-time" v-if="item.orderStatus === 0 && item.carPort.carStatus !== 30 && item.payEndTime > now">支付倒计时：{{diffTime(item.payEndTime)}}</div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="" v-if="showDialog">
      <div class="mask" @click="showDialog = false;"></div>
      <div class="dialog-wrapper dialog-refund">
        <div class="dialog-content">
          <div class="dialog-head">
            申请退款
          </div>
          <div class="dialog-body">
            如果您最终没有选购到满意车位的，我们将在您提出退款申请后二十个工作日内原路退还您所预付的全部服务费（无息。如需产生手续费的，将由您个人承担全部手续费用）。
          </div>
          <div class="dialog-foot">
            <button type="button" class="btn btn-prepay" @click="showDialog = false;">取消</button>
            <button type="button" class="btn btn-prepay" @click="refundSubmit">确认申请</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
import dayjs from 'dayjs'
import {webUrl, serverUrl, productName} from './../../config'

export default {
  name: "Order",
  title: '我的订单',
  data(){
    return {
      showDialog: false,
      now: '',
      curOrder: '',
      loading: false,
    }
  },
  computed: mapState({
    project: state => state.project,
    account: state => state.user.account,
    orderStatus: state => state.orderStatus,
    orderData: state => state.user.orderData,
  }),
  // beforeRouteEnter (to, from, next) {
  //   vm.$store.dispatch('fetchOrder', (err, post) => {
  //     next()
  //   })
  // },
  // asyncData({ store, route }) {
  //   console.log('store', store)
  //   return Promise.all([
  //     store.dispatch("fetchOrderList")
  //   ]);
  // },
  mounted(){
    this.fetchOrderList()
  },
  beforeDestroy(){
    clearInterval(this.timer)
  },
  methods: {
    fetchOrderList(){
      this.loading = true
      this.$store.dispatch("fetchOrderList", {
        projectId: this.project.id
      }).then(res => {
        this.now = res.data.now
        this.timer = setInterval(function(){
          this.now += 1000
        }.bind(this), 1000)
        this.loading = false
      }, res => {
        this.loading = false
        if(res.code === 1012){
          this.$router.replace({path: '/user/login', query: { url: '/user/order'}})
        }
        this.$toast(res.msg)
      })
    },
    diffTime(payEndTime){
      // console.log('payEndTime', payEndTime)
      let nowTime = this.now
      let hour = dayjs(payEndTime).diff(dayjs(nowTime), 'hour')
      let minute = dayjs(payEndTime).subtract(hour, 'hour').diff(dayjs(nowTime), 'minute')
      let second = dayjs(payEndTime).subtract(hour, 'hour').subtract(minute, 'minute').diff(dayjs(nowTime), 'second')
      var str = `${hour}小时${minute}分${second}秒`
      //倒计时结束，刷新数据
      if(hour === 0 && minute === 0 && second === 0){
        clearInterval(this.timer)
        this.fetchOrderList()
      }
      // console.log(str)
      return str
    },
    dayjs(stamp) {
      return dayjs(stamp).format('YYYY-MM-DD HH:mm')
    },
    refund(item) {
      this.showDialog = true
      this.curOrder = item
    },
    refundSubmit(){
      this.showDialog = false
      console.log('curOrder', this.curOrder)
      this.$store.dispatch('updateOrderStatus', {
        id: this.curOrder.id
      }).then(res => {
        this.$toast('申请成功')
        this.fetchOrderList()
        // this.$store.dispatch("fetchOrderList")
      }, res => {
        this.$toast('网络错误')
      })
    },
    // 到订单详情页面
    toDetailPage(id) {
      this.$router.push({path: '/user/orderDetail', query: {id}})
    },
    validPay(item){
      this.$store.dispatch('fetchOrderStatus', {
        id: item.id
      }).then(res => {
        console.log('fetchOrderStatus res', res)
        if(res.data.data.orderStatus === 0){
          this.pay(item)
        }else{
          this.$toast('订单已无法支付')
        }
      }, res => {
        this.$toast('网络错误')
      })
    },
    pay(data){
      console.log('in pay()')
      console.log('data', data)
      let total_fee = data.orderAmount * 100
      // let total_fee = 1
      //微信内调用支付
      let url = `https://wxsso.maifangma.com/cxc/pay.html?body=${productName}&detail=${productName}&total_fee=${total_fee}&out_trade_no=${data.id}&origin_url=${encodeURIComponent(`${webUrl}#/product/pay/result?id=${data.id}`)}&notify_url=${serverUrl}/order/wechatpayreturn`
      console.log('pay url:', url)
      location.href = url
    }
  }
}
</script>
<style lang="scss">
.mask{
  position: fixed;
  z-index: 2000;
  background-color: rgba(0, 0, 0, .4);
  top: 0; left: 0;
  width: 100%; height: 100%;
}
.dialog-wrapper{
  position: fixed;
  width: 80%;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2100;
  background-color: #fff;
  border-radius: 4px;
  
  .dialog-body{
    padding: 1rem;
  }
  .dialog-foot{
    padding: 1rem;
    display: flex; justify-content: space-between;
  }
}

.dialog-refund{
  .dialog-head{
    font-size: 20px; text-align: center;
    padding: 1rem; border-bottom: 1px solid #ddd;
  }
  .dialog-foot{
    padding-bottom: 1.5rem;
    .btn{
      width: 42%; height: 2.2rem; line-height: 1; border-radius: 4px;
    }
  }
}

.order-page{
  height: 100%; overflow-y: auto;
  background-color: #f3f3f3;

  .order-list{
    .order-txt {
      margin-left: .69rem;
    }
    .btn{
      width: 5.75rem; height: 1.88rem; font-size: .875rem; line-height: .875rem; border-radius: 1.88rem;
    }
    .btn-refund{
      color: #E3B689;
      border: 1px solid #E3B689; background-color: transparent;
    }
    p{
      margin: 5px auto;
      &:last-child{
        margin-bottom: 0;
      }
    }
    .order-item{
      background-color: #fff; color: #666; overflow: hidden;
      padding: 1rem 1.31rem; margin-bottom: 0.8rem;
      font-size: 0.875rem;
      .right{
        text-align: right;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
    }
    .order-item__top {
      display: flex;
      justify-content: space-between;
    }
    .order-item-orderNum {
      color: #BABBC9;
    }
    .order-item-orderStatus {
      color: #E3B689;
    }
    .order-item__head {
      margin-top: .75rem;
      display: flex; justify-content: space-between;
      color: #444652;
      line-height: 1.5rem;
    }
    .order-item__bottom{
      border-top: 1px solid #ddd; margin-top: 0.38rem; padding-top: 0.56rem;
      display: flex; justify-content: space-between;
    }
    .order-no{
      color: #BABBC9;
    }
    .rest-time{
      margin-top: 1rem;
      color: #E3B689;
    }
    .prepay-name{
      color: #BABBC9;
    }
    .prepay-price{
      font-size: 1rem;
      color: #FF5656;
    }
    .pay-status{
      color: #33CCBC;
    }
  }
}
@media screen and (max-width: 320px) {
  .order-page .order-list .order-item{
    padding: 1rem 0.7rem; 
  }
}
</style>
