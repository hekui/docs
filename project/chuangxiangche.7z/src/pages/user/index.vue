<template>
  <div class="user-page">
    <div class="user-head">
      <div class="user-bar" @click="go('/user/info')">
        <div class="user-name">
          <span>{{account.userName}}</span><span class="icon-edit-info"></span>
        </div>
        <p>手机号: {{account.phone}}</p>
        <!-- <p>房&nbsp;&nbsp;&nbsp;&nbsp;号：{{account.housesCode && account.housesCode.join('、')}}</p> -->
      </div>
    </div>
    <div class="user-menu">
      <div class="menu-item">
        <router-link to="/user/order">
          <span>我的订单</span>
          <span class="icon-chevron-right"></span>
        </router-link>
      </div>
      <div class="menu-item">
        <router-link to="/invoice">
          <span>申请电子发票</span>
          <span class="icon-chevron-right"></span>
        </router-link>
      </div>
    </div>
    <div class="footer-bar">
      <span @click="logout">退出登陆</span>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
  name: "Login",
  title: '个人中心',
  data(){
    return {
      loading: false,
    }
  },
  computed: mapState({
    project: state => state.project,
    account: state => state.user.account,
  }),
  created(){
    this.fetchUser()
  },
  methods: {
    go(url){
      this.$router.push(url)
    },
    fetchUser(){
      this.loading = true
      this.$store.dispatch('fetchUser', {
        projectId: this.project.id
      }).then(res => {
        this.loading = false
      }, res => {
        this.loading = false
        this.$toast('登陆已过期，请重新登陆')
        this.$router.replace('/user/login')
      })
    },
    logout(){
      this.$store.dispatch('userLogout').then(res => {
        this.$toast('已退出登陆')
        this.$router.push('/')
      }, res => {
        if(res.code === 1012){
          this.$toast('已退出登陆')
          this.$router.push('/')
        }else{
          this.$toast(res.msg || '登出失败')
        }
      })
    }
  }
}
</script>
<style lang="scss">
.user-page{
  height: 100%; position: relative;
  // 16px
  .user-head{
    background: #444652; 
    padding: 0.75rem 1.25rem 0;
    font-family: 'PingFangSC-Regular';
    .user-bar{
      background-image: linear-gradient(224deg, #BCC3D1 0%, #9EA4B1 60%, #969CA8 77%, #969CA8 77%, #969CA8 77%, #8A909C 100%);
      border-radius: 0.625rem 0.625rem 0 0;
      padding: 1.0625rem 0.88rem 2.06rem;
      color: #DEE7EC;
      p{
        font-size: 0.9375rem;
        color: #DEE7EC;
        margin: 0;letter-spacing: 0;
      }
      .btn-logout{
        border: 1px solid #DEE7EC; background-color: transparent; color: #DEE7EC;
      }
    }
    .user-name{
      font-size: 1.125rem; color: #fff;
      margin-bottom: .75rem;
      .icon-edit-info{
        margin-left: 0.75rem;
        font-size: 1rem;
        vertical-align: middle;
      }
    }
  }
  .user-menu{
    .menu-item{
      line-height: 3.28rem;
      padding: 0 1.25rem;
      border-bottom: 1px solid #ddd;
      a{
        display: flex;
        width: 100%;
        color: #333;
        justify-content: space-between;
        [class^="icon-"]{
          font-size: 1.25rem; line-height: inherit; color: #ABABAB;
        }
      }
    }
  }
  .footer-bar{
    position: absolute;
    width: 100%;
    left: 0;
    bottom: 1.75rem;
    color: #999;
    text-align: center;
  }
}
</style>
