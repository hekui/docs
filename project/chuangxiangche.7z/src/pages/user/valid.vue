<template>
  <div class="valid-page">
    <h1>业主认证</h1>
    <div>
      <div class="form-group">
        <input type="text" class="form-control" maxlength="10" v-model="form.userName" placeholder="请输入业主姓名">
      </div>
      <div class="form-group has-feedback has-send">
        <input type="tel" class="form-control" v-model="form.phone" maxlength="11" placeholder="请输入业主手机号">
        <button type="button" class="btn btn-prepay btn-send" :class="{'disabled': isSending || form.phone === ''}" v-if="canSend" @click="sendPhoneCode">发送验证码</button>
        <button type="button" class="btn btn-send btn-sended" v-else>{{seconed}}s</button>
      </div>

      <div class="form-group">
        <input type="tel" class="form-control" maxlength="6" v-model="form.verificationCode" placeholder="验证码">
      </div>
      <div class="house-list">
        <div class="form-group has-feedback has-opt" 
        v-for="(item, index) in form.housesCode"
        :key="index"
        >
          <input type="text" class="form-control" maxlength="11" v-model="item.value" placeholder="房号（格式：10-1-1601）">
          <span class="icon icon-plus" v-if="index == 0" @click="plusHouse"></span>
          <span class="icon icon-minus" v-else @click="minusHouse(index)"></span>
        </div>
      </div>
      <div class="form-agreement" @click="toggleChecked">
        <span class="icon icon-radio" :class="{'checked': isChecked}"></span>我已阅读并同意<router-link to="/user/agreement">《创享车用户注册协议》</router-link>
      </div>
      <button type="button" class="btn btn-prepay" @click="valid">立即认证</button>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
  name: "Valid",
  title: '业主认证',
  data(){
    return {
      isChecked: true,
      isValid: false,
      form: {
        userName: '',
        phone: '',
        verificationCode: '',
        housesCode: [{value: ''}],
      },
      // form: {
      //   userName: '何奎',
      //   phone: '13982271436',
      //   verificationCode: '',
      //   housesCode: [{value: '2-2-2'}],
      // },
      // 发送验证码
      canSend: true,
      isSending: false, // 发送中
      seconed: 60, // 多少秒后可发送短信
      timer: null,
    }
  },
  computed: mapState({
    project: state => state.project,
  }),
  watch: {
    form: {
      deep: true,
      handler: function(newVal){
        this.validate()
      },
    },
    isChecked: function(newVal){
      this.validate()
    },
  },
  created(){
    // 读取缓存
    let cacheForm = window.localStorage.getItem('CXC_CACHE_VALID_FORM')
    if(cacheForm){
      this.form = JSON.parse(cacheForm)
    }
  },
  methods: {
    toggleChecked(){
      this.isChecked = !this.isChecked
    },
    validate(){
      // if(this.isChecked && /^1\d{10}$/.test(this.form.phone) && /^\d{4,6}$/.test(this.form.verificationCode)){
      //   this.isValid = true
      // } else {
      //   this.isValid = false
      // }
      // 缓存form表单
      window.localStorage.setItem('CXC_CACHE_VALID_FORM', JSON.stringify(this.form))
    },
    initSend(){
      clearInterval(this.timer)
      this.canSend = true
      this.seconed = 60
    },
    sendPhoneCode(){
      if(this.form.phone === ''){
        return 
      }
      if(/^1\d{10}$/.test(this.form.phone)){
        if(this.canSend && !this.isSending){
          this.isSending = true

          // setTimeout(function(){
          //   this.isSending = false
          //   this.canSend = false

          //   this.timer = setInterval(function(){
          //     this.seconed --
              
          //     if(this.seconed === 0){
          //       this.initSend()
          //     }
          //   }.bind(this), 1000)
          // }.bind(this), 1000)
          this.form.verificationCode = ''
          this.$store.dispatch('sendPhoneCode', {
            phone: this.form.phone
          }).then(res => {
            this.isSending = false
            this.canSend = false

            this.timer = setInterval(function(){
              this.seconed --
              if(this.seconed === 0){
                this.initSend()
              }
            }.bind(this), 1000)
          }, res => {
            this.isSending = false
            this.canSend = true
            this.$toast('发送失败，请重试')
          })
        }
      }else{
        this.$toast('手机号不正确')
      }
    },
    plusHouse(){
      this.form.housesCode.push({value: ''})
    },
    minusHouse(index){
      this.form.housesCode.splice(index, 1)
    },
    valid(){
      let url = this.$route.query.url
      let params = {
        projectId: this.project.id,
        userName: this.form.userName,
        phone: this.form.phone,
        verificationCode: this.form.verificationCode
      }
      if(params.userName === ''){
        this.$toast('请输入业主姓名')
        return ; 
      }
      if(params.phone === ''){
        this.$toast('请输入业主手机号')
        return ; 
      }
      if(params.verificationCode === ''){
        this.$toast('请输入验证码')
        return ;
      }
      let hasEmpty = false
      params.housesCode = this.form.housesCode.map(item => {
        if(item.value === ''){
          hasEmpty = true
        }
        return item.value
      })
      if(hasEmpty){
        this.$toast('请输入房号')
        return ; 
      }
      if(!this.isChecked){
        this.$toast('请阅读并同意《创享车用户注册协议》')
        return ;
      }

      // 增加unionid openid
      let cacheSSOUser = window.localStorage.getItem('CXC_CACHE_WXSSO_USER')
      if(cacheSSOUser){
        let cacheUser = JSON.parse(cacheSSOUser)
        params.unionid = cacheUser.unionid
        params.openid = cacheUser.uid
      }
      console.log('params', params)
      this.$store.dispatch('userReg', params).then(res => {
        window.localStorage.removeItem('CXC_CACHE_VALID_FORM')
        this.$toast('认证成功')
        if(url){
          this.$router.replace(url)
        }
      }, res => {
        if(res.code === 1035){
          this.$toast('验证码错误')
        }else{
          this.$toast('认证失败')
        }
      })
    }
  }
}
</script>
<style lang="scss">
.valid-page{
  padding: 1.88rem 1.13rem;
  h1{
    font-size: 1.625rem; margin-top: 0; margin-bottom: 3rem; font-weight: 400;
  }
  .form-group{
    border-bottom: 1px solid #ddd;
  }
  .form-control{
    border: none; border-radius: 0; box-shadow: none;
    &:focus{
      border-color: #999; 
      box-shadow: none;
    }
  }
  .has-send{
    padding-right: 8rem;
  }
  .has-feedback{
    .btn-send{
      width: 7rem; height: 2.06rem; font-size: .875rem; line-height: 1; border-radius: 4px;
      position: absolute; right: 0; top: 0; 
      &.btn-sended{
        background-color: #f9f9f9; color:#999;
      }
    }
  }
  .has-opt{
    padding-right: 2.31rem;
  }
  .icon-plus, .icon-minus{
    width: 1.31rem; height: 1.31rem; margin-right: .5rem;
    position: absolute; right: 0; top: 0.5rem;
  }
  .icon-plus{
    background-image: url('./../../assets/images/icon-plus.png');
  }
  .icon-minus{
    background-image: url('./../../assets/images/icon-minus.png');
  }
  .form-agreement{
    margin-bottom: 3rem;
    a{
      color: #E3B689;
    }
  }
}
</style>
