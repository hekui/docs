<template>
  <div class="page-booking">
    <div class="slogan">创享车服务 畅享车生活</div>
    <div class="tips">
      <div>添加“创享车”服务官微信好友</div>
      <div>一对一服务，及时响应预约</div>
    </div>
    <div class="qr-code">
      <img src="./../../assets/images/qrcode-booking.jpg">
    </div>
    <div class="remind">
      <div class="label">预约说明：</div>
      <div>1、服务时间为白天9：00-18：00。</div>
      <div>2、可预约周末服务。暂不提供节假日服务，春节假期预约时间以创享车服务公告为准。</div>
      <div>3、预约上门服务应至少提前2小时。</div>
      <div>4、更多问题请咨询“创享车”服务官。</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Booking',
  title: '预约汽车服务'
}
</script>
<style lang="scss" scoped>
.page-booking {
  position: relative;
  height: 100%;
  min-height: 36rem;
  color: #fff;
  text-align: center;
  background: url('./../../assets/images/booking-bg.jpg') no-repeat center/cover;
  overflow: hidden;
  .slogan {
    margin-top: 3.06rem;
    font-size: 1.88rem;
    line-height: 2.63rem;
    span {
      margin: 0 .3rem;
    }
  }
  .tips {
    margin-top: 1.06rem;
    font-size: 1.06rem;
    line-height: 1.5rem;
  }
  .qr-code {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 10.63rem;
    height: 10.63rem;
    transform: translate(-50%, -50%);
    img {
      width: 100%;
      height: 100%;
    }
  }
  .remind {
    padding: .69rem .25rem 0 .94rem;
    position: absolute;
    bottom: 1.25rem;
    left: 1.19rem;
    right: .94rem;
    line-height: 1.31rem;
    font-size: .94rem;
    text-align: justify;
    background: rgba(12, 20, 31, .5);
    .label {
      font-weight: bold;
    }
  }
}
</style>
