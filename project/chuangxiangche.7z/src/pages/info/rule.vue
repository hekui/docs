<template>
  <div class="rule-page">
    <h1>活动须知</h1>
    <div v-html="content"></div>
    <div class="fix-bar">
      <button type="button" class="btn btn-prepay" @click="back()">返回</button>
    </div>
  </div>
</template>

<script>

import {mapState} from 'vuex'
export default {
  name: 'Rule',
  title: '活动须知',
  computed: {
    content() {
      const id = this.$route.query.projectId || ''
      const pjt = this.$store.getters.activityNotice(id) || {}
      const info = pjt.promotionsNotice || ''
      return info.replace(/\n/g, '<br>')
    },
  },
  methods: {
    back(){
      this.$router.go(-1)
    }
  }
}
</script>
<style lang="scss">
.rule-page{
  padding: 1.88rem 1.25rem 3rem; font-size: 0.9375rem;
  h1{
    margin-top: 0; margin-bottom: 1.81rem; font-weight: 400; font-size: 1.625rem;
  }
  p {
    line-height: 1.38rem;
      margin-bottom: 2rem;
  }
}
</style>
