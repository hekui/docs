<template>
  <div class="page-home">
    <!-- <p>首页 {{count}}</p>
    <div class="btns">
      <router-link type="button" class="btn btn-info btn-block" to="/product">开始选车位</router-link>
      <router-link type="button" class="btn btn-info btn-block" to="/product/payresult">支付结果</router-link>
      
      <router-link type="button" class="btn btn-info btn-block" to="/user/valid">登陆页面</router-link>
      <router-link type="button" class="btn btn-info btn-block" to="/user/order">我的订单</router-link>
      <button type="button" class="btn btn-info btn-block" @click="test">调用toast</button>
      <button type="button" class="btn btn-info btn-block" @click="pay1">mfm支付测试</button>
    </div> -->

    <div class="logo-wrapper">
      <div class="logo">
        <img src="./../../assets/images/logo.png" alt="创享车">
      </div>
      <!-- <div class="logo-other">
        <img :src="project.logoPic" :alt="project.name">
      </div> -->
      <!-- <p class="slogan" v-if="project.slogan">{{project.slogan}}</p> -->
    </div>
    <div class="index-info center">
      <!-- <p class="num">还有<span>{{amount}}</span>个车位可以供预选</p> -->
      <div>
        <button type="button" class="btn btn-full" @click="goProduct()">开始预选车位</button>
        <button type="button" class="btn" @click="goBooking()">预约汽车服务</button>
        <button type="button" class="btn" @click="goUserCenter()">个人中心</button>
        <!-- <button type="button" class="btn" @click="go('/user/order')">我的订单</button> -->
        <!-- <button type="button" class="btn" @click="payBack">支付回调</button> -->
        <!-- <button type="button" class="btn" @click="pay">支付 - test</button> -->
      </div>
      <!-- <p><router-link to="/info/rule" class="fs15">活动须知</router-link></p> -->
    </div>
  </div>
</template>

<script>
// import api from './../../api'
import Vue from 'vue'
// import Toast from './../../components/toast/'
// Vue.use(Toast)
import cookie from 'js-cookie'

import {mapState} from 'vuex'
export default {
  name: 'Home',
  title: '三利麓山城',
  computed: mapState({
    account: state => state.user.account,
    amount: state => state.product.amount || 0,
    project: state => state.project,
  }),
  created(){
    console.log('project', this.project)
    // this.$store.dispatch('fetchPSAmount', {
    //   projectId: 1
    // }, res => {})
    // 如果有项目信息
    let projectId = this.$route.query.projectId || ''
    if(projectId){
      this.fetchProjectInfo()
    }
  },
  methods: {
    fetchProjectInfo(projectId){
      // 获取项目信息
      this.$store.dispatch('fetchProject', {
        code: 'wkygc',
        id: projectId
      })
    },
    test: function(){
      this.$toast('测试的测试的测试的测试的测<br>试的测试的测试的测试的测试的测试的')
    },
    pay(data){
      console.log('in pay()')
      data.id = '1111'
      console.log('data', data)
      // let total_fee = data.orderAmount * 100
      let total_fee = 1
      //微信内调用支付
      let url = `https://wxsso.maifangma.com/cxc/pay.html?body=买房吗-三利麓山城专场&detail=意向金&total_fee=${total_fee}&out_trade_no=${data.id}&origin_url=${encodeURIComponent(location.href + `/result?id=${data.id}`)}&notify_url=${location.origin}/order/wechatpayreturn`
      console.log('pay url:', url)
      location.href = url
    },
    
    // payBack(){
    //   let params = {
    //     aaa: '111'
    //   }
    //   api.post('/order/wechatpayreturn', params).then(res => {
    //     console.log('payBack res', res)
    //   })
    // },
    goProduct(){
      let url
      if(this.project.id){ // 有项目信息
        url = '/product?projectId='+ this.project.id
      }else{
        url = '/case'
      }
      if(this.account.id){
        if(this.account.userName){
          this.$router.push(url)
        }else{
          this.$toast('请先完善业主信息')
          this.$router.push({path: '/user/info', query: { url: url }})
        }
      }else{
        this.$router.push({path: '/user/valid', query: { url: url }})
      }
    },
    goBooking(){
      this.$router.push('/booking')
    },
    goUserCenter(){
      if(this.account.id){
        this.$router.push('/user/index')
      }else{
        this.$router.push('/user/login')
      }
    }
  }
}
</script>
<style lang="scss">
.page-home{
  height: 100%;
  overflow-y: auto; 
  background-image: url('./../../assets/images/index-bg.jpg');
  background-size: 100% auto;
  background-position: center;
  .btns{
    margin-bottom: 15px;
  }

  .logo-wrapper{
    height: 240px; margin-top: 80px; overflow: hidden;
    img{
      width: 100%; margin: 0 auto; display: block;
    }
    .logo{
      width: 8.75rem; margin: 0 auto 1rem;
    }
    .logo-other{
      width: 60%; max-width: 15.8125rem; margin: 0 auto;
      
    }
  }
  .slogan{
    color: #fff; font-size: 18px; text-align: center;
  }

  .btn{
    width: 100%; height: 2.75rem; margin: 0 auto .8rem; font-size: 1.125rem;
    border: 1px solid #E3B689; color: #E3B689; background-color: transparent;
  }
  .btn-full{
    background-color: #E3B689; color: #fff;
  }
  .num{
    color: #999;
    span{
      color: #E3B689; margin: 0 .5rem;
    }
  }
  .index-info{
    width: 15.0625rem; margin: 0 auto;
    a{
      color: #ddd;
    }
  }
}
@media screen and (max-width: 320px){
  .page-home .logo-wrapper{
    margin-top: 95px; height: 170px;
  }
}
@media screen and (max-width: 320px){
  .page-home .logo-wrapper{
    margin-top: 95px; height: 170px;
  }
}
// @media screen and (min-width: 1024px){
//   .page-home .logo-wrapper{
//     height: 320px;
//   }
// }
</style>
