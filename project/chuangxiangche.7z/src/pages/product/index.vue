<template>
  <div class="product-page" :class="{'choosed': choosedItem.id && !inputState}">    
    <div class="fix-top">
      <div class="search-bar">
        <div class="form-group has-feedback" :class="{'has-content': keyword}">
          <input type="text" class="form-control"
          ref="input" 
          maxlength="20"
          v-model="keyword" 
          @focus="inputFocus"
          @blur="inputBlur" 
          @keyup.enter="search" 
          id="keyword" 
          placeholder="请输入车位编号">
          <span class="icon icon-search"></span>
          <span class="icon icon-search-clear" @click="clearKeyword"></span>
        </div>
        <span @click="search" class="search-text">搜索</span>
      </div>
      <div class="ps-wrapper" v-if="!loadingImg">
        <div class="ps-inner">
          <div v-if="imgList.length === 0">暂无车位图片</div>
          <div v-else class="ps-item" v-for="(item, index) in imgList" :key="index" @click="previewImage(item.picUrl)">
            <span class="icon icon-ps"></span> <span>{{item.picName}}</span>
            <!-- <img :src="item.picUrl" width="100%" :alt="item.picName" /> -->
          </div>
        </div>
      </div>
    </div>
    <!-- <div style="width:100%; height:0px; overflow:hidden">
      <img v-for="(item, index) in imgList" :key="index" :src="item.picUrl" width="100%" alt="图片">
    </div> -->
    <div class="list-wrapper" ref="plWrapper" @scroll="onScroll">
      <div class="pl-list" ref="plList">
        <!-- 车位状态 可预订、已预订、已出售 （0，20，30） -->
        <!-- 锁定状态 1:未锁定 2:已锁定 -->
        <div v-if="psList.length > 0" class="btns">
          <div class="btn-box" 
            v-for="(item, index) in psList" v-if="index < 1000" :key="index" 
            :class="[{'cur': choosedItem.id === item.id}]">
            <button type="button" class="btn" 
            :class="[{'btn-default': item['carStatus'] === 0}, {'btn-warning': item['lockStatus'] === 2 || item['carStatus'] === 20}, {'btn-danger': item['carStatus'] === 30}]" 
            @click="choose(item)">
            <span>{{item.carNum}}</span>
            </button>
          </div>
        </div>
        <div v-if="loaded && !loading && psList.length === 0 " class="loading">没有数据</div>
        <div v-if="loading" class="loading">努力加载中...</div>
        <div v-if="loaded && page.totalPage > 1 && !page.hasNext" class="loading">没有更多数据了</div>
      </div>
    </div>
    
    <!-- <div class="list">
      <div class="mine-list">
        我的已选车位：<button type="button" class="btn" 
          v-for="(item, index) in pList" v-if="item.isChoose" :key="index" 
          :class="[{'btn-default': item['carStatus'] === 1}, {'btn-warning': item['carStatus'] === 2}, {'btn-danger': item['carStatus'] === 3}, {'btn-success': item['isChoose']}]" 
          :disabled="item['carStatus'] > 1" 
          @click="choose(index)">{{item.name}} </button>
      </div>
    </div> -->
    <!-- <div>
      <button type="button" class="btn btn-success btn-block" @click="pay">提交订单</button>
    </div>
    <div>
      <button type="button" class="btn btn-success btn-block" :disabled="chooseCount === 0">提交选择</button>
    </div> -->
    <div class="fix-bar">
      <div class="btns">
        <button type="button" class="btn btn-danger">已售</button>
        <button type="button" class="btn btn-warning">已预订</button>
        <button type="button" class="btn btn-default">可选</button>
      </div>
      <transition name="slideInUp">
        <div v-if="choosedItem.id && !inputState">
          <div class="props">
            <div class="left">
              <p class="strong">车 位 号：{{choosedItem.carNum}}</p>
              <p>车位面积：{{choosedItem.carArea}}㎡</p>
              <p>车位类型：{{choosedItem.carType}}</p>
              <p>车位价格：¥{{choosedItem.carPrice}}元</p>
              <p>套餐价格：¥{{choosedItem.carPrice + project.packPrice}}元(车位价格 + <router-link to="/info/gift">后期服务包</router-link>)</p>
            </div>
            <div class="right">
              <p>意向金：<span class="pre-price">￥{{project.prepayments}}元</span></p>
            </div>
          </div>
          <div>
            <button type="button" class="btn btn-prepay" :class="{'disabled': choosedItem.carStatus > 0 || choosedItem.lockStatus === 2}" @click="presell">支付预选车位意向金</button>
          </div>
        </div>
      </transition>
    </div>
  </div>
</template>
<script>
import {mapState} from 'vuex'
// import './../../assets/js/previewImage.min.js'
import previewImage from './../../assets/js/previewImage.js'

export default {
  name: 'Product',
  title: '预选车位',
  data(){
    return {
      keyword: '',
      inputState: false, // 搜索输入框是否激活
      loaded: false,
      loading: false,
      loadingImg: false,
      needPay: false,
      // choosedItem: '',
      psList: [],
      page: {
        pageSize: 100,
        curPage: 1,
        totalPage: 1,
        hasNext: false
      }
    }
  },
  computed: mapState({
    account: state => state.user.account,
    choosedItem: state => state.product.choosePS,
    project: state => state.project,
    imgList: state => state.product.imgList,
  }),
  created(){
    let pid = this.$route.query.projectId
    let url = '/product?projectId='+ pid
    if(this.account.id){
      if(!this.account.userName){
        this.$toast('请先完善业主信息')
        this.$router.push({path: '/user/info', query: { url: url }})
      }
    }else{
      this.$router.push({path: '/user/login', query: { url: url }})
    }
  },
  mounted(){
    this.fetchProduct();
    this.fetchProductImg();
    // console.log('previewImage', previewImage)
  },
  methods: {
    previewImg(index){
      var obj = {
        urls : this.imgList,
        current : this.imgList[index]
      };
      previewImage.start(obj);
    },
    previewImage(url){
      // alert(url)
      let urls = this.imgList.map(item => {
        return item.picUrl
      })
      wx.previewImage({
        current: url, // 当前显示图片的http链接
        urls: urls // 需要预览的图片http链接列表
      });
    },
    inputFocus(){
      this.inputState = true
    },
    inputBlur(){
      this.inputState = false
    },
    onScroll(){
      // console.log('scroll')
      if(this.page.hasNext){
        let wrapper = this.$refs.plWrapper, 
            list = this.$refs.plList;
        let wrapperHeight = wrapper.clientHeight;
        let listHeight = list.clientHeight;
        let scrollTop = wrapper.scrollTop;
        let bottom = listHeight - (scrollTop + wrapperHeight)
        if(bottom < 50){
          this.fetchProduct()
        }
      }
    },
    fetchProduct(){
      // console.log('this.$refs.input', this.$refs)
      this.$refs.input.blur();
      this.inputState = false;
      let param = {
        carNum: this.keyword,
        projectId: this.project.id,
        curPage: this.page.curPage,
        pageSize: this.page.pageSize
      }
      if(!this.loading){
        this.loading = true
        this.$store.dispatch('fetchProduct', param).then(res => {
          this.psList = this.psList.concat(res.data.list)
          this.page.totalPage = res.data.totalPage
          if(res.data.hasNext){
            this.page.curPage += 1
          }
          this.page.hasNext = res.data.hasNext
          
          this.loading = false
          this.loaded = true
        }, res => {
          console.log('fetchProduct fail res', res)
          if(res.code === 1012){
            this.$router.replace({path: '/user/valid', query: { url: '/product?projectId='+ this.project.id}})
          }
          this.$toast(res.msg)
          this.loading = false
          this.loaded = true
        })
      }
    },
    fetchProductImg(){
      this.loadingImg = true
      this.$store.dispatch('fetchProductImg', {
        projectId: this.project.id
      }).then(res => {
        this.loadingImg = false
      }, res => {
        if(res.code === 1012){
          this.$router.replace({path: '/user/valid', query: { url: '/product?projectId='+ this.project.id}})
          this.$toast('登陆已过期，请重新登陆')
        }else{
          this.$toast(res.msg)
        }
        this.loadingImg = false
      })
    },
    clearKeyword(){
      this.keyword = ''
      this.psList = []
      this.page.curPage = 1
      this.fetchProduct()
    },
    search(){
      this.page.curPage = 1
      this.psList = []
      this.$store.commit('productSet', {
        target: 'choosePS',
        data: {}
      })
      this.fetchProduct()
    },
    choose(item){
      if(item.id === this.choosedItem.id){
        this.$store.commit('productSet', {
          target: 'choosePS',
          data: {}
        })
      }else{
        this.$store.commit('productSet', {
          target: 'choosePS',
          data: item
        })
      }
    },
    // pay(){
    //   //微信内调用支付
    //   location.href = 'https://prj.chuangjia.me/wxsso/pay.html?body=付款&total_fee=1&out_trade_no=out_trade_no123&origin_url=' + encodeURIComponent(location.href) + '&notify_url=' + location.origin + '/industryNotify';
    // }
    presell(){
      if(this.choosedItem && this.choosedItem['carStatus'] === 0){
        this.$router.push('/product/pay?projectId='+ this.project.id)
      }
    },
  }
}
</script>
<style lang="scss">
.product-page{
  padding-top: 5.875rem;
  padding-bottom: 49px; height: 100%; overflow-y: auto;
  background-color: #eee;
  &.choosed{
    padding-bottom: 220px;
  }
  .fix-top{
    position: fixed;
    top: 0; left: 0; width: 100%;
    background-color: #fff;
    z-index: 1000;
  }
  .btns .btn{
    height: 2.05rem; border-radius: 4px; line-height: 1rem; overflow: hidden; position: relative;
    // -webkit-tap-highlight-color:transparent;
    // &::before,&::after{
    //   content: ''; width: 12px; height: 100%; background-size: auto 100%; position: absolute; top: 0; left: 0; 
    //   z-index: 1;
    // }
    // &::after{
    //   left:auto; right: 0; background-position: right;
    // }
    span{
      z-index: 10; position: relative;
    }
  }
  .btn-default{
    background-color: #fff;
  }
  .btn-danger{
    background-color: #F05E5A;
  }
  .btn-warning{
    background-color: #F5A623;
  }
  .btn-default{
    &::before,&::after{ 
      background-color: #fff; 
      // background-image:url('./../../assets/images/btn-default.png');
    }
  }
  .btn-danger{
    &::before,&::after{ 
      background-color: #F05E5A; 
      // background-image: url('./../../assets/images/btn-danger.png');
    }
  }
  .btn-warning{
    &::before,&::after{ 
      background-color: #F5A623; 
      // background-image:url('./../../assets/images/btn-warning.png');
    }
  }
}
.search-bar{
  padding: 0.7rem 4.25rem 0.7rem 1.25rem; background-color: #fff;
  position: relative;
  .search-text{
    position: absolute; right: 1.25rem; top: 0.7rem;
    line-height: 2rem; color: #E3B689;
  }
  .form-group{
    margin-bottom: 0;
    background-color: #eee;
    border-radius: 4px;
  }
  .form-control{
    height: 2rem;
    background-color: transparent;
    box-shadow: none;
    border: none;
    &:focus{
      border-color: none;
      box-shadow: none;
    }
  }
  .has-feedback .form-control {
    padding-left: 2.4rem;
    padding-right: 12px;
  }
  .icon-search{
    position: absolute; color: #999;
    left: .5rem; top: .3rem;
    width: 1.4rem; height: 1.4rem;
    background-image: url('./../../assets/images/icon-search.png');
  }
  .icon-search-clear{
    display: none;
    position: absolute; color: #999;
    right: .5rem; top: .4rem;
    width: 1.2rem; height: 1.2rem;
    background-image: url('./../../assets/images/icon-search-clear.png');
  }
  
  .has-content {
    .form-control {
      padding-right: 2.4rem;
    }
    .icon-search-clear{
      display: block
    }
  }
}

.ps-wrapper{
  padding:0rem 1.38rem .7rem; height: 2.45rem;
  overflow: hidden; background-color: #fff; color: #E3B689;
  position: relative;
  &::after{
    content: '';
    position: absolute;
    bottom: 0; left: 0; width: 100%; height: 8px;
    background-color: #fff;
  }
  // ::-webkit-scrollbar {
  //   width: 0;
  //   height: 0;
  //   display: none;
  // }
  .ps-inner{
    display: box;
    display: -webkit-box;
    overflow-x: auto;
    overflow-y: hidden;
    touch-action: manipulation; 
    -webkit-overflow-scrolling: touch;
    padding-bottom: 10px;

  }
  .ps-item{
    height: 1.75rem; line-height: 1; padding: 0.375rem 0.375rem .475rem 0;
    display: block; margin-right: 1rem; position: relative; white-space: nowrap;
    img{
      opacity: 0; 
      position: absolute; width: 100%; height: 100%; top: 0; left: 0;
    }
  }
  .icon-ps{
    width: .75rem; height: .75rem; margin-right: .35rem;
    background-image: url('./../../assets/images/icon-ps.png');
  }
}

.list-wrapper{
  height: 100%; overflow-y: auto;
}
.pl-list{
  
  padding-top: 15px; 
  padding-left: 1rem;
  .loading{
    text-align: center;  color: #999; height: 3rem; line-height: 3rem; padding-right: 1rem;
  }
  .btn-box{
    display: inline-block; padding: 3px;
    border: 2px solid transparent;
    border-radius: 2px;    
    margin:0 0 5px auto; 
    &.cur{
      border-color: #33CCBC;
    }
  }  
}


.fix-bar{
  // position: fixed;
  // bottom: 0; left: 0; width: 100%;
  // box-shadow: 0 0 5px rgba(0, 0, 0, .2);
  background-color: #fff; z-index: 1000;
  .btns{
    background: #F1F0F0; padding: 0.56rem 1rem; border-top: 1px solid #ddd; border-bottom: 1px solid #ddd;
    display: flex; justify-content: space-around;
    .btn{
      height: 1.75rem; width: 4.2rem;
    }
  }
  .props{
    height: 7.75rem; margin: 0 10px; overflow: hidden;
    // display: flex; justify-content: space-between;
    font-size: .875rem;
    color: #BABBC9;
    position: relative;
    .strong{
      font-size: 1rem;
      color: #444652;
      margin-top: .5rem;
    }
    p{margin:0 auto .5rem auto; line-height: 1;}
    .right{
      position: absolute; right: 0; top: 0;
      margin-top: 38px; text-align: right;
    }
    .pre-price{
      font-size: 20px; color: #FF5656;
    }
  }
  
}

.slideInUp-enter-active, .slideInUp-leave-active {
  height: 171px;
  transition: all .3s;
}
.slideInUp-enter, .slideInUp-leave-to /* .fade-leave-active below version 2.1.8 */ {
  height: 0;
}
</style>