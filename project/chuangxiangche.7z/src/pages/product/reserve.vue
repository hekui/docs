<template>
  <div class="page-result">
    <div v-if="loading">
      <div class="loading">
        正在查询订单状态...
      </div>
    </div>
    <div v-else>
      <div class="pay-success" v-if="payStatus">
        <div class="center">
          <span class="icon icon-pay-success"></span>
        </div>
        <h3 class="center fs20">支付成功！</h3>
        <p class="center">恭喜你获得车位优先认购权。</p>
      </div>
      <div class="pay-fail" v-else>
        <div class="center">
          <span class="icon icon-pay-fail"></span>
        </div>
        <h3 class="center fs20">支付失败！</h3>
        <p class="center">网络开小差啦！请您再次尝试！</p>
      </div>
    </div>
    <div class="fix-bar">
      <button type="button" class="btn btn-prepay" @click="go('/')">返回首页</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data(){
    return {
      loading: true,
      payStatus: false,
    }
  },
  created(){
    // console.log(this.$route.query.id)
    this.fetchOrderStatus()
  },
  methods: {
    fetchOrderStatus(){
      this.loading = true
      this.$store.dispatch('fetchOrderStatus',{
        id: this.$route.query.id || ''
      }).then(res => {
        // alert('ok')
        this.loading = false
        this.payStatus = res.data.data.orderStatus >= 20; // 20 已支付
      }, res => {
        // alert('fail')
        this.loading = false
        if(res.code === 1012){
          this.$router.replace({path: '/user/login', query: { url: '/product/pay/result'}})
          this.$toast('登陆已过期，请重新登陆')
        }
      })
    },
    go(path){
      this.$router.push(path)
    }
  }
}
</script>
<style lang="scss">
.page-result{
  padding: 2rem 1.13rem 3rem;
  .loading{
    margin-top: 10rem; text-align: center; color: #999;
  }
  .red{
    color: #FF5656;
  }
  .note{
    color: #BABBC9;
  }
  .icon-pay-success{
    width: 3.44rem; height: 3.44rem;
    background-image:url('./../../assets/images/icon-pay-success.png');
  }
  .icon-pay-fail{
    width: 3.44rem; height: 3.44rem;
    background-image:url('./../../assets/images/icon-pay-fail.png');
  }
  .fix-bar{
    position: fixed;
    bottom: 0; left: 0; width: 100%;
  }
}
</style>
