<template>
  <div class="page-case">
    <div class="case-wrapper">
      <!-- <div class="case-item">
        <div class="case-main">
          <div class="case-cover">
            <img src="./../../assets/images/logo.png" alt="">
          </div>
          <div class="case-info">
            <p class="title">三利麓山城</p>
            <p class="slogan">健康之城 生活之城</p>
            <p class="amount">还有 <span class="red">15</span> 个车位可供预选</p>
          </div>
        </div>
        <div class="case-footer">
          <router-link to="/info/rule?projectId=123">
            <span>活动须知</span>
            <span class="icon-chevron-right"></span>
          </router-link>
        </div>
      </div> -->
      <div class="case-item" v-for="item in projectList" :key="item.id">
        <div class="case-main" @click="goProduct(item)">
          <div class="case-cover">
            <img :src="item.logoPic" alt="">
          </div>
          <div class="case-info">
            <p class="title">{{item.name}}</p>
            <p class="slogan">{{item.slogan}}</p>
            <p class="amount">还有 <span class="red">{{item.carportNum}}</span> 个车位可供预选</p>
          </div>
        </div>
        <div class="case-footer">
          <router-link :to="'/info/rule?projectId='+ item.id">
            <span>活动须知</span>
            <span class="icon-chevron-right"></span>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
import {webUrl, serverUrl, productName} from './../../config'
export default {
  name: 'Case',
  title: '选择项目',
  data(){
    return {
      
    }
  },
  computed: mapState({
    projectList: state => state.projectList,
  }),
  created(){
    this.fetchProjectList()
  },
  methods: {
    fetchProjectList(){
      this.$store.dispatch('fetchProjectList', {}).then(res => {

      }, res => {
        if(res.code === 1012){
          this.$toast('请登录后操作')
          this.$router.push('/')
        }else{
          this.$toast('项目列表加载失败，'+ res.msg || '')
        }
      })
    },
    goProduct(item){
      this.$store.commit('indexSet', {
        target: 'project',
        data: item
      })
      this.$router.push('/product?projectId='+ item.id)
    }
  }
}
</script>
<style lang="scss">
.red{
  color: #FB545D;
}
.page-case{
  background-color: #f3f3f3;
  height: 100%; overflow-y: auto;
  .case-wrapper{
    overflow: hidden;
  }
  .case-item{
    background-color: #fff;
    padding: 20px 20px 0;
    margin-bottom: 10px;
  }
  .case-main{
    width: 100%;
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
  }
  .case-cover{
    background: #00A699;
    width: 100px; height: 74px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    overflow: hidden;
    img{
      width: 100%; 
      // max-height: 100%;
    }
  }
  .case-info{
    flex-grow: 1; margin-left: 13px;
    p{
      margin: 0;
    }
    .title{
      font-family: PingFangSC-Regular;
      font-size: 17px;
      color: #444652;
      margin-bottom: 6px;
    }
    .slogan{
      font-family: PingFangSC-Regular;
      font-size: 14px;
      color: #666666;
      margin-bottom: 6px;
    }
    .amount{
      font-family: PingFangSC-Regular;
      font-size: 14px;
      color: #BABBC9;
    }
  }
  .case-footer{
    border-top: 1px solid #EEEEEE;
    line-height: 40px;
    a{    
      width: 100%;
      display: flex;
      justify-content: space-between;
      font-family: PingFangSC-Regular;
      font-size: 14px;
      color: #BABBC9;
      [class^="icon-"]{
        font-size: 1.25rem; line-height: inherit; color: #ABABAB;
      }
    }
  }
}
</style>
