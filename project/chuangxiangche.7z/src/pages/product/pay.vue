<template>
  <div class="page-pay">
    <div class="fix-top">
      <div class="pay-info-head">
        <div>
          <span class="strong">车 位 号：{{choosedItem.carNum}}</span>
        </div>
        <div>
          <span class="pre-name">意向金</span> <span class="pre-price"><span class="fs14">¥</span> {{project.prepayments}} <span class="fs14">元</span></span>
        </div>
      </div>
      <div class="fs15">
        <p>车位面积：{{choosedItem.carArea}}㎡</p>
        <p>车位类型：{{choosedItem.carType}}</p>
        <p>车位价格：¥{{choosedItem.carPrice}}元</p>
        <p>套餐价格：¥{{choosedItem.carPrice + project.packPrice}}元</p>
        <p class="gift-price-tips">(车位价格 + <router-link to="/info/gift">后期服务包</router-link>)</p>
      </div>
    </div>
    <div class="rule">
      <p>预选及缴费须知：</p>
      <p v-html="content"></p>
    </div>
    <div class="fix-bar">
      <div class="rule-agree">
        <div class="rule-check checked" @click="toggleChecked">
          <span class="icon icon-radio" :class="{'checked': isChecked}"></span>我已阅读预选及缴费须知
        </div>
      </div>
      <button type="button" :class="['btn', 'btn-prepay', {'disabled': !isChecked}, {'submit': isSubmit}]" @click="order"><i class="icon-loading"></i>确认支付</button>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
import {webUrl, serverUrl, productName} from './../../config'
export default {
  name: 'Pay',
  title: '预选车位',
  data(){
    return {
      isChecked: false,
      isSubmit: false,
    }
  },
  computed: mapState({
    project: state => state.project,
    choosedItem: state => state.product.choosePS,
    content() {
      const info = this.project.reserveNotice
      return info ? info.replace(/\n/g, '<br>'):''
    },
  }),
  created(){
    if(!this.choosedItem.id){
      this.$router.replace('/product?projectId='+ this.project.id)
    }
  },
  methods: {
    toggleChecked(){
      this.isChecked = !this.isChecked
    },
    order(){
      if(this.isChecked && !this.isSubmit){
        let params = {
          id: this.choosedItem.id
        }
        this.isSubmit = true
        this.$store.dispatch('createOrder', params).then(res => {
          console.log('createOrder success res', res)
          // this.$store.dispatch('fetchProduct', {
          //   carNum: '',
          //   projectId: this.project.id
          // })
          this.$toast('订单创建成功，进行支付')
          this.isSubmit = false
          this.pay(res.data)
        }, res => {
          this.isSubmit = false
          console.log('createOrder fail res', res)
          if(res.code === 1012){
            this.$router.replace({path: '/user/login', query: { url: '/product?projectId='+ this.project.id}})
            this.$toast('登陆已过期，请重新登陆')
          }else{
            this.$toast('生成订单失败，请重试！')
          }
        })
      }
    },
    pay(data){
      console.log('in pay()')
      console.log('data', data)
      let total_fee = data.orderAmount * 100
      // let total_fee = 1
      //微信内调用支付
      console.log(location.href)
      let url = `https://wxsso.maifangma.com/cxc/pay.html?body=${productName}&detail=${productName}&total_fee=${total_fee}&out_trade_no=${data.id}&origin_url=${encodeURIComponent(`${webUrl}#/product/pay/result?projectId=${this.project.id}&id=${data.id}`)}&notify_url=${serverUrl}/order/wechatpayreturn`
      console.log('pay url:', url)
      location.href = url
    }
  }
}
</script>
<style lang="scss">
.page-pay{
  padding: 1rem 1.13rem 5.6rem; 
  // height: 100%;
  // .fix-top{
  //   position: absolute; top: 0; left: 0; width: 100%;
  //   padding: 1rem 1.13rem;
  //   border-bottom: 1px solid #ddd; background-color: #fff;
  // }
  .pay-info-head{
    display: flex; justify-content: space-between;
  }
  p{
    margin: 0.4rem auto;
  }
  .pre-name{
    font-size: .875rem; color: #BABBC9; margin-left: 1.5rem;
  }
  .pre-price{
    font-size: 20px; color: #FF5656;
  }
  .gift-price-tips{
    margin-left: 4.8rem;
  }
  .icon-ok{
    width: 1.13rem; height: 1.13rem; margin-right: .5rem;
    background-image:url('./../../assets/images/icon-ok.png');
  }
  .icon-note{
    width: 0.7rem; height: 1rem; margin-right: .5rem; 
    background-image:url('./../../assets/images/icon-note.png');
  }
  .icon-radio{
    width: 1.13rem; height: 1.13rem; margin-right: .5rem; 
    background-image:url('./../../assets/images/icon-radio.png');
  }
  .icon-radio-checked{
    width: 1.13rem; height: 1.13rem; margin-right: .5rem; 
    background-image:url('./../../assets/images/icon-radio-checked.png');
  }

  .rule{
    // height: 100%; overflow-y: auto;
    font-size: 0.875rem; 
    margin-top: 1.4rem;
    padding-top: 1rem;
    border-top: 1px solid #ddd;
    p{
      margin: 0.4rem auto;
      line-height: 1.38rem;
    }
    .red{
      color: #FF5656;
    }
  }
  
  // .note{
  //   color: #BABBC9; font-size: .875rem; border-top: 1px solid #ddd; padding-top: 1rem; margin-top: 1.4rem;
  // }

  .rule-check{
    display: inline-block; color: #E3B689;
    &.checked{
      color: #33CCBC;
    }
    .icon{
      vertical-align: middle; margin-bottom: 5px;
    }
  }

  .fix-bar{
    height: 5.6rem;
    .rule-agree{
      height: 2.6rem; line-height: 2.6rem; padding-left: 1.13rem;
    }
  }
}
.pay-bar{
  position: fixed;
  width: 100%; padding: 15px;
  bottom: 0px; left: 0;
}
</style>

