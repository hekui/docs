<template>
  <div class="invoice-history">
    <div class="list" v-if="historyList.length > 0" v-for="(item ,index) in historyList" :key="index" @click="go(item.id)">
      <p class="time"><span class="first-span">{{ item.createTime.slice(0,10) }}</span><span>{{ item.createTime.slice(-5) }}</span><span class="right state">{{ item.invoiceStatus }}</span></p>
      <p><span class="first-span">发票类型</span><span class="two">{{ item.invoiceType === 0 ? '电子发票' : '' }}</span></p>
      <p><span class="first-span">发票内容</span><span class="two">{{ item.invoiceContent }}</span> <span class="right icon-chevron-right"></span></p>
      <p><span class="first-span">金额</span><span class="two color">{{ item.invoiceAmount }}元</span></p>
    </div>
    <div v-if="historyList.length === 0" class="empty">暂无开票信息</div>
  </div>
</template>
<script>
import {mapState} from 'vuex'
export default {
  name: 'History',
  title: '开票历史',
  computed: mapState({
    historyList: state => state.invoice.historyList,
  }),
  created() {
    this.$store.dispatch('fetchInvoiceHistory')
  },
  methods: {
    go(id){
      this.$router.push({path: '/invoice/detail', query: { id }})
    }
  }
}
</script>
<style lang="scss">
.invoice-history{

  .list{
    padding: 1rem 1.13rem 0.125rem;
    border-bottom: .5px solid #ddd;
    p{
      line-height: 1.38rem;
      font-size: 1rem;
      color: #333;
      margin: 0 0 .5rem 0;
      .first-span{
        display: inline-block;
        width: 5.25rem;
      }
      .two{
        font-size: 0.875rem;
        &.color{
          color: #FF5656;
        }
      }
      .icon-chevron-right{
        font-size: 1.125rem;
      }
    }
    .time{
      line-height: 1.25rem;
      font-size: 0.875rem;
      color: #999;
      margin-bottom: .38rem;
    }
    .right{
      float: right;
    }
  }
}
</style>
