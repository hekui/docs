<template>
  <div class="page-success">
    <div class="pay-success" v-if="payStatus">
      <div class="center">
        <img src="./../../assets/images/icon-pay-success.png"  class="icon icon-pay-success">
      </div>
      <h3 class="center ok">开票成功！</h3>
      <div class="rule">后续规则</div>
      <div class="intent">请务必填写支付诚意金时留下的手机号和正确的电子邮箱，便于我们在5个工作日内（法定节假日顺延）将发票发送到您邮箱，请注意查收。</div>
    </div>
    <div class="fix-bar">
      <button type="button" class="btn btn-prepay" @click="go('/')">返回首页</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Success',
  data(){
    return {
      payStatus: true,
    }
  },
  created(){
    // console.log(this.$route.query.id)

  },
  methods: {
    go(path){
      this.$router.push(path)
    }
  }
}
</script>
<style lang="scss">
.page-success{
  padding: 2rem 1.13rem 3rem;
  .icon-pay-success{
    width: 3.44rem; height: 3.44rem;
  }
  .ok{
    color: #444652;
    font-size: 1.25rem;
    margin: 1.06rem auto  3.63rem;
  }
  .fix-bar{
    position: fixed;
    bottom: 0; left: 0; width: 100%;
  }
  .rule{
    color: #444652;
    font-size: 0.9375rem;
  }
  .intent{
    margin-top: 0.4375rem;
    font-size: 0.875rem;
    line-height: 1.25rem;
    color: #444652;
    text-align: justify;
  }

}
</style>
