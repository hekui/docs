<template>
  <div class="rule-page">
    <h1>开票规则</h1>
    <div class="text">
      请务必填写支付诚意金时留下的手机号和正确的电子邮箱，便于我们在5个工作日内（法定节假日顺延）将发票发送到您邮箱，请注意查收。
    </div>
    <div class="fix-bar">
      <button type="button" class="btn btn-prepay" @click="back()">返回</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Rule',
  title: '开票规则',
  methods: {
    back(){
      this.$router.go(-1)
    }
  }
}
</script>
<style lang="scss">
.rule-page{
  padding: 1.88rem 1.25rem 3rem; font-size: 0.9375rem;
  h1{
    margin-top: 0; margin-bottom: 1.81rem; font-weight: 400; font-size: 1.625rem;
  }
  .text{
    line-height: 1.5rem;
  }
}
</style>
