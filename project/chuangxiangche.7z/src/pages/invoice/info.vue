<template>
  <div class="page">
    <section>
      <div class="column-title">
        <div class="title">发票信息</div>
        <div class="status">{{historyInfo.invoiceStatus}}</div>
      </div>
      <div class="column-content">
        <div class="column-row">
          <div class="column-label">发票类型</div>
          <div class="column-text">{{historyInfo.invoiceType}}</div>
        </div>
        <div class="column-row">
          <div class="column-label">发票内容</div>
          <div class="column-text">{{historyInfo.invoiceContent}}</div>
        </div>
        <div class="column-row">
          <div class="column-label">金额</div>
          <div class="column-text column-amount">{{historyInfo.invoiceAmount}}元</div>
        </div>
      </div>
    </section>
    <section>
      <div class="column-title">开票信息</div>
      <div class="column-content">
        <div class="column-row">
          <div class="column-label">开票类型</div>
          <div class="column-text">
            {{historyInfo.invoiceClass === 0 ? '个人/非企业单位' : '企业单位'}}
          </div>
        </div>
        <div class="column-row">
          <div class="column-label">发票抬头</div>
          <div class="column-text">{{historyInfo.invoiceTitle}}</div>
        </div>
        <div v-if="historyInfo.invoiceClass != 0">
          <div class="column-row">
            <div class="column-label">税号</div>
            <div class="column-text">{{historyInfo.payTaxesNum}}</div>
          </div>
          <div class="column-row">
            <div class="column-label">地址</div>
            <div class="column-text">{{historyInfo.companyAddress}}</div>
          </div>
          <div class="column-row">
            <div class="column-label">开户行名称</div>
            <div class="column-text">{{historyInfo.bankName}}</div>
          </div>
          <div class="column-row">
            <div class="column-label">开户行账号</div>
            <div class="column-text">{{historyInfo.bankNumber}}</div>
          </div>
          <div class="column-row">
            <div class="column-label">公司电话</div>
            <div class="column-text">{{historyInfo.companyTel}}</div>
          </div>
        </div>
        <div v-else>
          <div class="column-row">
            <div class="column-label">身份证号</div>
            <div class="column-text">{{historyInfo.idCard}}</div>
          </div>
        </div>

      </div>
    </section>
    <section>
      <div class="column-title">接收方式</div>
      <div class="column-content">
        <div class="column-row">
          <div class="column-label">电子邮箱</div>
          <div class="column-text">{{historyInfo.email}}</div>
        </div>
        <div class="column-row">
          <div class="column-label">手机号</div>
          <div class="column-text">{{historyInfo.phone}}</div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>

import {mapState} from 'vuex'

export default {
  name: 'Info',
  title: '开票详情',
  computed: mapState({
    historyInfo: state => state.invoice.historyInfo,
  }),
  created() {
    let id =  this.$route.query.id
    this.$store.dispatch('fetchInvoiceInfo', {
      id
    }, res => {
      console.log('fail in vue')
    })
  },
  methods: {
    // 获取初始数据
    getInitialData() {
      
    }
  }
}
</script>
<style lang="scss">
.page {
  height: 100%;
  overflow: hidden;
  overflow-y: auto;
  .column-title {
    display: flex;
    justify-content: space-between;
    padding: 0 1.13rem;
    height: 2rem;
    line-height: 2rem;
    color: #999999;
    font-size: .88rem;
    background:  #F6F6F6;
  }
  .column-content {
    background:#FFFFFF;
    .column-row {
      padding: 0 1.13rem 0 7.44rem;
      position: relative;
      text-align: left;
      border-bottom: 1px solid #DDDDDD;
      min-height: 2.88rem;
      line-height: 2.88rem;
      color: #333333;
      .column-label {
        padding-left: 1.13rem;
        position: absolute;
        left: 0;
        top: 0;
        width: 7.44rem;
        height: 100%;
        font-size: 1rem;
      }
      .column-text {
        font-size: .88rem;
      }
      .column-amount {
        color: #FF5656;
      }
    }
  }
}
</style>