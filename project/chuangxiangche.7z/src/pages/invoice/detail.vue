<template>
  <div :class="['page', {editable: !param.id}]">
    <section>
      <div class="column-title">
        <div class="title">发票信息</div>
        <div class="status"><span>{{detail.invoiceStatus}}</span></div>
      </div>
      <div class="column-content">
        <div class="column-row">
          <div class="column-label">发票类型</div>
          <div class="column-text"><span>{{invoiceTypeFilter}}</span></div>
        </div>
        <div class="column-row">
          <div class="column-label">发票内容</div>
          <div class="column-text"><span>{{detail.invoiceContent}}</span></div>
        </div>
        <div class="column-row">
          <div class="column-label">金额</div>
          <div class="column-text invoice-amount"><span>{{detail.invoiceAmount}}元</span></div>
        </div>
      </div>
    </section>
    <section v-if="dataLoaded">
      <div class="column-title">开票信息</div>
      <div class="column-content">
        <div class="column-row">
          <div class="column-label">开票类型</div>
          <div class="column-text">
            <span v-if="param.id">{{invoiceClassFilter}}</span>
            <div v-else class="radio-group">
              <div :class="['radio', {active: detail.invoiceClass === 0}]" @click="select(0)">个人/非企业单位</div>
              <div :class="['radio', {active: detail.invoiceClass === 1}]" @click="select(1)">企业单位</div>
            </div>
          </div>
        </div>
        <div class="column-row">
          <div class="column-label">发票抬头</div>
          <div class="column-text">
            <span v-if="!!param.id">{{detail.invoiceTitle}}</span>
            <input v-else type="text" v-model.trim="detail.invoiceTitle" :placeholder="detail.invoiceClass === 1 ? '请填写发票抬头（填写单位名称）' : '请填写发票抬头（填写个人姓名）'">
          </div>
        </div>
        <template v-if="detail.invoiceClass === 1">
          <div class="column-row">
            <div class="column-label">税号</div>
            <div class="column-text">
              <span v-if="!!param.id">{{detail.payTaxesNum}}</span>
              <input v-else type="text" v-model.trim="detail.payTaxesNum" placeholder="请填写纳税人识别号">
            </div>
          </div>
          <div class="column-row">
            <div class="column-label">地址</div>
            <div class="column-text">
              <span v-if="!!param.id">{{detail.companyAddress}}</span>
              <input v-else type="text" v-model.trim="detail.companyAddress" placeholder="请填写地址">
            </div>
          </div>
          <div class="column-row">
            <div class="column-label">开户行名称</div>
            <div class="column-text">
              <span v-if="!!param.id">{{detail.bankName}}</span>
              <input v-else type="text" v-model.trim="detail.bankName" placeholder="请填写开户行名称">
            </div>
          </div>
          <div class="column-row">
            <div class="column-label">开户行账号</div>
            <div class="column-text">
              <span v-if="!!param.id">{{detail.bankNumber}}</span>
              <input v-else type="text" v-model.trim="detail.bankNumber" placeholder="请填写开户行账号">
            </div>
          </div>
          <div class="column-row">
            <div class="column-label">公司电话</div>
            <div class="column-text">
              <span v-if="!!param.id">{{detail.companyTel}}</span>
              <input v-else type="text" v-model.trim="detail.companyTel" placeholder="请填写公司电话">
            </div>
          </div>
        </template>
        <template v-else>
          <div class="column-row">
            <div class="column-label">身份证号</div>
            <div class="column-text">
              <span v-if="!!param.id">{{detail.idCard}}</span>
              <input v-else type="text" v-model.trim="detail.idCard" placeholder="请填写身份证号">
            </div>
          </div>
        </template>
      </div>
    </section>
    <section>
      <div class="column-title">接收方式</div>
      <div class="column-content">
        <div class="column-row">
          <div class="column-label">电子邮箱</div>
          <div class="column-text">
            <span v-if="!!param.id">{{detail.email}}</span>
            <input v-else type="text" v-model.trim="detail.email" placeholder="请填写电子邮箱">
          </div>
        </div>
        <div class="column-row">
          <div class="column-label">手机号</div>
          <div class="column-text">
            <span v-if="!!param.id">{{detail.phone}}</span>
            <input v-else type="text" v-model.trim="detail.phone" placeholder="请填写手机号">
          </div>
        </div>
      </div>
    </section>
    <div v-if="!param.id" class="submit">
      <button type="button" class="btn btn-prepay" @click="submit()"><i class="icon-loading"></i>提交</button>
    </div>
    <section v-if="showConfirmSubmit" class="confirm-box" @click="showConfirmSubmit=false">
      <div class="content-box" @click.prevent.stop>
        <div class="title">开具电子发票</div>
        <div class="scroller-box">
          <section>
            <div class="column-title">开票信息</div>
            <div class="column-content">
              <div class="column-row">
                <div class="column-label">开票类型</div>
                <div class="column-text"><span>{{invoiceClassFilter}}</span></div>
              </div>
              <div class="column-row">
                <div class="column-label">发票抬头</div>
                <div class="column-text"><span>{{detail.invoiceTitle}}</span></div>
              </div>
              <template v-if="detail.invoiceClass === 1">
                <div class="column-row">
                  <div class="column-label">税号</div>
                  <div class="column-text"><span>{{detail.payTaxesNum}}</span></div>
                </div>
                <div class="column-row">
                  <div class="column-label">地址</div>
                  <div class="column-text"><span>{{detail.companyAddress}}</span></div>
                </div>
                <div class="column-row">
                  <div class="column-label">开户行名称</div>
                  <div class="column-text"><span>{{detail.bankName}}</span></div>
                </div>
                <div class="column-row">
                  <div class="column-label">开户行账号</div>
                  <div class="column-text"><span>{{detail.bankNumber}}</span></div>
                </div>
                <div class="column-row">
                  <div class="column-label">公司电话</div>
                  <div class="column-text"><span>{{detail.companyTel}}</span></div>
                </div>
              </template>
              <template v-else>
                <div class="column-row">
                  <div class="column-label">身份证号</div>
                  <div class="column-text"><span>{{detail.idCard}}</span></div>
                </div>
              </template>
            </div>
          </section>
          <section>
            <div class="column-title">接收方式</div>
            <div class="column-content">
              <div class="column-row">
                <div class="column-label">电子邮箱</div>
                <div class="column-text"><span>{{detail.email}}</span></div>
              </div>
              <div class="column-row">
                <div class="column-label">手机号</div>
                <div class="column-text"><span>{{detail.phone}}</span></div>
              </div>
            </div>
          </section>
          <section class="kindly-reminder">
            <div class="reminder-title">温馨提示</div>
            <div class="content">
              请务必填写支付诚意金时留下的手机号和正确的电子邮箱，便于我们在5个工作日内（法定节假日顺延）将发票送到您邮箱，请注意查收。
            </div>
          </section>
        </div>
        <div class="confirm-submit">
          <button type="button" :class="['btn btn-prepay', {'submit': isSubmitting}]" @click="confirmSubmit()"><i class="icon-loading"></i>确认提交</button>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import Vue from 'vue'
import {mapState} from 'vuex'
import Validator from '../../utils/validator'

let defaultData = {
  invoiceStatus: "", // 状态
  invoiceType: 0, // 发票类型
  invoiceContent: "信息服务费", // 发票内容
  invoiceAmount: "20000", // 金额
  invoiceClass: 1, // 开票类型
  invoiceTitle: "", // 发票抬头
  payTaxesNum: "", // 税号
  companyAddress: "", // 地址
  bankName: "", // 开户行名称
  bankNumber: "", // 开户行账号
  companyTel: "", // 公司电话
  idCard: "", // 身份证号
  email: "", // 电子邮箱
  phone: "", // 手机号
}

export default {
  name: 'InvoiceDetail',
  title: '开票详情',
  data(){
    return {
      // 参数
      param: {
        id: "", // 发票详情id
      },
      showConfirmSubmit: false, // 显示确认提交
      detail: Object.assign({}, defaultData), // 开票详情
      isSubmitting: false, // 提交中
      dataLoaded: false // 数据是否加载完毕
    }
  },
  computed: {
    invoiceTypeFilter() {
      return this.detail.invoiceType === 0 ? '电子发票': ''
    },
    invoiceClassFilter() {
      return this.detail.invoiceClass === 1 ? '企业单位' : '个人/非企业单位'
    }
  },
  created(){
    let invoiceDetail = localStorage.getItem('invoice_detail')
    if(invoiceDetail) {
      this.detail = Object.assign({}, JSON.parse(invoiceDetail))
    }

    if(this.$route.query) {
      this.param.id = this.$route.query.id || ''
    }
    if(this.param.id) {
      // 查询发票详情数据
      this.$store.dispatch('fetchFindInvoice', {
        id: this.param.id,
      }).then(res => {
        this.detail = Object.assign({}, this.$store.state.invoice.detail)
        this.dataLoaded = true
        console.log('sso res:', res)
      }).catch(function (res) {
        console.log('sso fail res:', res)
      })
    } else {
      if(!this.detail.phone) this.detail.phone = this.$store.state.user.account.phone || ""
      this.dataLoaded = true
    }
  },
  methods: {
    // 选择开票类型
    select(type) {
      this.detail.invoiceClass = type
    },
    validate() {
      let message = ''
      // 校验发票抬头
      if(message === '' && this.detail.invoiceTitle === '') message = '请填写发票抬头！'
      if(message === '' && this.detail.invoiceTitle.length > 50) message = '发票抬头不能超出50个字符！'
      if(this.detail.invoiceClass === 0) {
        // 校验身份证号
        if(message === '' && this.detail.idCard === '') message = '请填写身份证号！'
        if(message === '' && !Validator.validateIdCard(this.detail.idCard)) message = '身份证号格式不正确！'
      } else {
        // 校验税号
        if(message === '' && this.detail.payTaxesNum === '') message = '请填写税号！'
        // 校验地址
        if(message === '' && this.detail.companyAddress === '') message = '请填写地址！'
        if(message === '' && this.detail.companyAddress.length > 50) message = '地址不能超出50个字符！'
        // 校验开户行名称
        if(message === '' && this.detail.bankName === '') message = '请填写开户行名称！'
        if(message === '' && this.detail.bankName.length > 50) message = '开户行名称不能超出50个字符！'
        // 校验开户行账号
        if(message === '' && this.detail.bankNumber === '') message = '请填写开户行账号！'
        // 校验公司电话
        if(message === '' && this.detail.companyTel === '') message = '请填写公司电话！'
      }
      // 校验电子邮箱
      if(message === '' && this.detail.email === '') message = '请填写电子邮箱！'
      if(message === '' && !Validator.validateMail(this.detail.email)) message = '请填写正确的电子邮箱！'
      // 校验手机号
      if(message === '' && this.detail.phone === '') message = '请填写手机号！'
      if(message === '' && !Validator.validateChinaPhone(this.detail.phone)) message = '请填写正确的手机号！'
      return message
    },
    // 提交
    submit() {
      // 校验数据
      let message = this.validate();
      // 数据校验成功显示确认提交
      if(message){
         // 提示错误信息
        this.$toast(message)
      } else {
        this.showConfirmSubmit = true
      }
    },
    // 确认提交
    confirmSubmit(){
      if(this.isSubmitting) return
      this.isSubmitting = true
      this.$store.dispatch('fetchSaveInvoice', {
        invoiceType: this.detail.invoiceType,
        invoiceContent: this.detail.invoiceContent,
        invoiceAmount: this.detail.invoiceAmount,
        invoiceClass: this.detail.invoiceClass,
        invoiceTitle: this.detail.invoiceTitle,
        idCard: this.detail.idCard,
        email: this.detail.email,
        companyAddress: this.detail.companyAddress,
        bankName: this.detail.bankName,
        bankNumber: this.detail.bankNumber,
        companyTel: this.detail.companyTel,
        phone: this.detail.phone,
        payTaxesNum: this.detail.payTaxesNum
      }).then(res => {
        this.isSubmitting = false
        localStorage.removeItem('invoice_detail')
        this.$router.push({path: '/invoice/success'})
      }).catch(res => {
        this.isSubmitting = false
        this.$toast(res.msg)
      })
    }
  },
  watch: {
    detail: {
      handler: function(newVal, oldVal) {
        if(this.param.id === '') {
          localStorage.setItem('invoice_detail', JSON.stringify(newVal))
        }
      },
      deep: true
    }
  }
}
</script>
<style lang="scss">
.page {
  height: 100%;
  overflow: hidden;
  overflow-y: auto;
  .column-title {
    display: flex;
    justify-content: space-between;
    padding: 0 1.13rem;
    height: 2rem;
    line-height: 2rem;
    color: #999999;
    font-size: .88rem;
    background:  #F6F6F6;
  }
  .column-content {
    background:#FFFFFF;
    .column-row {
      padding: 0 1.13rem 0 7.44rem;
      position: relative;
      text-align: left;
      border-bottom: 1px solid #DDDDDD;
      color: #333333;
      .column-label {
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding-left: 1.13rem;
        position: absolute;
        left: 0;
        top: 0;
        width: 7.44rem;
        height: 100%;
        font-size: 1rem;
      }
      .column-text {
        font-size: .88rem;
        word-break : break-all;
        overflow:hidden;
        flex-direction: column;
        justify-content: center;
        min-height: 2.88rem;
        span {
          display: flex;
          flex-direction: column;
          min-height: 2.88rem;
          justify-content: center;
          padding: .5rem 0;
          line-height: 1.2rem;
        }
        input {
          font-size: .88rem;
          width: 100%;
          outline: none;
          border: none;
        }
        .radio-group {
          display: flex;
          justify-content: space-between;
          .radio {
            padding-left: 1.32rem;
            position: relative;
            &:before {
              content: '';
              position: absolute;
              left: 0;
              top: .88rem;
              width: 1.13rem;
              height: 1.13rem;
              background: url('./../../assets/images/icon-radio.png') no-repeat center/cover;
            }
          }
          .active {
            color: #999999;
            &:before {
              background: url('./../../assets/images/icon-radio-checked.png') no-repeat center/cover;
            }
          }
        }
      }
      .invoice-amount {
        color: #FF5656;
      }
    }
  }
  .submit, .confirm-submit {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3rem;
    line-height: 3rem;
    i {
      display: inline-block;
      margin-right: .5rem;
    }
  }
  .confirm-box {
    padding-top: 6rem; 
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, .3);
    .content-box { 
      padding: 3rem 0;
      position: relative;
      height: 100%;
      background: #FFFFFF;
      .title {
        position: absolute;
        left: 0;
        top: 0;
        height: 3rem;
        width: 100%;
        line-height: 3rem;
        text-align: center;
      }
      .column-label {
        color: #666;
      }
      .column-text {
        font-size: 1rem;
      }
      .scroller-box {
        height: 100%;
        overflow: hidden;
        overflow-y: auto;
        .kindly-reminder {
          padding: 1rem 1.13rem;
          .reminder-title {
            padding: 0.5rem 0;
          }
          .content {
            color: #999999;
          }
        }
      }
      
    }
  }
}
.editable {
  padding-bottom: 3rem;

}
</style>