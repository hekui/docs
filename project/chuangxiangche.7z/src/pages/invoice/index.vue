<template>
  <div class="invoice-index">
    <div class="check-box"   @click="toggleChecked">
      <div class="form-agreement" :class="{'checked': isChecked}">
        <span class="icon icon-radio" :class="{'checked': isChecked}" ></span>信息服务费</div>
      <div class="money">金额  <span>20000 <i>元</i></span></div>
    </div>
    <div class="fix-bar">
      <div class="invoice-button">
        <router-link to="/invoice/history">开票历史</router-link><router-link to="/invoice/rule">开票规则</router-link>
      </div>
      <button type="button" :class="['btn', 'btn-prepay', {'disabled': !isChecked}]" @click="next()">下一步</button>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Invoice',
  title: '选择发票',
  data () {
    return {
      isChecked: false,
    }
  },
  methods: {
    toggleChecked(){
      this.isChecked = !this.isChecked
    },
    next(){
      if(this.isChecked){
        this.$router.push({path: '/invoice/detail'})
      }else{
        this.$toast('请选择信息服务费')
      }
    }
  }
}
</script>
<style lang="scss">
.invoice-index{
  font-size: 1rem;
  .check-box{
    padding: 0 1.125rem; 
    line-height: 3.9375rem;
    border-bottom: .5px solid #DDDDDD;
    .form-agreement{
      display: inline-block; color: #333;
      .icon{
        top: 3px;
      }
      &.checked{
        color: #33CCBC;
      }
    }
    .money{
      display: block;
      float: right;
      font-size: .81rem;
      span{
        font-size: 1rem;
        color: #ff5c5c;
        i{
          font-style: normal;
          font-size: .81rem;
        }
      }
    }
  }
  .invoice-button{
    padding: 0 24.8%;
    line-height: 1.625rem;
    margin: 1.625rem 0;
    position: relative;
    &::after{
      content: "";
      display: block;
      width: .5px;
      height: 100%;
      background: #ddd;
      position: absolute;
      left: 50%;top: 0;
      transform: translateX(-50%);
    }
    a{
      font-size: 0.875rem;
      color: #999;
      display: inline-block;
      &:last-child{
        float: right;
      }
    }
  }

}
</style>
