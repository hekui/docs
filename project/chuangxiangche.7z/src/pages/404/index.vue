<template>
  <div class="page-404">
    <div>
      <h3>404</h3>
      <p>你访问的页面不存在，<router-link to="/">返回首页</router-link>。</p>
    </div>
  </div>
</template>
<style lang="scss">
.page-404{
  height: 100%; text-align: center; display: flex; align-items: center; justify-content: center; color: #999;
  h3{
    font-size: 2rem; margin-top: 0; margin-bottom: .5rem;
  }
}
</style>
