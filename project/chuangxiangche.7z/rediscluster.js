// https://github.com/luin/ioredis#readme

var Redis = require('ioredis');

// Redis集群 使用示例 以下host,port为朱波提供。
var cluster = new Redis.Cluster([{
  port: 7000,
  host: '192.168.10.232'
}, {
  port: 7001,
  host: '192.168.10.232'
}, {
  port: 7002,
  host: '192.168.10.232'
}]);

// 设置数据相同
cluster.set('foo', 'bar');
// 获取数据相同
cluster.get('foo', function (err, res) {
  console.log('res', res);
});