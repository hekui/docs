const Koa = require('koa')
const serve = require('koa-static')
const app = new Koa()
const port = 3000

const maxage = 30 * 24 * 60 * 60 * 1000 // 30天

app.use(serve('./dist/', {
  maxage: maxage
}));
app.use(serve('./public/', {
  maxage: maxage
}));

app.listen(port, ()=>{
  console.log('server listening on port '+ port)
})